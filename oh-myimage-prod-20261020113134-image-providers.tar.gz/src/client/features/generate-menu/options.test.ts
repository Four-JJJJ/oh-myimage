import { describe, expect, it } from "vitest";
import { formatGenerationSettingsSummary, qualityLabels, qualityOptionsForModel } from "./options";

describe("generate menu option helpers", () => {
  it("formats generation settings in the composer summary order", () => {
    expect(
      formatGenerationSettingsSummary({
        aspectRatio: "16:9",
        quality: "low",
        resolution: "2K",
        quantity: 4,
        outputFormat: "jpeg",
      }),
    ).toBe("16:9｜Low｜2K｜4张｜JPEG");
  });

  it("labels custom aspect ratios for the composer summary", () => {
    expect(
      formatGenerationSettingsSummary({
        aspectRatio: "custom",
        quality: "auto",
        resolution: "1K",
        quantity: 1,
        outputFormat: "png",
      }),
    ).toBe("自定义｜Auto｜1K｜1张｜PNG");
  });

  it("narrows quality tiers when image-2 is selected and widens them for 2.5 models", () => {
    expect(qualityOptionsForModel("gpt-image-2")).toEqual(["auto", "low", "medium", "high"]);
    expect(qualityOptionsForModel("gpt-image-2.5-flare")).toEqual(["auto", "low", "medium", "high", "xhigh", "max"]);
    expect(qualityOptionsForModel("gpt-image-2.5-sunburst")).toEqual(["auto", "low", "medium", "high", "xhigh", "max"]);
    expect(qualityOptionsForModel("gpt-image-2").map((quality) => qualityLabels[quality])).toEqual([
      "Auto",
      "Low",
      "Medium",
      "High",
    ]);
    expect(qualityOptionsForModel("gpt-image-2.5-flare").map((quality) => qualityLabels[quality])).toEqual([
      "Auto",
      "Low",
      "Medium",
      "High",
      "XHigh",
      "Max",
    ]);
  });
});
