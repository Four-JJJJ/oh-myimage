export const IMAGE_MODEL_OPTIONS = [
  "gpt-image-2",
  "gpt-image-2.5-flare",
  "gpt-image-2.5-sunburst",
  "grok-imagine-image",
  "grok-imagine-image-2.0",
  "gemini-2.5-flash-image",
  "gemini-3-pro-image",
  "gemini-3-pro-image-preview",
  "gemini-3.1-flash-image",
  "gemini-3.1-flash-image-preview",
  "gemini-nano-banana-2.1",
] as const;

export type ImageModel = (typeof IMAGE_MODEL_OPTIONS)[number];

export const DEFAULT_IMAGE_MODEL: ImageModel = "gpt-image-2.5-flare";

const imageModelLabels: Record<ImageModel, string> = {
  "gpt-image-2": "image-2",
  "gpt-image-2.5-flare": "Image 2.5 Flare",
  "gpt-image-2.5-sunburst": "Image 2.5 Sunburst",
  "grok-imagine-image": "Grok Imagine",
  "grok-imagine-image-2.0": "Grok Imagine 2.0",
  "gemini-2.5-flash-image": "Nano Banana",
  "gemini-3-pro-image": "Nano Banana Pro",
  "gemini-3-pro-image-preview": "Nano Banana Pro Preview",
  "gemini-3.1-flash-image": "Nano Banana 2",
  "gemini-3.1-flash-image-preview": "Nano Banana 2 Preview",
  "gemini-nano-banana-2.1": "Nano Banana 2.1",
};

const imageModelAliases: Record<string, ImageModel> = {
  "gpt-image-2": "gpt-image-2",
  "image-2": "gpt-image-2",
  "gpt-image-2.5-flare": "gpt-image-2.5-flare",
  "image-2.5-flare": "gpt-image-2.5-flare",
  "gpt-image-2.5-sunburst": "gpt-image-2.5-sunburst",
  "image-2.5-sunburst": "gpt-image-2.5-sunburst",
  "grok-imagine-image": "grok-imagine-image",
  "grok-imagine-image-1.0": "grok-imagine-image",
  "grok-2-image": "grok-imagine-image",
  "grok-2-image-1212": "grok-imagine-image",
  "grok-imagine-image-2.0": "grok-imagine-image-2.0",
  "grok-imagine-image-2": "grok-imagine-image-2.0",
  "gemini-2.5-flash-image": "gemini-2.5-flash-image",
  "gemini-2.5-flash-image-preview": "gemini-2.5-flash-image",
  "nano-banana": "gemini-2.5-flash-image",
  "gemini-3-pro-image": "gemini-3-pro-image",
  "gemini-3-pro-image-preview": "gemini-3-pro-image-preview",
  "nano-banana-pro": "gemini-3-pro-image",
  "gemini-3.1-flash-image": "gemini-3.1-flash-image",
  "gemini-3.1-flash-image-preview": "gemini-3.1-flash-image-preview",
  "nano-banana-2": "gemini-3.1-flash-image",
  "gemini-nano-banana-2.1": "gemini-nano-banana-2.1",
  "nano-banana-2.1": "gemini-nano-banana-2.1",
};

export function canonicalImageModel(model: string): ImageModel | null {
  const normalized = model.trim().toLowerCase();
  return imageModelAliases[normalized] ?? null;
}

export function isKnownImageModel(model: string): boolean {
  return canonicalImageModel(model) !== null;
}

export function imageModelLabel(model: string): string {
  const canonical = canonicalImageModel(model);
  if (canonical) return imageModelLabels[canonical];
  return model.replace(/^gpt-/, "");
}

const BASE_QUALITY_TIERS = ["auto", "low", "medium", "high"] as const;
const EXTENDED_QUALITY_TIERS = ["auto", "low", "medium", "high", "xhigh", "max"] as const;
const GROK_QUALITY_TIERS = ["auto", "low", "medium"] as const;

const imageModelQualityTiers: Record<ImageModel, readonly string[]> = {
  "gpt-image-2": BASE_QUALITY_TIERS,
  "gpt-image-2.5-flare": EXTENDED_QUALITY_TIERS,
  "gpt-image-2.5-sunburst": EXTENDED_QUALITY_TIERS,
  "grok-imagine-image": GROK_QUALITY_TIERS,
  "grok-imagine-image-2.0": GROK_QUALITY_TIERS,
  "gemini-2.5-flash-image": BASE_QUALITY_TIERS,
  "gemini-3-pro-image": BASE_QUALITY_TIERS,
  "gemini-3-pro-image-preview": BASE_QUALITY_TIERS,
  "gemini-3.1-flash-image": BASE_QUALITY_TIERS,
  "gemini-3.1-flash-image-preview": BASE_QUALITY_TIERS,
  "gemini-nano-banana-2.1": BASE_QUALITY_TIERS,
};

export function qualityTiersForModel(model: string): readonly string[] {
  const canonical = canonicalImageModel(model);
  if (canonical) return imageModelQualityTiers[canonical];
  return BASE_QUALITY_TIERS;
}

export function clampQualityForModel(model: string, quality: string): string {
  const tiers = qualityTiersForModel(model.trim() || DEFAULT_IMAGE_MODEL);
  return tiers.includes(quality) ? quality : "auto";
}

export interface DiscoveredImageModel {
  id: string;
  label: string;
}

export function imageModelsFromProviderCatalog(modelIds: readonly string[]): DiscoveredImageModel[] {
  const discovered = new Map<string, DiscoveredImageModel>();
  for (const modelId of modelIds) {
    const canonical = canonicalImageModel(modelId);
    if (!canonical || discovered.has(canonical)) continue;
    discovered.set(canonical, { id: canonical, label: imageModelLabels[canonical] });
  }
  return IMAGE_MODEL_OPTIONS.flatMap((model) => {
    const match = discovered.get(model);
    return match ? [match] : [];
  });
}
