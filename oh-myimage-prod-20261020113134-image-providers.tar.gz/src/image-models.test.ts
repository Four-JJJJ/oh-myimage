import { describe, expect, it } from "vitest";
import {
  canonicalImageModel,
  clampQualityForModel,
  DEFAULT_IMAGE_MODEL,
  IMAGE_MODEL_OPTIONS,
  imageModelLabel,
  imageModelsFromProviderCatalog,
  qualityTiersForModel,
} from "./image-models";

describe("image model catalog", () => {
  it("keeps the selectable upstream IDs and product labels aligned", () => {
    expect(IMAGE_MODEL_OPTIONS).toEqual([
      "gpt-image-2",
      "gpt-image-2.5-flare",
      "gpt-image-2.5-sunburst",
      "grok-imagine-image",
      "grok-imagine-image-2.0",
      "gemini-2.5-flash-image",
      "gemini-3-pro-image",
      "gemini-3-pro-image-preview",
      "gemini-3.1-flash-image",
      "gemini-3.1-flash-image-preview",
      "gemini-nano-banana-2.1",
    ]);
    expect(DEFAULT_IMAGE_MODEL).toBe("gpt-image-2.5-flare");
    expect(IMAGE_MODEL_OPTIONS.map(imageModelLabel)).toEqual([
      "image-2",
      "Image 2.5 Flare",
      "Image 2.5 Sunburst",
      "Grok Imagine",
      "Grok Imagine 2.0",
      "Nano Banana",
      "Nano Banana Pro",
      "Nano Banana Pro Preview",
      "Nano Banana 2",
      "Nano Banana 2 Preview",
      "Nano Banana 2.1",
    ]);
  });

  it("maps provider catalog aliases onto the supported image models", () => {
    expect(canonicalImageModel("grok-2-image-1212")).toBe("grok-imagine-image");
    expect(canonicalImageModel("gemini-3-pro-image-preview")).toBe("gemini-3-pro-image-preview");
    expect(canonicalImageModel("gemini-3.1-flash-image-preview")).toBe("gemini-3.1-flash-image-preview");
    expect(canonicalImageModel("nano-banana-2.1")).toBe("gemini-nano-banana-2.1");
    expect(
      imageModelsFromProviderCatalog([
        "gpt-4o",
        "grok-imagine-image-2",
        "gemini-2.5-flash-image-preview",
        "gemini-2.5-flash-image",
      ]).map((model) => model.id),
    ).toEqual(["grok-imagine-image-2.0", "gemini-2.5-flash-image"]);
  });
});

describe("quality tiers per model", () => {
  it("returns 4 tiers for gpt-image-2 and 6 tiers for gpt-image-2.5 models", () => {
    expect(qualityTiersForModel("gpt-image-2")).toEqual(["auto", "low", "medium", "high"]);
    expect(qualityTiersForModel("gpt-image-2.5-flare")).toEqual(["auto", "low", "medium", "high", "xhigh", "max"]);
    expect(qualityTiersForModel("gpt-image-2.5-sunburst")).toEqual(["auto", "low", "medium", "high", "xhigh", "max"]);
    expect(qualityTiersForModel("grok-imagine-image-2.0")).toEqual(["auto", "low", "medium"]);
    expect(qualityTiersForModel("gemini-3.1-flash-image")).toEqual(["auto", "low", "medium", "high"]);
  });

  it("falls back to base tiers for unknown models", () => {
    expect(qualityTiersForModel("unknown-model")).toEqual(["auto", "low", "medium", "high"]);
    expect(qualityTiersForModel("")).toEqual(["auto", "low", "medium", "high"]);
  });

  it("clamps unsupported quality values to auto", () => {
    expect(clampQualityForModel("gpt-image-2", "xhigh")).toBe("auto");
    expect(clampQualityForModel("gpt-image-2", "max")).toBe("auto");
    expect(clampQualityForModel("gpt-image-2", "high")).toBe("high");
    expect(clampQualityForModel("gpt-image-2.5-flare", "xhigh")).toBe("xhigh");
    expect(clampQualityForModel("gpt-image-2.5-flare", "max")).toBe("max");
    expect(clampQualityForModel("", "xhigh")).toBe("xhigh");
    expect(clampQualityForModel("", "max")).toBe("max");
  });
});
