import { describe, expect, it } from "vitest";
import { clampQualityForModel, DEFAULT_IMAGE_MODEL, IMAGE_MODEL_OPTIONS, imageModelLabel, qualityTiersForModel } from "./image-models";

describe("image model catalog", () => {
  it("keeps the selectable upstream IDs and product labels aligned", () => {
    expect(IMAGE_MODEL_OPTIONS).toEqual([
      "gpt-image-2",
      "gpt-image-2.5-flare",
      "gpt-image-2.5-sunburst",
    ]);
    expect(DEFAULT_IMAGE_MODEL).toBe("gpt-image-2.5-flare");
    expect(IMAGE_MODEL_OPTIONS.map(imageModelLabel)).toEqual([
      "image-2",
      "Image 2.5 Flare",
      "Image 2.5 Sunburst",
    ]);
  });
});

describe("quality tiers per model", () => {
  it("returns 4 tiers for gpt-image-2 and 6 tiers for gpt-image-2.5 models", () => {
    expect(qualityTiersForModel("gpt-image-2")).toEqual(["auto", "low", "medium", "high"]);
    expect(qualityTiersForModel("gpt-image-2.5-flare")).toEqual(["auto", "low", "medium", "high", "xhigh", "max"]);
    expect(qualityTiersForModel("gpt-image-2.5-sunburst")).toEqual(["auto", "low", "medium", "high", "xhigh", "max"]);
  });

  it("falls back to base tiers for unknown models", () => {
    expect(qualityTiersForModel("unknown-model")).toEqual(["auto", "low", "medium", "high"]);
    expect(qualityTiersForModel("")).toEqual(["auto", "low", "medium", "high"]);
  });

  it("clamps unsupported quality values to auto", () => {
    expect(clampQualityForModel("gpt-image-2", "xhigh")).toBe("auto");
    expect(clampQualityForModel("gpt-image-2", "max")).toBe("auto");
    expect(clampQualityForModel("gpt-image-2", "high")).toBe("high");
    expect(clampQualityForModel("gpt-image-2.5-flare", "xhigh")).toBe("xhigh");
    expect(clampQualityForModel("gpt-image-2.5-flare", "max")).toBe("max");
    expect(clampQualityForModel("", "xhigh")).toBe("xhigh");
    expect(clampQualityForModel("", "max")).toBe("max");
  });
});
