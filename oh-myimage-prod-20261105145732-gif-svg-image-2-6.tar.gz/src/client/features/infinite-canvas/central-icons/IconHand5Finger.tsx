import { forwardRef, type SVGProps } from "react";
import { CentralIcon } from "./icon";

export const IconHand5Finger = forwardRef<SVGSVGElement, SVGProps<SVGSVGElement>>(function IconHand5Finger(props, ref) {
  return (
    <CentralIcon ref={ref} {...props}>
      <path d="M16.25 7.75V7.25C16.25 6.42157 16.9216 5.75 17.75 5.75C18.5784 5.75 19.25 6.42157 19.25 7.25V14.2354C19.25 18.1094 16.1094 21.25 12.2354 21.25C9.32487 21.25 6.71671 19.4527 5.68043 16.7329L3.25 10.3542C3.73657 9.15947 5.3114 8.89654 6.15969 9.86836L7.25 11.1175V5.25C7.25 4.42157 7.92157 3.75 8.75 3.75C9.57843 3.75 10.25 4.42157 10.25 5.25V11M10.25 9.75V4.25C10.25 3.42157 10.9216 2.75 11.75 2.75C12.5784 2.75 13.25 3.42157 13.25 4.25V11.5M13.25 7.75V5.25C13.25 4.42157 13.9216 3.75 14.75 3.75C15.5784 3.75 16.25 4.42157 16.25 5.25V12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </CentralIcon>
  );
});
