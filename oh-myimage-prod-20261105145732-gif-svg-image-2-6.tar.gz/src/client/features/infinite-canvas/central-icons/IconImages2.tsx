import { forwardRef, type SVGProps } from "react";
import { CentralIcon } from "./icon";

export const IconImages2 = forwardRef<SVGSVGElement, SVGProps<SVGSVGElement>>(function IconImages2(props, ref) {
  return (
    <CentralIcon ref={ref} {...props}>
      <path d="M14.5 7C13.1193 7 12 8.11929 12 9.5C12 10.8807 13.1193 12 14.5 12C15.8807 12 17 10.8807 17 9.5C17 8.11929 15.8807 7 14.5 7Z" fill="currentColor" />
      <path fillRule="evenodd" clipRule="evenodd" d="M6.75 3.25C4.817 3.25 3.25 4.817 3.25 6.75V17.25C3.25 19.183 4.817 20.75 6.75 20.75H17.25C19.183 20.75 20.75 19.183 20.75 17.25V6.75C20.75 4.817 19.183 3.25 17.25 3.25H6.75ZM4.25 6.75C4.25 5.36929 5.36929 4.25 6.75 4.25H17.25C18.6307 4.25 19.75 5.36929 19.75 6.75V17.25C19.75 18.6307 18.6307 19.75 17.25 19.75H16.4571L10.4749 13.7678C9.10804 12.4009 6.89196 12.4009 5.52513 13.7678L4.25 15.0429V6.75Z" fill="currentColor" />
    </CentralIcon>
  );
});
