import { forwardRef, type SVGProps } from "react";
import { CentralIcon } from "./icon";

export const IconBubble5 = forwardRef<SVGSVGElement, SVGProps<SVGSVGElement>>(function IconBubble5(props, ref) {
  return (
    <CentralIcon ref={ref} {...props}>
      <path d="M21.75 12C21.75 6.84375 17.9583 3.75 12 3.75C6.04167 3.75 2.25 6.84375 2.25 12C2.25 13.3368 3.17054 15.6055 3.3145 15.9522C3.32742 15.9833 3.34021 16.0117 3.3518 16.0433C3.45089 16.3136 3.85722 17.7527 2.25 19.8828C4.41667 20.914 6.71766 19.2188 6.71766 19.2188C8.30963 20.0597 10.2038 20.25 12 20.25C17.9583 20.25 21.75 17.1562 21.75 12Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square" strokeLinejoin="round" />
    </CentralIcon>
  );
});
