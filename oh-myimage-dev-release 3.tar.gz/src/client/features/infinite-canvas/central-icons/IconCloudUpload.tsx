import { forwardRef, type SVGProps } from "react";

export const IconCloudUpload = forwardRef<SVGSVGElement, SVGProps<SVGSVGElement>>(function IconCloudUpload(props, ref) {
  return (
    <svg ref={ref} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path d="M12 19.25V11.75M12 11.75L14.5 14.25M12 11.75L9.5 14.25" fill="currentColor" />
    </svg>
  );
});
