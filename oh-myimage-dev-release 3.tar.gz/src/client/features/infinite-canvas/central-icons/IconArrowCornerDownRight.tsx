import { forwardRef, type SVGProps } from "react";

export const IconArrowCornerDownRight = forwardRef<SVGSVGElement, SVGProps<SVGSVGElement>>(function IconArrowCornerDownRight(props, ref) {
  return (
    <svg ref={ref} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path d="M3.75 4.75V13.25C3.75 14.3546 4.64543 15.25 5.75 15.25H19.25" fill="currentColor" />
    </svg>
  );
});
