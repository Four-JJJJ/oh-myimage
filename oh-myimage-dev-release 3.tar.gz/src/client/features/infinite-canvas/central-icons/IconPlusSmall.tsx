import { forwardRef, type SVGProps } from "react";

export const IconPlusSmall = forwardRef<SVGSVGElement, SVGProps<SVGSVGElement>>(function IconPlusSmall(props, ref) {
  return (
    <svg ref={ref} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path d="M12 6.75V12M12 12V17.25M12 12H6.75M12 12H17.25" fill="currentColor" />
    </svg>
  );
});
