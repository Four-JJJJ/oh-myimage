import { forwardRef, type SVGProps } from "react";

export const IconFocusZoomIn = forwardRef<SVGSVGElement, SVGProps<SVGSVGElement>>(function IconFocusZoomIn(props, ref) {
  return (
    <svg ref={ref} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path d="M3.75 8V5.75C3.75 4.64543 4.64543 3.75 5.75 3.75H8M3.75 16V18.25C3.75 19.3546 4.64543 20.25 5.75 20.25H8M16 3.75H18.25C19.3546 3.75 20.25 4.64543 20.25 5.75V8M20.25 16V18.25C20.25 19.3546 19.3546 20.25 18.25 20.25H16M8.75 12H15.25" fill="currentColor" />
    </svg>
  );
});
