import { forwardRef, type SVGProps } from "react";

export const IconTrashCan = forwardRef<SVGSVGElement, SVGProps<SVGSVGElement>>(function IconTrashCan(props, ref) {
  return (
    <svg ref={ref} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path d="M4.75 6.5L5.65512 19.3901C5.72868 20.4377 6.6 21.25 7.6502 21.25H16.3498C17.4 21.25 18.2713 20.4377 18.3449 19.3901L19.25 6.5" fill="currentColor" />
    </svg>
  );
});
