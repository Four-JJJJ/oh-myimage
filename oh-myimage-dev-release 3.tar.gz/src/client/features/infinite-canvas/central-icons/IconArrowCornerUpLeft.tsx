import { forwardRef, type SVGProps } from "react";

export const IconArrowCornerUpLeft = forwardRef<SVGSVGElement, SVGProps<SVGSVGElement>>(function IconArrowCornerUpLeft(props, ref) {
  return (
    <svg ref={ref} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path d="M20.25 19.25V10.75C20.25 9.64543 19.3546 8.75 18.25 8.75H4.75" fill="currentColor" />
    </svg>
  );
});
