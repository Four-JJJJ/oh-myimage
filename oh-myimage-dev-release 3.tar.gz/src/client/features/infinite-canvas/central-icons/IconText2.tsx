import { forwardRef, type SVGProps } from "react";

export const IconText2 = forwardRef<SVGSVGElement, SVGProps<SVGSVGElement>>(function IconText2(props, ref) {
  return (
    <svg ref={ref} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path d="M3.75 3.75H12H20.25" fill="currentColor" />
    </svg>
  );
});
