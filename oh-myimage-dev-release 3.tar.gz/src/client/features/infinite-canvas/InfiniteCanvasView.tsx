import { IconArrowCornerDownRight } from "./central-icons/IconArrowCornerDownRight";
import { IconArrowCornerUpLeft } from "./central-icons/IconArrowCornerUpLeft";
import { IconBubble5 } from "./central-icons/IconBubble5";
import { IconCloudUpload } from "./central-icons/IconCloudUpload";
import { IconCursor1 } from "./central-icons/IconCursor1";
import { IconFocusZoomIn } from "./central-icons/IconFocusZoomIn";
import { IconFocusZoomOut } from "./central-icons/IconFocusZoomOut";
import { IconHand5Finger } from "./central-icons/IconHand5Finger";
import { IconImages2 } from "./central-icons/IconImages2";
import { IconPan } from "./central-icons/IconPan";
import { IconPlusSmall } from "./central-icons/IconPlusSmall";
import { IconText2 } from "./central-icons/IconText2";
import { IconTrashCan } from "./central-icons/IconTrashCan";
import {
  DragEvent as ReactDragEvent,
  PointerEvent as ReactPointerEvent,
  useEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import { DEFAULT_IMAGE_MODEL, RATIO_OPTIONS, RESOLUTION_OPTIONS, clampQualityForModel, imageModelLabel, qualityTiersForModel, sizeForRatioResolution } from "../../../image-models";
import { api, type AppConfig, type GenerationJob, type ImageItem } from "../../api";
import { cn } from "../../lib/utils";
import { isTerminalGenerationJobStatus } from "../../generation-state";
import { AppShell } from "../generate-shell/AppShell";
import { ComposerPanel, updateGenerateForm, type GenerateForm } from "../generate-menu/GenerateMenuView";
import { AssistantRail, AssetRail, MiniMap, dotGridStyle, paintDraggedNodes, paintWorld, worldStyle } from "./canvas-chrome";
import type { WorkspaceView } from "../generate-shell/AppShell";
import {
  type CanvasDocument,
  type CanvasEdge,
  type CanvasNode,
  type CanvasNodeKind,
  type CanvasPoint,
  type CanvasRect,
  CANVAS_NODE_WIDTH,
  cloneDocument,
  connectNodes,
  createCanvasNode,
  duplicateNodes,
  edgePath,
  emptyCanvasDocument,
  fitViewport,
  incomingNodes,
  inputPort,
  moveNodes,
  nodesInsideRect,
  outputPort,
  panViewport,
  parseCanvasDocument,
  promptForNode,
  pushHistory,
  cardSizeForRatio,
  referenceSourcesForNode,
  removeNodes,
  screenToCanvas,
  zoomViewportAt,
} from "./geometry";

interface InfiniteCanvasViewProps {
  config: AppConfig;
  providerConfigured: boolean;
  onNavigate: (view: WorkspaceView) => void;
  onProviderNeeded: () => void;
  onLogout: () => void;
}

type Tool = "select" | "pan";
type MenuState = { x: number; y: number; canvas: CanvasPoint } | null;

const STORAGE_KEY = "ohm.infinite-canvas.v1";
const QUALITY_LABELS: Record<string, string> = {
  auto: "Auto",
  low: "Low",
  medium: "Medium",
  high: "High",
  xhigh: "XHigh",
  max: "Max",
};

export function InfiniteCanvasView({
  config,
  providerConfigured,
  onNavigate,
  onProviderNeeded,
  onLogout,
}: InfiniteCanvasViewProps) {
  const [documentState, setDocumentState] = useState<CanvasDocument>(() => readStoredCanvas());
  const [past, setPast] = useState<CanvasDocument[]>([]);
  const [future, setFuture] = useState<CanvasDocument[]>([]);
  const [tool, setTool] = useState<Tool>("select");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [menu, setMenu] = useState<MenuState>(null);
  const [marquee, setMarquee] = useState<CanvasRect | null>(null);
  const [draftEdge, setDraftEdge] = useState<{ from: string; to: CanvasPoint } | null>(null);
  const pendingSourceRef = useRef<string | null>(null);
  const [notice, setNotice] = useState("");
  const [assistantOpen, setAssistantOpen] = useState(true);
  const [assetsOpen, setAssetsOpen] = useState(true);
  const [promptDraft, setPromptDraft] = useState("");
  const [editingTextId, setEditingTextId] = useState<string | null>(null);
  const surfaceRef = useRef<HTMLDivElement | null>(null);
  const worldRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const uploadTargetRef = useRef<CanvasPoint | null>(null);
  const documentRef = useRef(documentState);
  const spacePressed = useRef(false);
  const idRef = useRef(0);

  useEffect(() => {
    documentRef.current = documentState;
  }, [documentState]);

  useEffect(() => {
    const handle = window.setTimeout(() => {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(documentState));
    }, 250);
    return () => window.clearTimeout(handle);
  }, [documentState]);

  useEffect(() => {
    const active = documentState.nodes.filter((node) => node.jobId && !isTerminalGenerationJobStatus(node.status === "idle" ? "queued" : node.status));
    if (active.length === 0) return;
    let cancelled = false;
    const timer = window.setInterval(() => {
      void Promise.all(active.map(async (node) => {
        if (!node.jobId) return null;
        const result = await api<{ ok: true; job: GenerationJob; images: ImageItem[] }>(`/api/generations/${node.jobId}`);
        return { nodeId: node.id, job: result.job, images: result.images };
      })).then((results) => {
        if (cancelled) return;
        setDocumentState((current) => applyGenerationResults(current, results.filter((item): item is NonNullable<typeof item> => Boolean(item))));
      }).catch((error: unknown) => {
        if (!cancelled) setNotice(error instanceof Error ? error.message : "画布生成状态刷新失败。");
      });
    }, 2000);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, [documentState.nodes]);

  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if (isTypingTarget(event.target)) return;
      const key = event.key.toLowerCase();
      const meta = event.metaKey || event.ctrlKey;
      if (meta && key === "z") {
        event.preventDefault();
        if (event.shiftKey) redo();
        else undo();
      } else if (meta && key === "a") {
        event.preventDefault();
        setSelectedIds(documentRef.current.nodes.map((node) => node.id));
      } else if (meta && key === "d") {
        event.preventDefault();
        duplicateSelection();
      } else if (key === "delete" || key === "backspace") {
        event.preventDefault();
        deleteSelection();
      } else if (key === "v") {
        setTool("select");
      } else if (key === "h") {
        setTool("pan");
      } else if (event.code === "Space") {
        spacePressed.current = true;
      } else if (key === "f") {
        fit();
      }
    }
    function onKeyUp(event: KeyboardEvent) {
      if (event.code === "Space") spacePressed.current = false;
    }
    function onPaste(event: ClipboardEvent) {
      if (isTypingTarget(event.target)) return;
      const files = Array.from(event.clipboardData?.files ?? []).filter((file) => file.type.startsWith("image/"));
      if (files.length === 0) return;
      event.preventDefault();
      const frame = surfaceRef.current?.getBoundingClientRect();
      const point = frame ? screenToCanvas({ x: frame.width / 2, y: frame.height / 2 }, documentRef.current.viewport) : { x: 160, y: 120 };
      void addUploadFiles(files, point);
    }
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("paste", onPaste);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("paste", onPaste);
    };
  });

  const selected = useMemo(
    () => documentState.nodes.filter((node) => selectedIds.includes(node.id)),
    [documentState.nodes, selectedIds],
  );
  const primary = selected.length === 1 ? selected[0] : null;

  function nextId(prefix: string) {
    idRef.current += 1;
    return `${prefix}_${Date.now().toString(36)}_${idRef.current}`;
  }

  function commit(recipe: (current: CanvasDocument) => CanvasDocument, recordHistory = true) {
    setDocumentState((current) => {
      const next = recipe(current);
      if (next === current) return current;
      if (recordHistory) {
        setPast((items) => pushHistory(items, current));
        setFuture([]);
      }
      return next;
    });
  }

  function undo() {
    setPast((items) => {
      const previous = items.at(-1);
      if (!previous) return items;
      setFuture((forward) => [cloneDocument(documentRef.current), ...forward].slice(0, 50));
      setDocumentState(previous);
      return items.slice(0, -1);
    });
  }

  function redo() {
    setFuture((items) => {
      const [next, ...rest] = items;
      if (!next) return items;
      setPast((backward) => pushHistory(backward, documentRef.current));
      setDocumentState(next);
      return rest;
    });
  }

  function addNode(kind: CanvasNodeKind, point: CanvasPoint) {
    const node = createCanvasNode(kind, point, nextId(kind), {
      aspectRatio: config.ratios[0] ?? "16:9",
      resolution: "1K",
      quality: config.qualities[0] ?? "auto",
    });
    commit((current) => ({ ...current, nodes: [...current.nodes, node] }));
    setSelectedIds([node.id]);
    setMenu(null);
    if (kind === "upload") {
      uploadTargetRef.current = point;
      fileInputRef.current?.click();
    }
  }

  function updateNode(id: string, patch: Partial<CanvasNode>, recordHistory = false) {
    commit((current) => ({
      ...current,
      nodes: current.nodes.map((node) => (node.id === id ? { ...node, ...patch } : node)),
    }), recordHistory);
  }

  function deleteSelection() {
    if (selectedIds.length === 0) return;
    const ids = selectedIds;
    commit((current) => removeNodes(current, ids));
    setSelectedIds([]);
  }

  function duplicateSelection() {
    if (selectedIds.length === 0) return;
    const ids = selectedIds;
    let created: string[] = [];
    commit((current) => {
      const before = new Set(current.nodes.map((node) => node.id));
      const next = duplicateNodes(current, ids, () => nextId("node"));
      created = next.nodes.filter((node) => !before.has(node.id)).map((node) => node.id);
      return next;
    });
    setSelectedIds(created);
  }

  function fit() {
    const frame = surfaceRef.current?.getBoundingClientRect();
    if (!frame) return;
    commit((current) => ({ ...current, viewport: fitViewport(current.nodes, frame) }), false);
  }

  function zoomBy(factor: number) {
    const frame = surfaceRef.current?.getBoundingClientRect();
    const origin = frame ? { x: frame.width / 2, y: frame.height / 2 } : { x: 0, y: 0 };
    commit((current) => ({ ...current, viewport: zoomViewportAt(current.viewport, origin, current.viewport.zoom * factor) }), false);
  }

  async function generateNode(nodeId: string) {
    const current = documentRef.current;
    const node = current.nodes.find((item) => item.id === nodeId);
    if (!node || node.kind === "upload") return;
    if (!providerConfigured) {
      onProviderNeeded();
      return;
    }
    const prompt = promptForNode(current.nodes, current.edges, nodeId);
    if (!prompt) {
      setNotice("先写提示词，或把文字节点连到这张图上。");
      return;
    }
    const references = referenceSourcesForNode(current.nodes, current.edges, nodeId);
    const [width, height] = sizeForRatioResolution(node.aspectRatio, node.resolution);
    const model = node.model || config.model || DEFAULT_IMAGE_MODEL;
    setNotice("");
    updateNode(nodeId, { status: "queued", error: undefined, text: node.text || prompt });
    try {
      const body = await canvasGenerationBody({
        prompt,
        model,
        aspectRatio: node.aspectRatio,
        resolution: node.resolution,
        width,
        height,
        quality: clampQualityForModel(model, node.quality),
        quantity: Math.min(4, Math.max(1, node.quantity)),
        outputFormat: "png",
        compression: 100,
      }, references);
      const created = await api<{ ok: true; jobId: string; status: "queued" }>("/api/generations", { method: "POST", body });
      updateNode(nodeId, { jobId: created.jobId, status: "queued", error: undefined });
    } catch (error) {
      updateNode(nodeId, { status: "failed", error: error instanceof Error ? error.message : "创建生成任务失败。" });
    }
  }

  async function addUploadFiles(files: File[], point: CanvasPoint) {
    const images = files.filter((file) => ["image/png", "image/jpeg", "image/webp", "image/jpg"].includes(file.type));
    if (images.length === 0) {
      setNotice("只支持 PNG、JPEG 或 WebP。");
      return;
    }
    const nodes = await Promise.all(images.map(async (file, index) => {
      const url = URL.createObjectURL(file);
      const node = createCanvasNode("upload", { x: point.x + index * 32, y: point.y + index * 24 }, nextId("upload"));
      return { ...node, imageUrl: url, imageName: file.name || "参考图", text: file.name || "上传图片", status: "succeeded" as const };
    }));
    commit((current) => ({ ...current, nodes: [...current.nodes, ...nodes] }));
    setSelectedIds(nodes.map((node) => node.id));
    setMenu(null);
  }

  function onSurfacePointerDown(event: ReactPointerEvent<HTMLDivElement>) {
    const target = event.target instanceof Element ? event.target : null;
    const onNode = Boolean(target?.closest("[data-node-id]"));
    const onControl = Boolean(target?.closest("button, input, textarea, select, a"));
    if (!onNode && !onControl && (event.button === 1 || (event.button === 0 && !event.shiftKey))) {
      event.currentTarget.setPointerCapture(event.pointerId);
      event.currentTarget.dataset.drag = "pan";
      event.currentTarget.dataset.x = String(event.clientX);
      event.currentTarget.dataset.y = String(event.clientY);
      setMenu(null);
      return;
    }
    if (event.button !== 0 || onControl || !event.shiftKey) return;
    const local = localPoint(event, surfaceRef.current);
    const origin = screenToCanvas(local, documentRef.current.viewport);
    setMenu(null);
    if (!event.shiftKey) setSelectedIds([]);
    setMarquee({ ...origin, width: 0, height: 0 });
    event.currentTarget.setPointerCapture(event.pointerId);
    event.currentTarget.dataset.drag = "marquee";
    event.currentTarget.dataset.x = String(origin.x);
    event.currentTarget.dataset.y = String(origin.y);
  }

  function onSurfacePointerMove(event: ReactPointerEvent<HTMLDivElement>) {
    const mode = event.currentTarget.dataset.drag;
    if (!mode) return;
    if (mode === "pan") {
      const previousX = Number(event.currentTarget.dataset.x);
      const previousY = Number(event.currentTarget.dataset.y);
      const delta = { x: event.clientX - previousX, y: event.clientY - previousY };
      event.currentTarget.dataset.x = String(event.clientX);
      event.currentTarget.dataset.y = String(event.clientY);
      const viewport = panViewport(documentRef.current.viewport, delta);
      documentRef.current = { ...documentRef.current, viewport };
      paintWorld(worldRef.current, surfaceRef.current, viewport);
      return;
    }
    if (mode === "marquee") {
      const origin = { x: Number(event.currentTarget.dataset.x), y: Number(event.currentTarget.dataset.y) };
      const point = screenToCanvas(localPoint(event, surfaceRef.current), documentRef.current.viewport);
      setMarquee({ x: origin.x, y: origin.y, width: point.x - origin.x, height: point.y - origin.y });
    }
  }

  function onSurfacePointerUp(event: ReactPointerEvent<HTMLDivElement>) {
    const mode = event.currentTarget.dataset.drag;
    delete event.currentTarget.dataset.drag;
    if (mode === "pan") {
      setDocumentState((current) => ({ ...current, viewport: documentRef.current.viewport }));
    }
    if (mode === "marquee" && marquee) {
      const ids = nodesInsideRect(documentRef.current.nodes, marquee);
      setSelectedIds((current) => (event.shiftKey ? Array.from(new Set([...current, ...ids])) : ids));
    }
    setMarquee(null);
  }

  function onWheel(event: React.WheelEvent<HTMLDivElement>) {
    const current = documentRef.current.viewport;
    const viewport = event.ctrlKey || event.metaKey
      ? zoomViewportAt(current, localPoint(event, surfaceRef.current), current.zoom * Math.exp(-event.deltaY * 0.0015))
      : panViewport(current, { x: -event.deltaX, y: -event.deltaY });
    documentRef.current = { ...documentRef.current, viewport };
    paintWorld(worldRef.current, surfaceRef.current, viewport);
    scheduleViewportCommit();
  }

  function scheduleViewportCommit() {
    const surface = surfaceRef.current;
    if (!surface || surface.dataset.commit === "1") return;
    surface.dataset.commit = "1";
    window.requestAnimationFrame(() => {
      if (surfaceRef.current) delete surfaceRef.current.dataset.commit;
      setDocumentState((current) => current.viewport === documentRef.current.viewport ? current : { ...current, viewport: documentRef.current.viewport });
    });
  }

  function startNodeDrag(event: ReactPointerEvent<HTMLElement>, nodeId: string) {
    const target = event.target instanceof Element ? event.target : null;
    if (tool === "pan" || event.button !== 0 || target?.closest("button, textarea, input, select")) return;
    event.stopPropagation();
    const ids = selectedIds.includes(nodeId) ? selectedIds : [nodeId];
    if (!selectedIds.includes(nodeId)) setSelectedIds(event.shiftKey ? [...selectedIds, nodeId] : [nodeId]);
    const start = screenToCanvas(localPoint(event, surfaceRef.current), documentRef.current.viewport);
    const snapshot = documentRef.current;
    event.currentTarget.setPointerCapture(event.pointerId);
    const move = (next: PointerEvent) => {
      const point = screenToCanvas(clientToLocal(next, surfaceRef.current), snapshot.viewport);
      const delta = { x: point.x - start.x, y: point.y - start.y };
      const nodes = moveNodes(snapshot.nodes, ids, delta);
      documentRef.current = { ...snapshot, nodes };
      paintDraggedNodes(worldRef.current, nodes, snapshot.edges, ids);
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      const moved = documentRef.current;
      setDocumentState((current) => ({
        ...current,
        nodes: current.nodes.map((node) => {
          const next = moved.nodes.find((item) => item.id === node.id);
          return next ? { ...node, x: next.x, y: next.y } : node;
        }),
      }));
      setPast((items) => pushHistory(items, snapshot));
      setFuture([]);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  }

  function startConnect(event: ReactPointerEvent<HTMLButtonElement>, nodeId: string) {
    event.stopPropagation();
    event.preventDefault();
    const move = (next: PointerEvent) => {
      setDraftEdge({ from: nodeId, to: screenToCanvas(clientToLocal(next, surfaceRef.current), documentRef.current.viewport) });
    };
    const up = (next: PointerEvent) => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      const point = screenToCanvas(clientToLocal(next, surfaceRef.current), documentRef.current.viewport);
      const target = documentRef.current.nodes.find((node) => node.id !== nodeId && pointInsideNode(point, node));
      if (target) {
        commit((current) => ({ ...current, edges: connectNodes(current.nodes, current.edges, nodeId, target.id, nextId("edge")) }));
        pendingSourceRef.current = null;
      } else {
        pendingSourceRef.current = nodeId;
        setMenu({ x: next.clientX, y: next.clientY, canvas: point });
      }
      setDraftEdge(null);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  }

  function connectFromMenu(kind: CanvasNodeKind) {
    if (!menu || !pendingSourceRef.current) return;
    const node = createCanvasNode(kind, menu.canvas, nextId(kind));
    const source = pendingSourceRef.current;
    pendingSourceRef.current = null;
    commit((current) => {
      const nodes = [...current.nodes, node];
      return { ...current, nodes, edges: connectNodes(nodes, current.edges, source, node.id, nextId("edge")) };
    });
    setSelectedIds([node.id]);
    setMenu(null);
  }

  function onDrop(event: ReactDragEvent<HTMLDivElement>) {
    event.preventDefault();
    const files = Array.from(event.dataTransfer.files);
    if (files.length === 0) return;
    const point = screenToCanvas(localPoint(event, surfaceRef.current), documentRef.current.viewport);
    void addUploadFiles(files, point);
  }

  const viewport = documentState.viewport;
  const marqueeStyle = marquee ? rectStyle(normalizeDisplayedRect(marquee)) : null;

  return (
    <AppShell activeView="canvas" onNavigate={onNavigate} onLogout={onLogout}>
      <div className="relative flex h-full min-w-0 overflow-hidden bg-[#161616] text-white">
        <AssetRail
          open={assetsOpen}
          nodes={documentState.nodes}
          selectedIds={selectedIds}
          onToggle={() => setAssetsOpen((current) => !current)}
          onFocus={(id) => setSelectedIds([id])}
        />
        <div className="relative min-w-0 flex-1">
        <CanvasTopBar
          name={documentState.name}
          onName={(name) => commit((current) => ({ ...current, name }), false)}
          zoom={viewport.zoom}
          assistantOpen={assistantOpen}
          onAssistant={() => setAssistantOpen((current) => !current)}
        />
        <div
          ref={surfaceRef}
          className={cn("absolute inset-0 overflow-hidden", tool === "pan" || spacePressed.current ? "cursor-grab active:cursor-grabbing" : "cursor-grab active:cursor-grabbing")}
          style={dotGridStyle(viewport)}
          onPointerDown={onSurfacePointerDown}
          onPointerMove={onSurfacePointerMove}
          onPointerUp={onSurfacePointerUp}
          onPointerCancel={onSurfacePointerUp}
          onWheel={onWheel}
          onDoubleClick={(event) => {
            if (event.target !== event.currentTarget) return;
            const canvas = screenToCanvas(localPoint(event, surfaceRef.current), viewport);
            setMenu({ x: event.clientX, y: event.clientY, canvas });
          }}
          onContextMenu={(event) => {
            event.preventDefault();
            const canvas = screenToCanvas(localPoint(event, surfaceRef.current), viewport);
            setMenu({ x: event.clientX, y: event.clientY, canvas });
          }}
          onDragOver={(event) => event.preventDefault()}
          onDrop={onDrop}
        >
          <div ref={worldRef} className="canvas-world absolute left-0 top-0" style={worldStyle(viewport)}>
            <svg className="pointer-events-none absolute overflow-visible" width="1" height="1">
              {documentState.edges.map((edge) => {
                const from = documentState.nodes.find((node) => node.id === edge.from);
                const to = documentState.nodes.find((node) => node.id === edge.to);
                if (!from || !to) return null;
                return <path key={edge.id} data-edge-id={edge.id} d={edgePath(outputPort(from), inputPort(to))} fill="none" stroke="rgba(255,255,255,0.72)" strokeWidth="1.6" />;
              })}
              {draftEdge && (() => {
                const from = documentState.nodes.find((node) => node.id === draftEdge.from);
                return from ? <path d={edgePath(outputPort(from), draftEdge.to)} fill="none" stroke="rgba(255,255,255,0.9)" strokeWidth="1.6" strokeDasharray="5 4" /> : null;
              })()}
            </svg>
            {documentState.nodes.map((node) => (
              <CanvasCard
                key={node.id}
                node={node}
                selected={selectedIds.includes(node.id)}
                incoming={incomingNodes(documentState.nodes, documentState.edges, node.id).length}
                composerOpen={selectedIds.length === 1 && selectedIds[0] === node.id && node.kind !== "upload"}
                config={config}
                onPointerDown={(event) => startNodeDrag(event, node.id)}
                onSelect={() => setSelectedIds([node.id])}
                onConnect={(event) => startConnect(event, node.id)}
                editing={editingTextId === node.id}
                onEdit={() => setEditingTextId((current) => current === node.id ? null : node.id)}
                onText={(text) => updateNode(node.id, { text })}
                onPatch={(patch) => updateNode(node.id, patch)}
                onGenerate={() => {
                  setSelectedIds([node.id]);
                  if (!node.text.trim() && promptForNode(documentRef.current.nodes, documentRef.current.edges, node.id)) {
                    void generateNode(node.id);
                    return;
                  }
                  void generateNode(node.id);
                }}
                onUpload={() => {
                  uploadTargetRef.current = { x: node.x, y: node.y };
                  fileInputRef.current?.click();
                }}
              />
            ))}
            {marqueeStyle && <div className="pointer-events-none absolute border border-white/80 bg-white/10" style={marqueeStyle} />}
          </div>
        </div>

        {documentState.nodes.length === 0 && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div className="max-w-sm text-center">
              <p className="text-lg text-white/88">从一张画布开始</p>
              <p className="mt-2 text-sm leading-6 text-white/48">双击空白处添加文字或图片。把节点连起来，上游文字和图片会成为下一次生成的上下文。</p>
            </div>
          </div>
        )}

        <CanvasToolbar
          tool={tool}
          canUndo={past.length > 0}
          canRedo={future.length > 0}
          onTool={setTool}
          onAdd={(kind) => {
            const frame = surfaceRef.current?.getBoundingClientRect();
            const center = frame
              ? screenToCanvas({ x: frame.width / 2, y: frame.height / 2 }, documentRef.current.viewport)
              : { x: 240, y: 180 };
            const offset = documentRef.current.nodes.length * 36;
            addNode(kind, { x: center.x - CANVAS_NODE_WIDTH / 2 + offset, y: center.y - 90 + offset });
          }}
          onUpload={() => {
            const frame = surfaceRef.current?.getBoundingClientRect();
            uploadTargetRef.current = frame ? screenToCanvas({ x: frame.width / 2 - 140, y: frame.height / 2 - 80 }, viewport) : { x: 120, y: 120 };
            fileInputRef.current?.click();
          }}
          onUndo={undo}
          onRedo={redo}
        />
        <ZoomControl zoom={viewport.zoom} onZoomOut={() => zoomBy(0.9)} onZoomIn={() => zoomBy(1.1)} onFit={fit} />
        {primary && (
          <Inspector
            node={primary}
            config={config}
            onChange={(patch) => updateNode(primary.id, patch)}
            onDelete={deleteSelection}
            onDuplicate={duplicateSelection}
          />
        )}
        {menu && (
          <CanvasMenu
            menu={menu}
            canChain={Boolean(pendingSourceRef.current)}
            onAdd={pendingSourceRef.current ? connectFromMenu : addNode}
            onUpload={() => {
              uploadTargetRef.current = menu.canvas;
              fileInputRef.current?.click();
              setMenu(null);
            }}
            onClose={() => {
              pendingSourceRef.current = null;
              setMenu(null);
              setDraftEdge(null);
            }}
          />
        )}
        {primary && primary.kind === "image" && (
          <div
            className="absolute z-30 w-[min(840px,calc(100vw-32px))] -translate-x-1/2"
            style={{ left: viewport.x + (primary.x + primary.width / 2) * viewport.zoom, top: viewport.y + (primary.y + primary.height) * viewport.zoom + 16 }}
            onPointerDown={(event) => event.stopPropagation()}
          >
            <CanvasComposer node={primary} nodes={documentState.nodes} edges={documentState.edges} config={config} onPatch={(patch) => updateNode(primary.id, patch)} onGenerate={() => void generateNode(primary.id)} onRemoveReference={(sourceId) => commit((current) => ({ ...current, edges: current.edges.filter((edge) => !(edge.to === primary.id && edge.from === sourceId)) }))} />
          </div>
        )}
        {notice && <div className="absolute bottom-24 left-1/2 max-w-md -translate-x-1/2 rounded-xl bg-black/80 px-4 py-2 text-sm text-white shadow-lg">{notice}</div>}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/png,image/jpeg,image/webp"
          multiple
          className="hidden"
          onChange={(event) => {
            const files = Array.from(event.target.files ?? []);
            const point = uploadTargetRef.current ?? { x: 120, y: 120 };
            event.target.value = "";
            void addUploadFiles(files, point);
          }}
        />
        </div>
        <AssistantRail
          open={assistantOpen}
          draft={promptDraft}
          onDraft={setPromptDraft}
          onClose={() => setAssistantOpen(false)}
          onPlace={() => {
            const text = promptDraft.trim();
            if (!text) return;
            const frame = surfaceRef.current?.getBoundingClientRect();
            const center = frame ? screenToCanvas({ x: frame.width * 0.62, y: frame.height / 2 }, documentRef.current.viewport) : { x: 280, y: 180 };
            const node = createCanvasNode("text", { x: center.x, y: center.y }, nextId("text"), { aspectRatio: config.ratios[0] ?? "16:9" });
            commit((current) => ({ ...current, nodes: [...current.nodes, { ...node, text }] }));
            setSelectedIds([node.id]);
            setPromptDraft("");
          }}
        />
        <MiniMap nodes={documentState.nodes} viewport={viewport} onFocus={fit} />
      </div>
    </AppShell>
  );
}

function CanvasCard({
  node,
  selected,
  incoming,
  composerOpen,
  config,
  onPointerDown,
  onSelect,
  onConnect,
  editing,
  onEdit,
  onText,
  onPatch,
  onGenerate,
  onUpload,
}: {
  node: CanvasNode;
  selected: boolean;
  incoming: number;
  composerOpen: boolean;
  config: AppConfig;
  onPointerDown: (event: ReactPointerEvent<HTMLElement>) => void;
  onSelect: () => void;
  onConnect: (event: ReactPointerEvent<HTMLButtonElement>) => void;
  editing: boolean;
  onEdit: () => void;
  onText: (text: string) => void;
  onPatch: (patch: Partial<CanvasNode>) => void;
  onGenerate: () => void;
  onUpload: () => void;
}) {
  const busy = node.status === "queued" || node.status === "running";
  return (
    <article
      data-node-id={node.id}
      data-drag-handle="true"
      className={cn("canvas-node absolute cursor-grab rounded-[18px] border bg-[#1b1b1b] active:cursor-grabbing", selected ? "border-white/80" : "border-white/12")}
      style={{ left: node.x, top: node.y, width: node.width, height: node.height }}
      onPointerDown={(event) => {
        if (node.kind === "image" && event.button === 0) onSelect();
        onPointerDown(event);
      }}
      onDoubleClick={(event) => {
        if (node.kind !== "text") return;
        event.stopPropagation();
        onEdit();
      }}
    >
      <div className="pointer-events-none absolute -top-7 left-0 flex h-6 items-center gap-1.5 text-xs text-white/58">
        {node.kind === "text" ? <IconText2 className="size-3.5" /> : <IconImages2 className="size-3.5" />}
        <span>{node.kind === "text" ? "文本" : node.kind === "upload" ? "上传" : "图片"}{incoming > 0 ? ` ${incoming}` : ""}</span>
      </div>
      <div className="h-full overflow-hidden rounded-[17px]">
        {node.kind === "text" ? (
          editing ? (
            <textarea
              autoFocus
              value={node.text}
              placeholder="双击编辑文本"
              className="h-full w-full resize-none bg-transparent px-4 py-4 text-sm leading-6 text-white outline-none placeholder:text-white/32"
              onChange={(event) => onText(event.target.value)}
              onPointerDown={(event) => event.stopPropagation()}
              onBlur={() => onEdit()}
            />
          ) : (
            <div className="flex h-full items-start whitespace-pre-wrap px-4 py-4 text-sm leading-6 text-white/82">
              {node.text.trim() || <span className="text-white/32">双击编辑文本</span>}
            </div>
          )
        ) : node.imageUrl ? (
          <img src={node.imageUrl} alt="" className="pointer-events-none h-full w-full bg-black/20 object-contain" draggable={false} />
        ) : (
          <div className="grid h-full place-items-center text-white/28">
            <IconImages2 className="size-6" />
          </div>
        )}
        {busy && <div className="pointer-events-none absolute inset-0 grid place-items-center bg-black/35 text-xs text-white">生成中</div>}
        {node.error && <p className="absolute inset-x-3 bottom-3 text-xs leading-5 text-[#ffb4b4]">{node.error}</p>}
      </div>
      {node.kind !== "upload" && <Port side="input" />}
      <Port side="output" onPointerDown={onConnect} />
    </article>
  );
}

function CanvasComposer({
  node,
  nodes,
  edges,
  config,
  onPatch,
  onGenerate,
  onRemoveReference,
}: {
  node: CanvasNode;
  nodes: CanvasNode[];
  edges: CanvasEdge[];
  config: AppConfig;
  onPatch: (patch: Partial<CanvasNode>) => void;
  onGenerate: () => void;
  onRemoveReference: (sourceId: string) => void;
}) {
  const formRef = useRef<HTMLFormElement | null>(null);
  const panelRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const references = referenceSourcesForNode(nodes, edges, node.id);
  const [width, height] = sizeForRatioResolution(node.aspectRatio, node.resolution);
  const form: GenerateForm = {
    prompt: promptForNode(nodes, edges, node.id),
    model: node.model || config.model || DEFAULT_IMAGE_MODEL,
    aspectRatio: node.aspectRatio,
    resolution: node.resolution,
    width,
    height,
    quality: node.quality,
    quantity: node.quantity,
    outputFormat: "png",
    compression: 100,
  };
  return (
    <ComposerPanel
        formRef={formRef}
        panelRef={panelRef}
        layoutMode="canvas-card"
        form={form}
        config={config}
        loading={node.status === "queued" || node.status === "running"}
        referencePreparing={false}
        optimizing={false}
        providerConfigured
        modelProviders={[]}
        selectedModelProviderId={null}
        onModelProviderChange={() => undefined}
        showReferenceCarryoverHint={false}
        referenceImages={references.map((item, index) => ({ file: new File([], item.imageName || `参考图 ${index + 1}`), url: item.imageUrl || "", name: `参考图 ${index + 1}` }))}
        sourceImagePreview={null}
        referenceMask={null}
        localEditPreviewUrl={null}
        textareaRef={textareaRef}
        referenceInputRef={fileRef}
        onSubmit={(event) => {
          event.preventDefault();
          onGenerate();
        }}
        onPromptPaste={() => undefined}
        onReferenceInput={() => undefined}
        onPickReference={() => undefined}
        onRemoveSourceReference={() => undefined}
        onRemoveReference={(index) => {
          const source = references[index];
          if (!source) return;
          onRemoveReference(source.id);
        }}
        onOptimize={() => undefined}
        onUpdate={(key, value) => {
          const next = updateGenerateForm(form, key, value);
          onPatch({
            text: next.prompt,
            model: next.model,
            aspectRatio: next.aspectRatio,
            resolution: next.resolution,
            ...cardSizeForRatio(next.aspectRatio, next.resolution),
            quality: next.quality,
            quantity: next.quantity,
          });
        }}
        onConfigureProvider={() => undefined}
        turnstileToken=""
        onTurnstileToken={() => undefined}
      />
  );
}

function Port({ side, onPointerDown }: { side: "input" | "output"; onPointerDown?: (event: ReactPointerEvent<HTMLButtonElement>) => void }) {
  return (
    <button
      type="button"
      aria-label={side === "input" ? "输入" : "输出"}
      className={cn("absolute top-1/2 grid size-7 -translate-y-1/2 place-items-center rounded-full border border-white/18 bg-[#141414] text-white/72 hover:border-white/50 hover:text-white", side === "input" ? "left-[-42px]" : "right-[-42px]")}
      onPointerDown={onPointerDown}
    >
      <IconPlusSmall className="size-3.5" />
    </button>
  );
}

function CanvasTopBar({ name, zoom, assistantOpen, onAssistant, onName }: { name: string; zoom: number; assistantOpen: boolean; onAssistant: () => void; onName: (name: string) => void }) {
  return (
    <div className="absolute left-4 top-4 z-20 flex h-11 items-center gap-2 rounded-2xl border border-white/10 bg-[#1b1b1b]/92 px-3 shadow-lg backdrop-blur">
      <input aria-label="项目名称" value={name} className="w-36 bg-transparent text-sm text-white outline-none" onChange={(event) => onName(event.target.value)} />
      <span className="text-xs tabular-nums text-white/45">{Math.round(zoom * 100)}%</span>
      <button type="button" aria-label="对话" aria-pressed={assistantOpen} className={cn("grid size-8 place-items-center rounded-lg text-white/62 hover:bg-white/10", assistantOpen && "bg-white/10 text-white")} onClick={onAssistant}>
        <IconBubble5 className="size-4" />
      </button>
    </div>
  );
}

function CanvasToolbar({
  tool,
  canUndo,
  canRedo,
  onTool,
  onAdd,
  onUpload,
  onUndo,
  onRedo,
}: {
  tool: Tool;
  canUndo: boolean;
  canRedo: boolean;
  onTool: (tool: Tool) => void;
  onAdd: (kind: CanvasNodeKind) => void;
  onUpload: () => void;
  onUndo: () => void;
  onRedo: () => void;
}) {
  return (
    <div className="absolute bottom-5 left-1/2 z-20 flex -translate-x-1/2 items-center gap-1 rounded-2xl border border-white/10 bg-[#1b1b1b]/94 p-1.5 shadow-2xl backdrop-blur">
      <ToolButton label="选择" active={tool === "select"} onClick={() => onTool("select")}><IconCursor1 className="size-4" /></ToolButton>
      <ToolButton label="抓手" active={tool === "pan"} onClick={() => onTool("pan")}><IconPan className="size-4" /></ToolButton>
      <span className="mx-1 h-5 w-px bg-white/10" />
      <ToolButton label="文字" onClick={() => onAdd("text")}><IconText2 className="size-4" /></ToolButton>
      <ToolButton label="图片" onClick={() => onAdd("image")}><IconImages2 className="size-4" /></ToolButton>
      <ToolButton label="上传" onClick={onUpload}><IconCloudUpload className="size-4" /></ToolButton>
      <span className="mx-1 h-5 w-px bg-white/10" />
      <ToolButton label="撤销" disabled={!canUndo} onClick={onUndo}><IconArrowCornerUpLeft className="size-4" /></ToolButton>
      <ToolButton label="重做" disabled={!canRedo} onClick={onRedo}><IconArrowCornerDownRight className="size-4" /></ToolButton>
    </div>
  );
}

function ToolButton({ label, active, disabled, onClick, children }: { label: string; active?: boolean; disabled?: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button type="button" aria-label={label} title={label} disabled={disabled} className={cn("flex h-9 items-center gap-1.5 rounded-xl px-2.5 text-xs text-white/72 hover:bg-white/10 disabled:opacity-35", active && "bg-white/12 text-white")} onClick={onClick}>
      {children}
      <span className="hidden sm:inline">{label}</span>
    </button>
  );
}

function ZoomControl({ zoom, onZoomOut, onZoomIn, onFit }: { zoom: number; onZoomOut: () => void; onZoomIn: () => void; onFit: () => void }) {
  return (
    <div className="absolute bottom-5 left-4 z-20 flex items-center gap-1 rounded-2xl border border-white/10 bg-[#1b1b1b]/94 p-1 shadow-lg">
      <ToolButton label="缩小" onClick={onZoomOut}><IconFocusZoomOut className="size-4" /></ToolButton>
      <span className="w-12 text-center text-xs text-white/70">{Math.round(zoom * 100)}%</span>
      <ToolButton label="放大" onClick={onZoomIn}><IconFocusZoomIn className="size-4" /></ToolButton>
      <ToolButton label="适应" onClick={onFit}><IconHand5Finger className="size-4" /></ToolButton>
    </div>
  );
}

function Inspector({
  node,
  config,
  onChange,
  onDelete,
  onDuplicate,
}: {
  node: CanvasNode;
  config: AppConfig;
  onChange: (patch: Partial<CanvasNode>) => void;
  onDelete: () => void;
  onDuplicate: () => void;
}) {
  const ratios = config.ratios.length > 0 ? config.ratios : [...RATIO_OPTIONS];
  const qualities = qualityTiersForModel(config.model || DEFAULT_IMAGE_MODEL);
  return (
    <aside className="absolute right-4 top-4 z-20 w-64 rounded-2xl border border-white/10 bg-[#1b1b1b]/94 p-3 shadow-2xl backdrop-blur">
      <div className="mb-3 flex items-center justify-between">
        <p className="text-sm text-white/88">节点</p>
        <div className="flex gap-1">
          <button type="button" aria-label="复制节点" className="rounded-lg px-2 py-1 text-xs text-white/60 hover:bg-white/10" onClick={onDuplicate}>复制</button>
          <button type="button" aria-label="删除节点" className="rounded-lg p-1 text-white/60 hover:bg-white/10" onClick={onDelete}><IconTrashCan className="size-3.5" /></button>
        </div>
      </div>
      {node.kind !== "upload" && (
        <div className="space-y-2">
          <Field label="比例">
            <select aria-label="比例" className="canvas-select" value={node.aspectRatio} onChange={(event) => onChange({ aspectRatio: event.target.value })}>
              {ratios.map((ratio) => <option key={ratio} value={ratio}>{ratio}</option>)}
            </select>
          </Field>
          <Field label="清晰度">
            <select aria-label="清晰度" className="canvas-select" value={node.resolution} onChange={(event) => onChange({ resolution: event.target.value })}>
              {RESOLUTION_OPTIONS.map((item) => <option key={item} value={item}>{item}</option>)}
            </select>
          </Field>
          <Field label="质量">
            <select aria-label="质量" className="canvas-select" value={node.quality} onChange={(event) => onChange({ quality: event.target.value })}>
              {qualities.map((item) => <option key={item} value={item}>{QUALITY_LABELS[item] ?? item}</option>)}
            </select>
          </Field>
          <Field label="数量">
            <input aria-label="数量" className="canvas-select" type="number" min={1} max={4} value={node.quantity} onChange={(event) => onChange({ quantity: clampQuantity(event.target.value) })} />
          </Field>
          <p className="pt-1 text-xs text-white/38">{imageModelLabel(config.model || DEFAULT_IMAGE_MODEL)}</p>
        </div>
      )}
      {node.kind === "upload" && <p className="text-xs leading-5 text-white/48">上传节点作为参考图。把它的输出连到图片节点后，生成时会带上这张图。</p>}
    </aside>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="flex items-center justify-between gap-3 text-xs text-white/55">
      <span>{label}</span>
      {children}
    </label>
  );
}

function CanvasMenu({
  menu,
  canChain,
  onAdd,
  onUpload,
  onClose,
}: {
  menu: NonNullable<MenuState>;
  canChain: boolean;
  onAdd: (kind: CanvasNodeKind, point: CanvasPoint) => void;
  onUpload: () => void;
  onClose: () => void;
}) {
  return (
    <div className="fixed z-30 min-w-40 rounded-xl border border-white/10 bg-[#202020] p-1 shadow-2xl" style={{ left: menu.x, top: menu.y }}>
      <MenuItem label={canChain ? "连接到文字" : "文字节点"} onClick={() => onAdd("text", menu.canvas)} />
      <MenuItem label={canChain ? "连接到图片" : "图片节点"} onClick={() => onAdd("image", menu.canvas)} />
      {!canChain && <MenuItem label="上传图片" onClick={onUpload} />}
      <MenuItem label="关闭" onClick={onClose} />
    </div>
  );
}

function MenuItem({ label, onClick }: { label: string; onClick: () => void }) {
  return <button type="button" className="block w-full rounded-lg px-3 py-2 text-left text-sm text-white/82 hover:bg-white/10" onClick={onClick}>{label}</button>;
}

function readStoredCanvas(): CanvasDocument {
  if (typeof window === "undefined") return emptyCanvasDocument();
  return parseCanvasDocument(window.localStorage.getItem(STORAGE_KEY)) ?? emptyCanvasDocument();
}

function localPoint(event: { clientX: number; clientY: number }, surface: HTMLElement | null): CanvasPoint {
  return clientToLocal(event, surface);
}

function clientToLocal(event: { clientX: number; clientY: number }, surface: HTMLElement | null): CanvasPoint {
  const bounds = surface?.getBoundingClientRect();
  return { x: event.clientX - (bounds?.left ?? 0), y: event.clientY - (bounds?.top ?? 0) };
}

function pointInsideNode(point: CanvasPoint, node: CanvasNode): boolean {
  return point.x >= node.x && point.x <= node.x + node.width && point.y >= node.y && point.y <= node.y + node.height;
}

function rectStyle(rect: CanvasRect): CSSProperties {
  return { left: rect.x, top: rect.y, width: rect.width, height: rect.height };
}

function normalizeDisplayedRect(rect: CanvasRect): CanvasRect {
  return {
    x: rect.width < 0 ? rect.x + rect.width : rect.x,
    y: rect.height < 0 ? rect.y + rect.height : rect.y,
    width: Math.abs(rect.width),
    height: Math.abs(rect.height),
  };
}

function statusLabel(status: CanvasNode["status"]): string {
  if (status === "queued" || status === "running") return "生成中";
  if (status === "succeeded") return "完成";
  if (status === "failed") return "失败";
  return "";
}

function isTypingTarget(target: EventTarget | null): boolean {
  if (!(target instanceof HTMLElement)) return false;
  return target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target.isContentEditable;
}

function clampQuantity(value: string): number {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return 1;
  return Math.min(4, Math.max(1, Math.round(parsed)));
}

async function canvasGenerationBody(form: Record<string, string | number>, references: CanvasNode[]): Promise<BodyInit> {
  const files = (await Promise.all(references.map(nodeToReferenceFile))).filter((file): file is File => Boolean(file)).slice(0, 6);
  if (files.length === 0) return JSON.stringify(form);
  const body = new FormData();
  Object.entries(form).forEach(([key, value]) => body.set(key, String(value)));
  files.forEach((file) => body.append("referenceImage", file, file.name));
  return body;
}

async function nodeToReferenceFile(node: CanvasNode): Promise<File | null> {
  if (!node.imageUrl) return null;
  if (node.imageUrl.startsWith("blob:")) {
    const response = await fetch(node.imageUrl);
    const blob = await response.blob();
    return new File([blob], node.imageName || "reference.png", { type: blob.type || "image/png" });
  }
  const response = await fetch(node.imageUrl);
  const blob = await response.blob();
  return new File([blob], node.imageName || "reference.png", { type: blob.type || "image/png" });
}

function applyGenerationResults(
  document: CanvasDocument,
  results: Array<{ nodeId: string; job: GenerationJob; images: ImageItem[] }>,
): CanvasDocument {
  if (results.length === 0) return document;
  let changed = false;
  const nodes = document.nodes.map((node) => {
    const result = results.find((item) => item.nodeId === node.id);
    if (!result) return node;
    const image = result.images[0];
    const status = generationStatus(result.job.status);
    const next = {
      ...node,
      status,
      imageUrl: image?.url ?? node.imageUrl,
      sourceImageId: image?.id ?? node.sourceImageId,
      error: result.job.error_message ?? undefined,
      height: image ? Math.max(node.height, 280) : node.height,
      width: node.width || CANVAS_NODE_WIDTH,
    };
    if (JSON.stringify(next) !== JSON.stringify(node)) changed = true;
    return next;
  });
  return changed ? { ...document, nodes } : document;
}

function generationStatus(status: GenerationJob["status"]): CanvasNode["status"] {
  if (status === "queued") return "queued";
  if (status === "running") return "running";
  if (status === "succeeded" || status === "partial_succeeded") return "succeeded";
  if (status === "failed" || status === "cancelled") return "failed";
  return "idle";
}

export function canvasStorageKey() {
  return STORAGE_KEY;
}
