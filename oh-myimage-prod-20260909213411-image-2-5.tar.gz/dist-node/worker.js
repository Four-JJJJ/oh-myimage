// src/node/worker.ts
import { Worker } from "bullmq";

// src/node/env.ts
import "dotenv/config";

// src/node/postgres-d1.ts
import { Pool } from "pg";
function createPostgresDatabase(connectionString) {
  const pool = new Pool({
    connectionString,
    max: Number(process.env.POSTGRES_POOL_SIZE ?? 10),
    idleTimeoutMillis: 3e4,
    connectionTimeoutMillis: 1e4
  });
  return new PostgresD1Database(pool);
}
var PostgresD1Database = class {
  constructor(pool) {
    this.pool = pool;
  }
  pool;
  prepare(query) {
    return new PostgresPreparedStatement(this.pool, query);
  }
  async close() {
    await this.pool.end();
  }
};
var PostgresPreparedStatement = class {
  constructor(pool, query) {
    this.pool = pool;
    this.query = query;
  }
  pool;
  query;
  values = [];
  bind(...values) {
    this.values = values;
    return this;
  }
  async first() {
    const result = await this.pool.query(translateSql(this.query), this.values);
    return normalizeRow(result.rows[0]);
  }
  async all() {
    const result = await this.pool.query(translateSql(this.query), this.values);
    return { results: result.rows.map((row) => normalizeRow(row)) };
  }
  async run() {
    const result = await this.pool.query(translateSql(this.query), this.values);
    return { success: true, meta: { changes: result.rowCount ?? 0 } };
  }
};
function translateSql(query) {
  const normalized = query.replace(
    /\bCURRENT_TIMESTAMP\b/g,
    "to_char(NOW() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')"
  );
  let index = 0;
  let inSingleQuote = false;
  let output = "";
  for (let i = 0; i < normalized.length; i += 1) {
    const char = normalized[i];
    const next = normalized[i + 1];
    if (char === "'" && next === "'") {
      output += "''";
      i += 1;
      continue;
    }
    if (char === "'") {
      inSingleQuote = !inSingleQuote;
      output += char;
      continue;
    }
    if (char === "?" && !inSingleQuote) {
      index += 1;
      output += `$${index}`;
      continue;
    }
    output += char;
  }
  return output;
}
function normalizeRow(row) {
  if (!row || typeof row !== "object") return row ?? null;
  const record = row;
  for (const [key, value] of Object.entries(record)) {
    if ((key === "count" || key.endsWith("_count")) && typeof value === "string") {
      const numberValue = Number(value);
      if (Number.isFinite(numberValue)) record[key] = numberValue;
    }
  }
  return record;
}

// src/node/queue.ts
import { Queue } from "bullmq";
import IORedis from "ioredis";
var GENERATION_QUEUE_NAME = process.env.BULLMQ_GENERATION_QUEUE_NAME ?? "oh-myimage-generation";
var INSPIRATION_QUEUE_NAME = process.env.BULLMQ_INSPIRATION_QUEUE_NAME ?? "oh-myimage-inspiration";
function createRedisConnection(redisUrl2) {
  return new IORedis(redisUrl2, {
    maxRetriesPerRequest: null,
    enableReadyCheck: false
  });
}
function createBullQueues(config) {
  const connection = createRedisConnection(config.redisUrl);
  const generation = new Queue(GENERATION_QUEUE_NAME, { connection });
  const inspiration = new Queue(INSPIRATION_QUEUE_NAME, { connection });
  return {
    generationQueue: new BullAppQueue(generation, "generation", {
      attempts: config.generationAttempts,
      backoff: { type: "fixed", delay: config.generationBackoffMs }
    }),
    inspirationQueue: new BullAppQueue(inspiration, "inspiration", {
      attempts: 1
    }),
    async close() {
      await Promise.all([generation.close(), inspiration.close()]);
      connection.disconnect();
    }
  };
}
var BullAppQueue = class {
  constructor(queue, name, defaults) {
    this.queue = queue;
    this.name = name;
    this.defaults = defaults;
  }
  queue;
  name;
  defaults;
  async send(message) {
    await this.queue.add(this.name, message, {
      attempts: this.defaults.attempts,
      backoff: this.defaults.backoff,
      removeOnComplete: 1e3,
      removeOnFail: 5e3
    });
  }
};

// src/node/r2-store.ts
import { Readable } from "node:stream";
import { CopyObjectCommand, DeleteObjectCommand, GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
function createR2Store(config) {
  const endpoint = resolveR2Endpoint(config);
  const client = new S3Client({
    region: "auto",
    endpoint,
    forcePathStyle: true,
    credentials: {
      accessKeyId: config.accessKeyId,
      secretAccessKey: config.secretAccessKey
    }
  });
  return new S3ObjectStore(client, config.bucket);
}
function resolveR2Endpoint(config) {
  const explicitEndpoint = config.endpoint?.trim();
  if (explicitEndpoint) return explicitEndpoint;
  const accountId = config.accountId?.trim();
  if (!accountId) {
    throw new Error("R2 account ID is required when R2_ENDPOINT is not set.");
  }
  return `https://${accountId}.r2.cloudflarestorage.com`;
}
var S3ObjectStore = class {
  constructor(client, bucket) {
    this.client = client;
    this.bucket = bucket;
  }
  client;
  bucket;
  async put(key, value, options) {
    await this.client.send(
      new PutObjectCommand({
        Bucket: this.bucket,
        Key: key,
        Body: await toS3Body(value),
        ContentType: options?.httpMetadata?.contentType,
        ContentDisposition: options?.httpMetadata?.contentDisposition,
        Metadata: options?.customMetadata
      })
    );
    return {};
  }
  async get(key) {
    try {
      const result = await this.client.send(new GetObjectCommand({ Bucket: this.bucket, Key: key }));
      if (!result.Body) return null;
      return new S3Object(result);
    } catch (error) {
      const name = error instanceof Error ? error.name : "";
      if (name === "NoSuchKey" || name === "NotFound") return null;
      throw error;
    }
  }
  async copy(sourceKey, destinationKey, options) {
    await this.client.send(
      new CopyObjectCommand({
        Bucket: this.bucket,
        Key: destinationKey,
        CopySource: s3CopySource(this.bucket, sourceKey),
        ContentType: options?.httpMetadata?.contentType,
        ContentDisposition: options?.httpMetadata?.contentDisposition,
        Metadata: options?.customMetadata,
        MetadataDirective: "REPLACE"
      })
    );
    return {};
  }
  async delete(key) {
    await this.client.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
  }
  async createPresignedGetUrl(key, options) {
    const command = new GetObjectCommand({
      Bucket: this.bucket,
      Key: key,
      ResponseContentType: options?.contentType,
      ResponseContentDisposition: options?.contentDisposition
    });
    return getSignedUrl(this.client, command, { expiresIn: options?.expiresInSeconds ?? 300 });
  }
};
function s3CopySource(bucket, key) {
  return `${bucket}/${key.split("/").map(encodeURIComponent).join("/")}`;
}
var S3Object = class {
  constructor(result) {
    this.result = result;
    this.httpMetadata = {
      contentType: result.ContentType,
      contentDisposition: result.ContentDisposition
    };
  }
  result;
  httpMetadata;
  get body() {
    const body = this.result.Body;
    return body ? toWebStream(body) : null;
  }
  async arrayBuffer() {
    const body = this.result.Body;
    if (body && typeof body.transformToByteArray === "function") {
      const bytes = await body.transformToByteArray();
      return toArrayBuffer(bytes);
    }
    if (!this.body) return new ArrayBuffer(0);
    return new Response(this.body).arrayBuffer();
  }
};
async function toS3Body(value) {
  if (typeof value === "string") return value;
  if (value instanceof Blob) return Buffer.from(await value.arrayBuffer());
  if (value instanceof ArrayBuffer) return Buffer.from(value);
  if (ArrayBuffer.isView(value)) return Buffer.from(value.buffer, value.byteOffset, value.byteLength);
  return Readable.fromWeb(value);
}
function toWebStream(body) {
  if (typeof body.transformToWebStream === "function") {
    return body.transformToWebStream();
  }
  if (body instanceof Readable) return Readable.toWeb(body);
  throw new Error("Unsupported S3 response body stream.");
}
function toArrayBuffer(bytes) {
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  return copy.buffer;
}

// src/worker/http.ts
import { HTTPException } from "hono/http-exception";
function jsonError(status, code, message) {
  return new HTTPException(status, {
    message,
    res: Response.json({ ok: false, error: { code, message } }, { status })
  });
}
function envNumber(value, fallback) {
  if (!value) return fallback;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}
function redactSecrets(value) {
  return value.replace(/Bearer\s+[A-Za-z0-9._~+/=-]+/gi, "Bearer [redacted]").replace(/sk-[A-Za-z0-9._-]+/gi, "sk-[redacted]").replace(/Authorization["']?\s*:\s*["'][^"']+["']/gi, "Authorization: [redacted]");
}
function daysFromNow(days) {
  return new Date(Date.now() + days * 24 * 60 * 60 * 1e3).toISOString();
}
function randomId(prefix) {
  return `${prefix}_${crypto.randomUUID().replaceAll("-", "")}`;
}

// src/node/env.ts
function createNodeRuntime(options = {}) {
  const db = createPostgresDatabase(requiredEnv("DATABASE_URL"));
  const queues = options.queues === false ? null : createBullQueues({
    redisUrl: process.env.REDIS_URL ?? "redis://127.0.0.1:6379",
    generationAttempts: resolveGenerationAttempts(),
    generationBackoffMs: envNumber(process.env.POST_PROCESSING_RETRY_DELAY_SECONDS, 5) * 1e3
  });
  const env = {
    DB: db,
    IMAGES: createR2Store({
      accountId: process.env.R2_ACCOUNT_ID,
      endpoint: process.env.R2_ENDPOINT,
      accessKeyId: requiredEnv("R2_ACCESS_KEY_ID"),
      secretAccessKey: requiredEnv("R2_SECRET_ACCESS_KEY"),
      bucket: requiredEnv("R2_BUCKET")
    }),
    GENERATION_QUEUE: queues?.generationQueue ?? disabledQueue("generation"),
    INSPIRATION_QUEUE: queues?.inspirationQueue ?? disabledQueue("inspiration"),
    APP_ENCRYPTION_KEY: requiredEnv("APP_ENCRYPTION_KEY"),
    TURNSTILE_SECRET_KEY: process.env.TURNSTILE_SECRET_KEY ?? "",
    TURNSTILE_SITE_KEY: process.env.TURNSTILE_SITE_KEY ?? "",
    TURNSTILE_REQUIRED: process.env.TURNSTILE_REQUIRED ?? "false",
    DEFAULT_IMAGE_MODEL: process.env.DEFAULT_IMAGE_MODEL ?? "image-2.5",
    PROMPT_OPTIMIZER_MODEL: process.env.PROMPT_OPTIMIZER_MODEL ?? "gpt-5.5",
    MAX_IMAGES_PER_REQUEST: process.env.MAX_IMAGES_PER_REQUEST ?? "4",
    MAX_RUNNING_JOBS_PER_SPACE: process.env.MAX_RUNNING_JOBS_PER_SPACE ?? "12",
    REQUEST_TIMEOUT_MS: process.env.REQUEST_TIMEOUT_MS ?? "600000",
    GENERATION_JOB_MAX_RUNTIME_MS: process.env.GENERATION_JOB_MAX_RUNTIME_MS ?? "840000",
    PROVIDER_IMAGE_CONCURRENCY: process.env.PROVIDER_IMAGE_CONCURRENCY ?? "2",
    PROVIDER_TIMEOUT_RETRY_ATTEMPTS: process.env.PROVIDER_TIMEOUT_RETRY_ATTEMPTS ?? "0",
    PROVIDER_RETRY_ATTEMPTS: process.env.PROVIDER_RETRY_ATTEMPTS ?? "0",
    PROVIDER_RETRY_DELAY_SECONDS: process.env.PROVIDER_RETRY_DELAY_SECONDS ?? "120",
    POST_PROCESSING_RETRY_ATTEMPTS: process.env.POST_PROCESSING_RETRY_ATTEMPTS ?? "2",
    POST_PROCESSING_RETRY_DELAY_SECONDS: process.env.POST_PROCESSING_RETRY_DELAY_SECONDS ?? "5",
    IMAGE_RETENTION_DAYS: process.env.IMAGE_RETENTION_DAYS ?? "90",
    X_BEARER_TOKEN: process.env.X_BEARER_TOKEN ?? "",
    INSPIRATION_FEATURE_ENABLED: process.env.INSPIRATION_FEATURE_ENABLED ?? "false",
    INSPIRATION_MAX_ITEMS_PER_RUN: process.env.INSPIRATION_MAX_ITEMS_PER_RUN ?? "12",
    INSPIRATION_THUMBNAIL_MAX_BYTES: process.env.INSPIRATION_THUMBNAIL_MAX_BYTES ?? "1048576",
    INSPIRATION_AUTO_PUBLISH_SOURCES: process.env.INSPIRATION_AUTO_PUBLISH_SOURCES ?? "civitai"
  };
  return {
    env,
    async close() {
      await Promise.all([closeDatabase(db), closeQueues(queues)]);
    }
  };
}
function requiredEnv(name) {
  const value = process.env[name]?.trim();
  if (!value) throw new Error(`${name} is required.`);
  return value;
}
function resolveGenerationAttempts() {
  return resolveGenerationQueueAttempts(process.env.PROVIDER_RETRY_ATTEMPTS, process.env.POST_PROCESSING_RETRY_ATTEMPTS);
}
function resolveGenerationQueueAttempts(providerValue, postProcessingValue) {
  return Math.max(1, Math.trunc(Math.max(envNumber(providerValue, 0), envNumber(postProcessingValue, 2))) + 1);
}
function disabledQueue(name) {
  return {
    async send() {
      throw new Error(`${name} queue is disabled in this process.`);
    }
  };
}
async function closeDatabase(db) {
  await db.close();
}
async function closeQueues(queues) {
  if (queues) await queues.close();
}

// src/worker/crypto.ts
var encoder = new TextEncoder();
var decoder = new TextDecoder();
var PASSWORD_ITERATIONS = 1e5;
function bytesToBase64(bytes) {
  let binary = "";
  for (let i = 0; i < bytes.length; i += 32768) {
    binary += String.fromCharCode(...bytes.subarray(i, i + 32768));
  }
  return btoa(binary);
}
function base64ToBytes(value) {
  const binary = atob(value);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return bytes;
}
function bytesToBase64Url(bytes) {
  return bytesToBase64(bytes).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}
function base64UrlToBytes(value) {
  const padded = value.replaceAll("-", "+").replaceAll("_", "/").padEnd(Math.ceil(value.length / 4) * 4, "=");
  return base64ToBytes(padded);
}
function randomBytes(length) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return bytes;
}
async function sha256Hex(input) {
  const bytes = typeof input === "string" ? encoder.encode(input) : input;
  const digest = await crypto.subtle.digest("SHA-256", toArrayBuffer2(bytes));
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
async function passwordKey(password) {
  return crypto.subtle.importKey("raw", toArrayBuffer2(encoder.encode(password)), "PBKDF2", false, ["deriveBits"]);
}
async function hashPassword(password) {
  const salt = randomBytes(16);
  const key = await passwordKey(password);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt: toArrayBuffer2(salt), iterations: PASSWORD_ITERATIONS },
    key,
    256
  );
  return `pbkdf2$${PASSWORD_ITERATIONS}$${bytesToBase64Url(salt)}$${bytesToBase64Url(new Uint8Array(bits))}`;
}
async function verifyPassword(password, stored) {
  const [scheme, iterationText, saltText, hashText] = stored.split("$");
  if (scheme !== "pbkdf2" || !iterationText || !saltText || !hashText) return false;
  const iterations = Number(iterationText);
  if (!Number.isInteger(iterations) || iterations < 5e4) return false;
  const salt = base64UrlToBytes(saltText);
  const expected = base64UrlToBytes(hashText);
  const key = await passwordKey(password);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt: toArrayBuffer2(salt), iterations },
    key,
    256
  );
  return timingSafeEqual(new Uint8Array(bits), expected);
}
function timingSafeEqual(left, right) {
  if (left.length !== right.length) return false;
  let diff = 0;
  for (let index = 0; index < left.length; index += 1) {
    diff |= left[index] ^ right[index];
  }
  return diff === 0;
}
async function aesKey(secret) {
  if (!secret || secret.length < 16) {
    throw new Error("APP_ENCRYPTION_KEY \u81F3\u5C11\u9700\u8981 16 \u4E2A\u5B57\u7B26\u3002");
  }
  const digest = await crypto.subtle.digest("SHA-256", encoder.encode(secret));
  return crypto.subtle.importKey("raw", digest, "AES-GCM", false, ["encrypt", "decrypt"]);
}
async function encryptSecret(plainText, secret) {
  const iv = randomBytes(12);
  const key = await aesKey(secret);
  const encrypted = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: toArrayBuffer2(iv) },
    key,
    toArrayBuffer2(encoder.encode(plainText))
  );
  return `v1.${bytesToBase64Url(iv)}.${bytesToBase64Url(new Uint8Array(encrypted))}`;
}
async function decryptSecret(payload, secret) {
  const [version, ivText, cipherText] = payload.split(".");
  if (version !== "v1" || !ivText || !cipherText) {
    throw new Error("\u5BC6\u94A5\u5BC6\u6587\u683C\u5F0F\u4E0D\u6B63\u786E\u3002");
  }
  const key = await aesKey(secret);
  const decrypted = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: toArrayBuffer2(base64UrlToBytes(ivText)) },
    key,
    toArrayBuffer2(base64UrlToBytes(cipherText))
  );
  return decoder.decode(decrypted);
}
function makeSessionToken() {
  return bytesToBase64Url(randomBytes(32));
}
function apiKeyHint(apiKey) {
  if (apiKey.length <= 8) return "configured";
  return `${apiKey.slice(0, 4)}...${apiKey.slice(-4)}`;
}
function bytesFromBase64(value) {
  return base64ToBytes(value);
}
function toArrayBuffer2(bytes) {
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
}

// src/worker/inspiration.ts
var DEFAULT_MAX_ITEMS_PER_RUN = 12;
var DEFAULT_THUMBNAIL_MAX_BYTES = 1048576;
var IMPORT_USER_AGENT = "oh-myimage-inspiration/1.0 (+https://workers.cloudflare.com)";
function normalizeInspirationUrl(rawUrl) {
  let url;
  try {
    url = new URL(rawUrl.trim());
  } catch {
    throw new Error("\u8BF7\u8F93\u5165\u6709\u6548\u7684 URL\u3002");
  }
  if (url.protocol !== "https:") throw new Error("\u7075\u611F\u6765\u6E90\u94FE\u63A5\u5FC5\u987B\u4F7F\u7528 HTTPS\u3002");
  if (isBlockedHostname(url.hostname)) throw new Error("\u4E0D\u652F\u6301\u5BFC\u5165\u5185\u7F51\u3001\u672C\u673A\u6216 IP \u5730\u5740\u94FE\u63A5\u3002");
  url.hash = "";
  const hostname = url.hostname.toLowerCase();
  if (hostname === "x.com" || hostname.endsWith(".x.com") || hostname === "twitter.com" || hostname.endsWith(".twitter.com")) {
    const tweetId = extractTweetId(url);
    if (!tweetId) throw new Error("X \u94FE\u63A5\u9700\u8981\u6307\u5411\u5177\u4F53\u63A8\u6587\u3002");
    return { normalizedUrl: canonicalTweetUrl(tweetId, url.pathname), sourceKey: "x", tweetId };
  }
  if (hostname.includes("jimeng") || hostname.includes("jianying")) {
    return { normalizedUrl: url.toString(), sourceKey: "jimeng" };
  }
  return { normalizedUrl: url.toString(), sourceKey: "generic" };
}
async function listInspirations(db, spaceId, filters) {
  const conditions = ["items.status = 'published'"];
  const values = [spaceId];
  if (filters.q?.trim()) {
    const term = `%${escapeLike(filters.q.trim())}%`;
    conditions.push("(items.prompt LIKE ? ESCAPE '\\' OR items.title LIKE ? ESCAPE '\\' OR items.author LIKE ? ESCAPE '\\' OR items.tags_json LIKE ? ESCAPE '\\')");
    values.push(term, term, term, term);
  }
  if (filters.source?.trim()) {
    conditions.push("sources.source_key = ?");
    values.push(filters.source.trim());
  }
  if (filters.tag?.trim()) {
    conditions.push("items.tags_json LIKE ? ESCAPE '\\'");
    values.push(`%${escapeLike(filters.tag.trim())}%`);
  }
  if (filters.favorites) {
    conditions.push("favorites.item_id IS NOT NULL");
  }
  if (filters.cursor?.trim()) {
    conditions.push("items.imported_at < ?");
    values.push(filters.cursor.trim());
  }
  const result = await db.prepare(
    `SELECT
        items.*,
        sources.source_key,
        sources.name AS source_name,
        CASE WHEN favorites.item_id IS NULL THEN 0 ELSE 1 END AS favorite
       FROM inspiration_items items
       INNER JOIN inspiration_sources sources ON sources.id = items.source_id
       LEFT JOIN inspiration_favorites favorites ON favorites.item_id = items.id AND favorites.space_id = ?
       WHERE ${conditions.join(" AND ")}
       ORDER BY items.imported_at DESC, items.id DESC
       LIMIT 31`
  ).bind(...values).all();
  const rows = result.results ?? [];
  const items = rows.slice(0, 30);
  return {
    items,
    nextCursor: rows.length > 30 ? items[items.length - 1]?.imported_at ?? null : null
  };
}
async function getInspirationItem(db, itemId) {
  return db.prepare(
    `SELECT items.*, sources.source_key, sources.name AS source_name
       FROM inspiration_items items
       INNER JOIN inspiration_sources sources ON sources.id = items.source_id
       WHERE items.id = ?`
  ).bind(itemId).first();
}
async function toggleInspirationFavorite(db, spaceId, itemId, favorite) {
  const item = await db.prepare("SELECT id FROM inspiration_items WHERE id = ? AND status = 'published'").bind(itemId).first();
  if (!item) throw new Error("\u7075\u611F\u7D20\u6750\u4E0D\u5B58\u5728\u3002");
  const existing = await db.prepare("SELECT id FROM inspiration_favorites WHERE space_id = ? AND item_id = ?").bind(spaceId, itemId).first();
  const next = favorite ?? !existing;
  if (next && !existing) {
    await db.prepare("INSERT INTO inspiration_favorites (id, space_id, item_id) VALUES (?, ?, ?)").bind(randomId("fav"), spaceId, itemId).run();
  } else if (!next && existing) {
    await db.prepare("DELETE FROM inspiration_favorites WHERE space_id = ? AND item_id = ?").bind(spaceId, itemId).run();
  }
  return next;
}
async function recordInspirationUse(db, itemId) {
  await db.prepare("UPDATE inspiration_items SET use_count = use_count + 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(itemId).run();
}
async function importInspirationUrl(env, input) {
  const normalized = normalizeInspirationUrl(input.url);
  const source = await getOrCreateSource(env.DB, normalized.sourceKey);
  const runId = await startImportRun(env.DB, source, "manual");
  try {
    const candidate = normalized.sourceKey === "x" ? await importXUrl(env, normalized, input) : await importGenericUrl(normalized, input, normalized.sourceKey === "jimeng");
    const result = await upsertInspirationCandidate(env, source, {
      ...candidate,
      prompt: candidate.prompt ?? input.prompt,
      title: input.title ?? candidate.title,
      author: input.author ?? candidate.author,
      tags: mergeTags(candidate.tags, input.tags),
      status: "published"
    });
    await finishImportRun(env.DB, runId, "succeeded", 1, result.inserted ? 1 : 0);
    const item = await getInspirationItem(env.DB, result.itemId);
    if (!item) throw new Error("\u5BFC\u5165\u540E\u672A\u627E\u5230\u7075\u611F\u7D20\u6750\u3002");
    return item;
  } catch (error) {
    await finishImportRun(env.DB, runId, "failed", 0, 0, redactSecrets(error instanceof Error ? error.message : "\u5BFC\u5165\u5931\u8D25\u3002"));
    throw error;
  }
}
async function processInspirationSourceMessage(message, env) {
  const source = await env.DB.prepare("SELECT * FROM inspiration_sources WHERE id = ?").bind(message.sourceId).first();
  if (!source || !source.enabled) return;
  const runId = await startImportRun(env.DB, source, message.trigger);
  try {
    const result = await importSource(env, source);
    await env.DB.prepare("UPDATE inspiration_sources SET last_run_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(source.id).run();
    await finishImportRun(env.DB, runId, "succeeded", result.itemsSeen, result.itemsImported);
  } catch (error) {
    await finishImportRun(
      env.DB,
      runId,
      "failed",
      0,
      0,
      redactSecrets(error instanceof Error ? error.message : "\u91C7\u96C6\u5931\u8D25\u3002")
    );
  }
}
function parseInspirationTags(raw) {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item) => typeof item === "string" && item.trim().length > 0).slice(0, 12);
  } catch {
    return [];
  }
}
async function importSource(env, source) {
  if (source.kind === "civitai") return importCivitaiSource(env, source);
  if (source.kind === "x") return importXSource(env, source);
  if (source.kind === "jimeng" || source.kind === "generic") return importConfiguredPages(env, source);
  return { itemsSeen: 0, itemsImported: 0 };
}
async function importCivitaiSource(env, source) {
  const config = parseConfig(source.config_json);
  const maxItems = sourceLimit(env, config.limit);
  const params = new URLSearchParams({
    limit: String(maxItems),
    nsfw: String(config.nsfw === true ? true : false),
    sort: typeof config.sort === "string" ? config.sort : "Most Reactions",
    period: typeof config.period === "string" ? config.period : "Week"
  });
  const response = await fetch(`https://civitai.com/api/v1/images?${params.toString()}`, {
    headers: { Accept: "application/json", "User-Agent": IMPORT_USER_AGENT }
  });
  if (!response.ok) throw new Error(`Civitai \u8FD4\u56DE ${response.status}\u3002`);
  const json = await response.json();
  const candidates = (json.items ?? []).map(civitaiCandidate).filter((item) => Boolean(item));
  return importCandidates(env, source, candidates);
}
async function importXSource(env, source) {
  if (!env.X_BEARER_TOKEN) throw new Error("X_BEARER_TOKEN \u672A\u914D\u7F6E\uFF0CX \u6765\u6E90\u53EA\u80FD\u624B\u52A8\u5BFC\u5165\u3002");
  const config = parseConfig(source.config_json);
  const query = typeof config.query === "string" && config.query.trim() ? config.query.trim() : "has:images -is:retweet";
  const maxItems = Math.min(sourceLimit(env, config.limit), 100);
  const params = new URLSearchParams({
    query,
    max_results: String(Math.max(10, maxItems)),
    expansions: "attachments.media_keys,author_id",
    "media.fields": "alt_text,height,media_key,preview_image_url,type,url,width",
    "tweet.fields": "attachments,author_id,created_at,text",
    "user.fields": "name,username"
  });
  const response = await fetch(`https://api.x.com/2/tweets/search/recent?${params.toString()}`, {
    headers: { Authorization: `Bearer ${env.X_BEARER_TOKEN}` }
  });
  if (!response.ok) throw new Error(`X API \u8FD4\u56DE ${response.status}\u3002`);
  const json = await response.json();
  const candidates = xCandidates(json).slice(0, maxItems);
  return importCandidates(env, source, candidates);
}
async function importConfiguredPages(env, source) {
  const config = parseConfig(source.config_json);
  const urls = Array.isArray(config.urls) ? config.urls.filter((item) => typeof item === "string") : [];
  const candidates = [];
  for (const rawUrl of urls.slice(0, sourceLimit(env, config.limit))) {
    const normalized = normalizeInspirationUrl(rawUrl);
    candidates.push(await importGenericUrl(normalized, {}, source.kind === "jimeng"));
  }
  return importCandidates(env, source, candidates);
}
async function importCandidates(env, source, candidates) {
  let imported = 0;
  for (const candidate of candidates) {
    const result = await upsertInspirationCandidate(env, source, candidate);
    if (result.inserted) imported += 1;
  }
  return { itemsSeen: candidates.length, itemsImported: imported };
}
async function importXUrl(env, normalized, input) {
  if (env.X_BEARER_TOKEN && normalized.tweetId) {
    try {
      const candidate = await fetchXTweet(env.X_BEARER_TOKEN, normalized.tweetId);
      if (candidate) return { ...candidate, prompt: input.prompt ?? candidate.prompt };
    } catch {
    }
  }
  if (!input.prompt?.trim()) {
    throw new Error("X \u94FE\u63A5\u4E0D\u505A\u7F51\u9875\u6293\u53D6\uFF1B\u672A\u914D\u7F6E\u53EF\u7528 X API \u65F6\uFF0C\u8BF7\u540C\u65F6\u7C98\u8D34\u63D0\u793A\u8BCD\u3002");
  }
  return {
    sourceItemId: normalized.tweetId,
    originalUrl: normalized.normalizedUrl,
    title: input.title ?? "X \u624B\u52A8\u5BFC\u5165",
    author: input.author,
    prompt: input.prompt,
    tags: input.tags,
    safety: "unknown"
  };
}
async function fetchXTweet(token, tweetId) {
  const params = new URLSearchParams({
    expansions: "attachments.media_keys,author_id",
    "media.fields": "alt_text,height,media_key,preview_image_url,type,url,width",
    "tweet.fields": "attachments,author_id,created_at,text",
    "user.fields": "name,username"
  });
  const response = await fetch(`https://api.x.com/2/tweets/${tweetId}?${params.toString()}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!response.ok) throw new Error(`X API \u8FD4\u56DE ${response.status}\u3002`);
  const json = await response.json();
  return xCandidates({ data: json.data ? [json.data] : [], includes: json.includes }).at(0) ?? null;
}
async function importGenericUrl(normalized, input, isJimeng) {
  const response = await fetch(normalized.normalizedUrl, {
    redirect: "manual",
    headers: { Accept: "text/html,image/*", "User-Agent": IMPORT_USER_AGENT }
  });
  if (response.status >= 300 && response.status < 400) {
    throw new Error("\u6765\u6E90\u9875\u9762\u53D1\u751F\u91CD\u5B9A\u5411\uFF0C\u5DF2\u505C\u6B62\u5BFC\u5165\u3002");
  }
  if (!response.ok) throw new Error(`\u6765\u6E90\u9875\u9762\u8FD4\u56DE ${response.status}\u3002`);
  const contentType = response.headers.get("content-type") ?? "";
  if (contentType.startsWith("image/")) {
    return {
      sourceItemId: normalized.normalizedUrl,
      originalUrl: normalized.normalizedUrl,
      title: input.title ?? (isJimeng ? "\u5373\u68A6\u7075\u611F" : "\u56FE\u7247\u5BFC\u5165"),
      author: input.author,
      prompt: input.prompt ?? "",
      originalImageUrl: normalized.normalizedUrl,
      tags: mergeTags(input.tags, [isJimeng ? "\u5373\u68A6" : "\u7F51\u9875\u5BFC\u5165"]),
      safety: "unknown"
    };
  }
  const html = await response.text();
  const title = input.title ?? extractMeta(html, "og:title") ?? extractTitle(html);
  const description = extractMeta(html, "og:description") ?? extractMeta(html, "description") ?? extractMeta(html, "twitter:description");
  const imageUrl = absoluteUrl(
    extractMeta(html, "og:image") ?? extractMeta(html, "twitter:image") ?? extractFirstImage(html),
    normalized.normalizedUrl
  );
  const author = input.author ?? extractMeta(html, "author") ?? extractMeta(html, "article:author");
  return {
    sourceItemId: normalized.normalizedUrl,
    originalUrl: normalized.normalizedUrl,
    title: title ?? (isJimeng ? "\u5373\u68A6\u7075\u611F" : "\u7F51\u9875\u5BFC\u5165"),
    author,
    prompt: input.prompt ?? description ?? "",
    originalImageUrl: imageUrl,
    tags: mergeTags(input.tags, [isJimeng ? "\u5373\u68A6" : "\u7F51\u9875\u5BFC\u5165"]),
    safety: "unknown"
  };
}
async function upsertInspirationCandidate(env, source, candidate) {
  const sourceItemId = candidate.sourceItemId ?? candidate.originalUrl;
  const dedupeKey = await sha256Hex(`${source.source_key}:${sourceItemId}:${candidate.originalImageUrl ?? ""}`.toLowerCase());
  const existing = await env.DB.prepare("SELECT id FROM inspiration_items WHERE dedupe_key = ?").bind(dedupeKey).first();
  if (existing) {
    await env.DB.prepare(
      `UPDATE inspiration_items
         SET title = COALESCE(NULLIF(?, ''), title),
             prompt = CASE WHEN prompt = '' THEN ? ELSE prompt END,
             original_image_url = COALESCE(original_image_url, ?),
             updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`
    ).bind(candidate.title ?? "", candidate.prompt ?? "", candidate.originalImageUrl ?? null, existing.id).run();
    return { itemId: existing.id, inserted: false };
  }
  const thumbnail = candidate.originalImageUrl ? await cacheThumbnail(env, source.source_key, dedupeKey, candidate.originalImageUrl) : null;
  const id = randomId("ins");
  const status = candidate.status ?? (autoPublishSources(env).has(source.source_key) ? "published" : "draft");
  await env.DB.prepare(
    `INSERT INTO inspiration_items (
        id, source_id, source_item_id, original_url, author, title, prompt, negative_prompt,
        thumbnail_storage_key, thumbnail_mime_type, original_image_url, width, height, aspect_ratio,
        tags_json, model, safety, status, dedupe_key
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).bind(
    id,
    source.id,
    sourceItemId,
    candidate.originalUrl,
    candidate.author ?? null,
    candidate.title ?? null,
    candidate.prompt?.trim() ?? "",
    candidate.negativePrompt ?? null,
    thumbnail?.key ?? null,
    thumbnail?.mimeType ?? null,
    candidate.originalImageUrl ?? null,
    candidate.width ?? null,
    candidate.height ?? null,
    aspectRatio(candidate.width, candidate.height),
    JSON.stringify(normalizeTags(candidate.tags)),
    candidate.model ?? null,
    candidate.safety ?? "unknown",
    status,
    dedupeKey
  ).run();
  return { itemId: id, inserted: true };
}
async function cacheThumbnail(env, sourceKey, dedupeKey, imageUrl) {
  let url;
  try {
    url = new URL(imageUrl);
  } catch {
    return null;
  }
  if (url.protocol !== "https:" || isBlockedHostname(url.hostname)) return null;
  const maxBytes = Math.max(64e3, envNumber(env.INSPIRATION_THUMBNAIL_MAX_BYTES, DEFAULT_THUMBNAIL_MAX_BYTES));
  const contentLength2 = Number(await headContentLength(imageUrl));
  if (Number.isFinite(contentLength2) && contentLength2 > maxBytes) return null;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15e3);
  try {
    const response = await fetch(imageUrl, {
      headers: { Accept: "image/avif,image/webp,image/png,image/jpeg,image/gif", Range: `bytes=0-${maxBytes}` },
      signal: controller.signal
    });
    if (!response.ok && response.status !== 206) return null;
    const mimeType = normalizeImageMime(response.headers.get("content-type"));
    if (!mimeType) return null;
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes.byteLength > maxBytes) return null;
    const key = `inspirations/${sourceKey}/${dedupeKey}.${extensionFromMime(mimeType)}`;
    await env.IMAGES.put(key, bytes, {
      httpMetadata: { contentType: mimeType, contentDisposition: `inline; filename="${dedupeKey}.${extensionFromMime(mimeType)}"` }
    });
    return { key, mimeType };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}
async function headContentLength(url) {
  try {
    const response = await fetch(url, { method: "HEAD", redirect: "manual" });
    if (!response.ok) return null;
    return response.headers.get("content-length");
  } catch {
    return null;
  }
}
async function getOrCreateSource(db, sourceKey) {
  const existing = await db.prepare("SELECT * FROM inspiration_sources WHERE source_key = ?").bind(sourceKey).first();
  if (existing) return existing;
  const id = `src_${sourceKey}`;
  const name = sourceKey === "x" ? "X" : sourceKey === "jimeng" ? "\u5373\u68A6\u7075\u611F" : "\u7F51\u9875\u5BFC\u5165";
  const kind = sourceKey === "generic" ? "generic" : sourceKey;
  await db.prepare("INSERT INTO inspiration_sources (id, source_key, name, kind, enabled, config_json) VALUES (?, ?, ?, ?, 0, '{}')").bind(id, sourceKey, name, kind).run();
  const created = await db.prepare("SELECT * FROM inspiration_sources WHERE id = ?").bind(id).first();
  if (!created) throw new Error("\u7075\u611F\u6765\u6E90\u521B\u5EFA\u5931\u8D25\u3002");
  return created;
}
async function startImportRun(db, source, trigger) {
  const id = randomId("run");
  await db.prepare("INSERT INTO inspiration_import_runs (id, source_id, source_key, trigger_type, status) VALUES (?, ?, ?, ?, 'running')").bind(id, source.id, source.source_key, trigger).run();
  return id;
}
async function finishImportRun(db, runId, status, itemsSeen, itemsImported, errorMessage) {
  await db.prepare(
    `UPDATE inspiration_import_runs
       SET status = ?, items_seen = ?, items_imported = ?, error_message = ?, completed_at = CURRENT_TIMESTAMP
       WHERE id = ?`
  ).bind(status, itemsSeen, itemsImported, errorMessage ?? null, runId).run();
}
function civitaiCandidate(item) {
  const prompt = typeof item.meta?.prompt === "string" ? item.meta.prompt.trim() : "";
  if (!item.id || !item.url || !prompt) return null;
  const tags = item.meta?.resources?.map((resource) => resource.name).filter((name) => Boolean(name)) ?? [];
  const nsfw = item.nsfw === true || item.nsfw === "true";
  return {
    sourceItemId: String(item.id),
    originalUrl: `https://civitai.com/images/${item.id}`,
    author: item.username ?? item.user?.username,
    title: prompt.slice(0, 96),
    prompt,
    negativePrompt: item.meta?.negativePrompt,
    originalImageUrl: item.url,
    width: item.width,
    height: item.height,
    tags: ["Civitai", ...tags],
    model: item.meta?.Model ?? item.meta?.model,
    safety: nsfw ? "nsfw" : "sfw"
  };
}
function xCandidates(json) {
  const mediaByKey = new Map((json.includes?.media ?? []).map((item) => [item.media_key, item]));
  const usersById = new Map((json.includes?.users ?? []).map((item) => [item.id, item]));
  return (json.data ?? []).flatMap((tweet) => {
    const user = tweet.author_id ? usersById.get(tweet.author_id) : void 0;
    const medias = tweet.attachments?.media_keys?.map((key) => mediaByKey.get(key)).filter((item) => Boolean(item)) ?? [];
    return medias.filter((media) => media.type === "photo" && (media.preview_image_url || media.url)).map((media) => ({
      sourceItemId: `${tweet.id}:${media.media_key}`,
      originalUrl: `https://x.com/${user?.username ?? "i"}/status/${tweet.id}`,
      author: user?.username ? `@${user.username}` : user?.name,
      title: trimText(tweet.text ?? media.alt_text ?? "X \u7075\u611F", 120),
      prompt: trimText(media.alt_text || tweet.text || "", 4e3),
      originalImageUrl: media.preview_image_url ?? media.url,
      width: media.width,
      height: media.height,
      tags: ["X"],
      safety: "unknown"
    }));
  });
}
function extractTweetId(url) {
  const match = url.pathname.match(/\/status\/(\d+)/);
  return match?.[1];
}
function canonicalTweetUrl(tweetId, pathname) {
  const username = pathname.split("/").filter(Boolean).at(0) ?? "i";
  return `https://x.com/${username}/status/${tweetId}`;
}
function parseConfig(value) {
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}
function sourceLimit(env, configured) {
  const fallback = envNumber(env.INSPIRATION_MAX_ITEMS_PER_RUN, DEFAULT_MAX_ITEMS_PER_RUN);
  const value = typeof configured === "number" ? configured : Number(configured);
  return Math.max(1, Math.min(Number.isFinite(value) ? value : fallback, fallback, 100));
}
function autoPublishSources(env) {
  const raw = env.INSPIRATION_AUTO_PUBLISH_SOURCES ?? "civitai";
  return new Set(raw.split(",").map((item) => item.trim()).filter(Boolean));
}
function aspectRatio(width, height) {
  if (!width || !height) return null;
  const divisor = gcd(width, height);
  return `${Math.round(width / divisor)}:${Math.round(height / divisor)}`;
}
function gcd(left, right) {
  let a = Math.abs(left);
  let b = Math.abs(right);
  while (b) {
    const next = a % b;
    a = b;
    b = next;
  }
  return a || 1;
}
function normalizeTags(tags) {
  return [...new Set((tags ?? []).map((item) => item.trim()).filter(Boolean))].slice(0, 12);
}
function mergeTags(...groups) {
  return normalizeTags(groups.flatMap((group) => group ?? []));
}
function trimText(value, maxLength) {
  const trimmed = value.replace(/\s+/g, " ").trim();
  return trimmed.length > maxLength ? `${trimmed.slice(0, maxLength - 1)}...` : trimmed;
}
function escapeLike(value) {
  return value.replace(/[\\%_]/g, (match) => `\\${match}`);
}
function isBlockedHostname(hostname) {
  const host = hostname.toLowerCase();
  if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local")) return true;
  if (host.includes(":")) return true;
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) return true;
  return false;
}
function normalizeImageMime(value) {
  const mime = value?.split(";")[0]?.trim().toLowerCase();
  if (mime === "image/jpeg" || mime === "image/png" || mime === "image/webp" || mime === "image/gif" || mime === "image/avif") return mime;
  return null;
}
function extensionFromMime(mimeType) {
  if (mimeType === "image/jpeg") return "jpg";
  if (mimeType === "image/webp") return "webp";
  if (mimeType === "image/gif") return "gif";
  if (mimeType === "image/avif") return "avif";
  return "png";
}
function extractMeta(html, name) {
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const patterns = [
    new RegExp(`<meta\\s+[^>]*(?:property|name)=["']${escaped}["'][^>]*content=["']([^"']+)["'][^>]*>`, "i"),
    new RegExp(`<meta\\s+[^>]*content=["']([^"']+)["'][^>]*(?:property|name)=["']${escaped}["'][^>]*>`, "i")
  ];
  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match?.[1]) return decodeHtml(match[1]);
  }
  return void 0;
}
function extractTitle(html) {
  const match = html.match(/<title[^>]*>([^<]+)<\/title>/i);
  return match?.[1] ? decodeHtml(match[1]) : void 0;
}
function extractFirstImage(html) {
  const match = html.match(/<img\s+[^>]*src=["']([^"']+)["'][^>]*>/i);
  return match?.[1] ? decodeHtml(match[1]) : void 0;
}
function absoluteUrl(value, baseUrl) {
  if (!value) return void 0;
  try {
    return new URL(value, baseUrl).toString();
  } catch {
    return void 0;
  }
}
function decodeHtml(value) {
  return value.replaceAll("&amp;", "&").replaceAll("&quot;", '"').replaceAll("&#39;", "'").replaceAll("&lt;", "<").replaceAll("&gt;", ">").trim();
}

// src/worker/index.ts
import { Hono } from "hono";
import { getCookie, setCookie, deleteCookie } from "hono/cookie";
import { cors } from "hono/cors";

// src/worker/db.ts
var IMAGE_GENERATED_EVENT = "image_generated";
var GENERATION_JOB_PAGE_SIZE = 40;
var GENERATION_JOB_PAGE_QUERY_LIMIT = GENERATION_JOB_PAGE_SIZE + 1;
async function getSpaceByKey(db, spaceKey) {
  return db.prepare("SELECT * FROM spaces WHERE space_key = ?").bind(spaceKey).first();
}
async function createSpace(db, displayName, spaceKey, passwordHash) {
  const id = randomId("spc");
  await db.prepare("INSERT INTO spaces (id, space_name, space_key, password_hash) VALUES (?, ?, ?, ?)").bind(id, displayName, spaceKey, passwordHash).run();
  const space = await getSpaceByKey(db, spaceKey);
  if (!space) throw new Error("\u7A7A\u95F4\u521B\u5EFA\u5931\u8D25\u3002");
  return space;
}
async function createSession(db, spaceId, tokenHash, expiresAt) {
  await db.prepare("INSERT INTO space_sessions (id, space_id, token_hash, expires_at) VALUES (?, ?, ?, ?)").bind(randomId("ses"), spaceId, tokenHash, expiresAt).run();
}
async function getSession(db, tokenHash) {
  return db.prepare(
    `SELECT
        space_sessions.id,
        space_sessions.space_id,
        space_sessions.token_hash,
        space_sessions.expires_at,
        space_sessions.created_at,
        spaces.id AS space_id_record,
        spaces.space_name,
        spaces.space_key,
        spaces.password_hash,
        spaces.updated_at
      FROM space_sessions
      INNER JOIN spaces ON spaces.id = space_sessions.space_id
      WHERE space_sessions.token_hash = ? AND space_sessions.expires_at > ?`
  ).bind(tokenHash, (/* @__PURE__ */ new Date()).toISOString()).first();
}
async function deleteSession(db, tokenHash) {
  await db.prepare("DELETE FROM space_sessions WHERE token_hash = ?").bind(tokenHash).run();
}
async function upsertCredential(db, spaceId, input) {
  const existing = await getCredential(db, spaceId);
  if (existing) {
    await db.prepare(
      `UPDATE api_credentials
         SET base_url = ?, model = ?, encrypted_api_key = ?, api_key_hint = ?,
             prompt_base_url = ?, prompt_optimizer_model = ?, prompt_encrypted_api_key = ?, prompt_api_key_hint = ?,
             last_test_ok = 0, last_tested_at = NULL, prompt_last_test_ok = 0, prompt_last_tested_at = NULL, updated_at = CURRENT_TIMESTAMP
         WHERE space_id = ?`
    ).bind(
      input.imageBaseURL,
      input.imageModel,
      input.imageEncryptedApiKey,
      input.imageApiKeyHint,
      input.promptBaseURL,
      input.promptModel,
      input.promptEncryptedApiKey,
      input.promptApiKeyHint,
      spaceId
    ).run();
    return;
  }
  await db.prepare(
    `INSERT INTO api_credentials (
        id, space_id, base_url, model, encrypted_api_key, api_key_hint,
        prompt_base_url, prompt_optimizer_model, prompt_encrypted_api_key, prompt_api_key_hint
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).bind(
    randomId("cred"),
    spaceId,
    input.imageBaseURL,
    input.imageModel,
    input.imageEncryptedApiKey,
    input.imageApiKeyHint,
    input.promptBaseURL,
    input.promptModel,
    input.promptEncryptedApiKey,
    input.promptApiKeyHint
  ).run();
}
async function getCredential(db, spaceId) {
  return db.prepare("SELECT * FROM api_credentials WHERE space_id = ?").bind(spaceId).first();
}
async function deleteCredential(db, spaceId) {
  await db.prepare("DELETE FROM api_credentials WHERE space_id = ?").bind(spaceId).run();
}
async function markCredentialTested(db, spaceId, kind, ok) {
  if (kind === "prompt") {
    await db.prepare(
      `UPDATE api_credentials
         SET prompt_last_test_ok = ?, prompt_last_tested_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
         WHERE space_id = ?`
    ).bind(ok ? 1 : 0, spaceId).run();
    return;
  }
  await db.prepare(
    `UPDATE api_credentials
       SET last_test_ok = ?, last_tested_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
       WHERE space_id = ?`
  ).bind(ok ? 1 : 0, spaceId).run();
}
async function createGenerationJob(db, spaceId, input, model, baseUrlHash, referenceImages = [], maskImage, jobId = randomId("job"), conversationId) {
  const primaryReference = referenceImages[0];
  const referenceImagesJson = referenceImages.length > 0 ? JSON.stringify(referenceImages.map(referenceImageSnapshot)) : null;
  const normalizedConversationId = typeof conversationId === "string" && conversationId.trim() ? conversationId.trim() : jobId;
  await db.prepare(
    `INSERT INTO generation_jobs (
        id, space_id, status, prompt, aspect_ratio, width, height, quality, quantity,
        output_format, background, compression, moderation, model, base_url_hash,
        reference_image_storage_key, reference_image_mime_type, reference_image_name, reference_image_byte_size,
        mask_image_storage_key, mask_image_mime_type, mask_image_name, mask_image_byte_size, conversation_id,
        stage, progress_current, progress_total, reference_images_json
      ) VALUES (?, ?, 'queued', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'queued', 0, ?, ?)`
  ).bind(
    jobId,
    spaceId,
    input.prompt,
    input.aspectRatio,
    input.width,
    input.height,
    input.quality,
    input.quantity,
    input.outputFormat,
    input.background,
    input.outputFormat === "png" ? null : input.compression,
    input.moderation,
    model,
    baseUrlHash,
    primaryReference?.storageKey ?? null,
    primaryReference?.mimeType ?? null,
    primaryReference?.name ?? null,
    primaryReference?.byteSize ?? null,
    maskImage?.storageKey ?? null,
    maskImage?.mimeType ?? null,
    maskImage?.name ?? null,
    maskImage?.byteSize ?? null,
    normalizedConversationId,
    input.quantity,
    referenceImagesJson
  ).run();
  return jobId;
}
async function getGenerationJob(db, spaceId, jobId) {
  return db.prepare("SELECT * FROM generation_jobs WHERE id = ? AND space_id = ?").bind(jobId, spaceId).first();
}
async function getGenerationJobForWorker(db, jobId) {
  return db.prepare("SELECT * FROM generation_jobs WHERE id = ?").bind(jobId).first();
}
async function deleteGenerationJob(db, spaceId, jobId) {
  await db.prepare("DELETE FROM generation_jobs WHERE id = ? AND space_id = ?").bind(jobId, spaceId).run();
}
async function listGenerationJobs(db, spaceId, cursor) {
  const sql = cursor ? `SELECT * FROM generation_jobs
       WHERE space_id = ? AND created_at < ?
       ORDER BY created_at DESC
       LIMIT ${GENERATION_JOB_PAGE_QUERY_LIMIT}` : `SELECT * FROM generation_jobs
       WHERE space_id = ?
       ORDER BY created_at DESC
       LIMIT ${GENERATION_JOB_PAGE_QUERY_LIMIT}`;
  const statement = cursor ? db.prepare(sql).bind(spaceId, cursor) : db.prepare(sql).bind(spaceId);
  const result = await statement.all();
  return result.results ?? [];
}
async function listImagesForJob(db, spaceId, jobId) {
  const result = await db.prepare("SELECT * FROM image_assets WHERE job_id = ? AND space_id = ? ORDER BY created_at ASC").bind(jobId, spaceId).all();
  return result.results ?? [];
}
async function listImagesForJobs(db, spaceId, jobIds) {
  if (jobIds.length === 0) return [];
  const placeholders = jobIds.map(() => "?").join(", ");
  const result = await db.prepare(
    `SELECT * FROM image_assets
       WHERE space_id = ? AND job_id IN (${placeholders})
       ORDER BY created_at ASC`
  ).bind(spaceId, ...jobIds).all();
  return result.results ?? [];
}
async function listGenerationResultsForJob(db, spaceId, jobId) {
  const result = await db.prepare(
    `SELECT * FROM generation_job_results
       WHERE space_id = ? AND job_id = ?
       ORDER BY result_index ASC`
  ).bind(spaceId, jobId).all();
  return result.results ?? [];
}
async function listGenerationResultsForJobs(db, spaceId, jobIds) {
  if (jobIds.length === 0) return [];
  const placeholders = jobIds.map(() => "?").join(", ");
  const result = await db.prepare(
    `SELECT * FROM generation_job_results
       WHERE space_id = ? AND job_id IN (${placeholders})
       ORDER BY job_id ASC, result_index ASC`
  ).bind(spaceId, ...jobIds).all();
  return result.results ?? [];
}
async function listImages(db, spaceId, cursor) {
  const sql = cursor ? `SELECT image_assets.*, generation_jobs.prompt, generation_jobs.quality, generation_jobs.aspect_ratio
       FROM image_assets
       INNER JOIN generation_jobs ON generation_jobs.id = image_assets.job_id
       WHERE image_assets.space_id = ? AND image_assets.created_at < ?
       ORDER BY image_assets.created_at DESC
       LIMIT 30` : `SELECT image_assets.*, generation_jobs.prompt, generation_jobs.quality, generation_jobs.aspect_ratio
       FROM image_assets
       INNER JOIN generation_jobs ON generation_jobs.id = image_assets.job_id
       WHERE image_assets.space_id = ?
       ORDER BY image_assets.created_at DESC
       LIMIT 30`;
  const statement = cursor ? db.prepare(sql).bind(spaceId, cursor) : db.prepare(sql).bind(spaceId);
  const result = await statement.all();
  return result.results ?? [];
}
async function getImage(db, spaceId, imageId) {
  return db.prepare("SELECT * FROM image_assets WHERE id = ? AND space_id = ?").bind(imageId, spaceId).first();
}
async function countActiveJobs(db, spaceId) {
  const row = await db.prepare("SELECT COUNT(*) AS count FROM generation_jobs WHERE space_id = ? AND status IN ('queued', 'running')").bind(spaceId).first();
  return dbNumber(row?.count);
}
async function insertRateLimitEvent(db, spaceId, eventType) {
  await db.prepare("INSERT INTO rate_limit_events (id, space_id, event_type) VALUES (?, ?, ?)").bind(randomId("evt"), spaceId, eventType).run();
}
async function insertImageUsageEvent(db, spaceId, imageId) {
  await db.prepare("INSERT INTO rate_limit_events (id, space_id, event_type) VALUES (?, ?, ?) ON CONFLICT (id) DO NOTHING").bind(imageUsageEventId(imageId), spaceId, IMAGE_GENERATED_EVENT).run();
}
async function updateJobStatus(db, jobId, status, errorCode, errorMessage, update = {}) {
  const completed = status === "succeeded" || status === "partial_succeeded" || status === "failed" || status === "cancelled";
  const nextStage = update.stage ?? stageForStatus(status);
  await db.prepare(
    `UPDATE generation_jobs
       SET status = ?,
           error_code = ?,
           error_message = ?,
           error_reason = ?,
           stage = ?,
           progress_current = COALESCE(?, progress_current),
           progress_total = COALESCE(?, progress_total),
           started_at = COALESCE(started_at, CASE WHEN ? = 'running' THEN CURRENT_TIMESTAMP ELSE started_at END),
           completed_at = CASE WHEN ? THEN CURRENT_TIMESTAMP ELSE completed_at END
       WHERE id = ?`
  ).bind(
    status,
    errorCode ?? null,
    errorMessage ?? null,
    update.errorReason ?? errorMessage ?? null,
    nextStage,
    update.progressCurrent ?? null,
    update.progressTotal ?? null,
    status,
    completed,
    jobId
  ).run();
}
async function completeJob(db, jobId, status, revisedPrompt, usageJson, errorCode = null, errorMessage = null) {
  await db.prepare(
    `UPDATE generation_jobs
       SET status = ?, stage = 'completed', progress_current = quantity, progress_total = quantity,
           revised_prompt = ?, usage_json = ?, error_code = ?, error_message = ?, error_reason = ?, completed_at = CURRENT_TIMESTAMP
       WHERE id = ?`
  ).bind(status, revisedPrompt, usageJson, errorCode, errorMessage, errorMessage, jobId).run();
}
async function upsertGenerationJobResult(db, row) {
  await db.prepare(
    `INSERT INTO generation_job_results (
        id, space_id, job_id, result_index, status, image_asset_id, error_code, error_message, started_at, completed_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT (job_id, result_index) DO UPDATE SET
        status = excluded.status,
        image_asset_id = excluded.image_asset_id,
        error_code = excluded.error_code,
        error_message = excluded.error_message,
        started_at = COALESCE(generation_job_results.started_at, excluded.started_at),
        completed_at = excluded.completed_at`
  ).bind(
    row.id,
    row.space_id,
    row.job_id,
    row.result_index,
    row.status,
    row.image_asset_id,
    row.error_code,
    row.error_message,
    row.started_at,
    row.completed_at
  ).run();
}
async function insertImageAsset(db, row) {
  try {
    await db.prepare(
      `INSERT INTO image_assets (
          id, space_id, job_id, storage_key, mime_type, format, width, height, byte_size, sha256,
          thumbnail_storage_key, thumbnail_mime_type, thumbnail_byte_size, thumbnail_sha256
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT (id) DO UPDATE SET
          storage_key = excluded.storage_key,
          mime_type = excluded.mime_type,
          format = excluded.format,
          width = excluded.width,
          height = excluded.height,
          byte_size = excluded.byte_size,
          sha256 = excluded.sha256,
          thumbnail_storage_key = COALESCE(excluded.thumbnail_storage_key, image_assets.thumbnail_storage_key),
          thumbnail_mime_type = COALESCE(excluded.thumbnail_mime_type, image_assets.thumbnail_mime_type),
          thumbnail_byte_size = COALESCE(excluded.thumbnail_byte_size, image_assets.thumbnail_byte_size),
          thumbnail_sha256 = COALESCE(excluded.thumbnail_sha256, image_assets.thumbnail_sha256)`
    ).bind(
      row.id,
      row.space_id,
      row.job_id,
      row.storage_key,
      row.mime_type,
      row.format,
      row.width,
      row.height,
      row.byte_size,
      row.sha256,
      row.thumbnail_storage_key,
      row.thumbnail_mime_type,
      row.thumbnail_byte_size,
      row.thumbnail_sha256
    ).run();
  } catch (error) {
    if (!isMissingThumbnailColumnError(error)) throw error;
    await db.prepare(
      `INSERT INTO image_assets (
          id, space_id, job_id, storage_key, mime_type, format, width, height, byte_size, sha256
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT (id) DO UPDATE SET
          storage_key = excluded.storage_key,
          mime_type = excluded.mime_type,
          format = excluded.format,
          width = excluded.width,
          height = excluded.height,
          byte_size = excluded.byte_size,
          sha256 = excluded.sha256`
    ).bind(
      row.id,
      row.space_id,
      row.job_id,
      row.storage_key,
      row.mime_type,
      row.format,
      row.width,
      row.height,
      row.byte_size,
      row.sha256
    ).run();
  }
}
function isMissingThumbnailColumnError(error) {
  const message = error instanceof Error ? error.message.toLowerCase() : String(error).toLowerCase();
  const namesThumbnailColumn = /thumbnail_(storage_key|mime_type|byte_size|sha256)/.test(message);
  return namesThumbnailColumn && /(does not exist|has no column|no column named|unknown column)/.test(message);
}
function imageUsageEventId(imageId) {
  return `evt_usage_${imageId}`;
}
function dbNumber(value) {
  const parsed = typeof value === "number" ? value : Number(value ?? 0);
  return Number.isFinite(parsed) ? parsed : 0;
}
function referenceImageSnapshot(image) {
  return {
    storageKey: image.storageKey,
    mimeType: image.mimeType,
    name: image.name,
    byteSize: image.byteSize,
    ...image.role ? { role: image.role } : {}
  };
}
function stageForStatus(status) {
  if (status === "queued") return "queued";
  if (status === "running") return "waiting_provider";
  if (status === "cancelled") return "cancelled";
  if (status === "failed") return "failed";
  return "completed";
}

// src/worker/security.ts
var BLOCKED_HOSTS = /* @__PURE__ */ new Set([
  "localhost",
  "metadata.google.internal",
  "metadata",
  "169.254.169.254"
]);
var TURNSTILE_VERIFY_TIMEOUT_MS = 5e3;
function normalizeSpaceName(spaceName) {
  const displayName = spaceName.trim().replace(/\s+/g, " ");
  return { displayName, key: displayName.toLowerCase() };
}
function validateBaseURL(value) {
  let url;
  try {
    url = new URL(value.trim());
  } catch {
    return { ok: false, error: "baseURL \u5FC5\u987B\u662F\u5408\u6CD5 URL\u3002" };
  }
  if (url.protocol !== "https:") {
    return { ok: false, error: "baseURL \u5FC5\u987B\u4F7F\u7528 HTTPS\u3002" };
  }
  if (url.username || url.password) {
    return { ok: false, error: "baseURL \u4E0D\u80FD\u5305\u542B\u7528\u6237\u540D\u6216\u5BC6\u7801\u3002" };
  }
  if (url.search || url.hash) {
    return { ok: false, error: "baseURL \u4E0D\u80FD\u5305\u542B\u67E5\u8BE2\u53C2\u6570\u6216 hash\u3002" };
  }
  const hostname = url.hostname.toLowerCase();
  if (!hostname || BLOCKED_HOSTS.has(hostname) || hostname.endsWith(".localhost") || hostname.endsWith(".local")) {
    return { ok: false, error: "baseURL \u4E3B\u673A\u4E0D\u5141\u8BB8\u8BBF\u95EE\u3002" };
  }
  if (isIpLiteral(hostname)) {
    return { ok: false, error: "baseURL \u4E0D\u5141\u8BB8\u4F7F\u7528 IP \u5730\u5740\uFF0C\u8BF7\u4F7F\u7528\u516C\u5F00\u57DF\u540D\u3002" };
  }
  const normalizedPath = url.pathname.replace(/\/+$/, "");
  url.pathname = normalizedPath === "/" ? "" : normalizedPath;
  return { ok: true, normalized: url.toString().replace(/\/$/, "") };
}
function buildProviderEndpoint(baseURL, endpoint) {
  const base = new URL(baseURL);
  base.pathname = `${base.pathname.replace(/\/+$/, "")}/${endpoint.replace(/^\/+/, "")}`;
  base.search = "";
  base.hash = "";
  return base.toString();
}
function isIpLiteral(hostname) {
  if (/^\d+\.\d+\.\d+\.\d+$/.test(hostname)) return true;
  if (hostname.includes(":")) return true;
  if (/^\[[0-9a-f:]+\]$/i.test(hostname)) return true;
  return false;
}
async function verifyTurnstile(token, request, env) {
  const required = env.TURNSTILE_REQUIRED === "true";
  if (!env.TURNSTILE_SECRET_KEY) return !required;
  if (!token) return false;
  const form = new FormData();
  form.append("secret", env.TURNSTILE_SECRET_KEY);
  form.append("response", token);
  const ip = request.headers.get("CF-Connecting-IP");
  if (ip) form.append("remoteip", ip);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort("timeout"), TURNSTILE_VERIFY_TIMEOUT_MS);
  try {
    const response = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      body: form,
      signal: controller.signal
    });
    if (!response.ok) return false;
    const result = await response.json();
    return result.success === true;
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

// src/worker/provider.ts
var DEFAULT_GENERATION_TIMEOUT_MS = 6e5;
var MAX_QUEUE_CONSUMER_TIMEOUT_MS = 14 * 60 * 1e3;
var MIN_GENERATION_JOB_MAX_RUNTIME_MS = 6e4;
var DEFAULT_GENERATION_JOB_MAX_RUNTIME_MS = MAX_QUEUE_CONSUMER_TIMEOUT_MS;
var DEFAULT_PROVIDER_IMAGE_CONCURRENCY = 2;
var MAX_PROVIDER_IMAGE_CONCURRENCY = 4;
var DEFAULT_RESPONSES_MODEL = "gpt-5.5";
var DEFAULT_PROMPT_OPTIMIZER_MODEL = DEFAULT_RESPONSES_MODEL;
var DEFAULT_PROMPT_OPTIMIZER_TIMEOUT_MS = 45e3;
var PROVIDER_TIMEOUT_RETRY_DELAYS_MS = [5e3, 1e4, 2e4, 3e4, 6e4, 6e4];
var DEFAULT_PROVIDER_TIMEOUT_RETRY_ATTEMPTS = 0;
var MAX_PROVIDER_TIMEOUT_RETRY_ATTEMPTS = 4;
var IMMEDIATE_PROVIDER_TIMEOUT_RETRY_REQUEST_TIMEOUT_MS = 3e4;
var MAX_PROVIDER_IMAGE_DOWNLOAD_BYTES = 25 * 1024 * 1024;
var MAX_PROVIDER_IMAGE_REDIRECTS = 3;
var PROVIDER_IMAGE_DOWNLOAD_RETRY_DELAYS_MS = [1e3, 3e3, 8e3, 2e4];
var PROVIDER_IMAGE_DOWNLOAD_ATTEMPT_TIMEOUT_MS = 6e4;
var PROVIDER_IMAGE_DOWNLOAD_USER_AGENT = "oh-myimage/1.0";
var IMAGE_STORAGE_RETRY_DELAYS_MS = [1e3, 3e3];
var GENERATED_THUMBNAIL_MAX_EDGE_PX = 512;
var GENERATED_THUMBNAIL_WEBP_QUALITY = 78;
var PROMPT_OPTIMIZER_MODELS = /* @__PURE__ */ new Set(["gpt-5.5", "gpt-5.4"]);
var PROVIDER_RESULT_CHECKPOINT_VERSION = 1;
var REFERENCE_IMAGE_PROMPT_SUFFIX = [
  "Use the attached reference image(s) as active visual input, not as optional background context.",
  "If the user asks for a change, make that change visibly clear; do not reproduce the reference unchanged unless the user explicitly asks to preserve it."
].join(" ");
var SOURCE_IMAGE_PROMPT_SUFFIX = [
  "The first attached image is the primary source image to edit.",
  "Any later attached images are supplemental references for the style, material, color, or content the user names.",
  "Preserve only the traits the user explicitly asks to keep, and make requested changes visibly clear."
].join(" ");
var MASKED_IMAGE_EDIT_PROMPT_SUFFIX = [
  "Treat the user's prompt as the replacement content for that selected area, not as an instruction to add a new object elsewhere in the image.",
  "Replace the masked content so the selected area matches the user's prompt exactly, including short words, labels, or characters when text is requested.",
  "Only edit the area selected by the alpha mask's transparent pixels.",
  "Preserve every unmasked area of the input image, including composition, objects, lighting, texture, and background, as unchanged as possible."
].join(" ");
var ProviderError = class extends Error {
  constructor(code, message, retryable = false, retryScope = "provider") {
    super(message);
    this.code = code;
    this.retryable = retryable;
    this.retryScope = retryScope;
  }
  code;
  retryable;
  retryScope;
};
function providerIdempotencyKey(job, resultIndex) {
  return `oh-myimage:${job.space_id}:${job.id}:${resultIndex}`;
}
function shouldImmediatelyRetryImageGeneration(error) {
  return error.code === "provider_timeout";
}
function resolveProviderTimeoutRetryAttempts(value) {
  return Math.min(Math.max(Math.trunc(envNumber(value, DEFAULT_PROVIDER_TIMEOUT_RETRY_ATTEMPTS)), 0), MAX_PROVIDER_TIMEOUT_RETRY_ATTEMPTS);
}
function resolveProviderTimeoutRetryDelayMs(attempt) {
  const index = Math.max(0, Math.trunc(attempt));
  return PROVIDER_TIMEOUT_RETRY_DELAYS_MS[index] ?? PROVIDER_TIMEOUT_RETRY_DELAYS_MS[PROVIDER_TIMEOUT_RETRY_DELAYS_MS.length - 1];
}
function resolvePostCheckpointImageTimeoutMs(remainingRuntimeMs, timeoutMs) {
  const floorMs = Math.min(Math.max(Math.trunc(timeoutMs), 1e3), PROVIDER_IMAGE_DOWNLOAD_ATTEMPT_TIMEOUT_MS);
  return Math.max(Math.trunc(remainingRuntimeMs), floorMs);
}
function generationJobDeadlineMs(job, maxRuntimeMs, nowMs = Date.now()) {
  const persistedStart = providerTimestampMs(job.started_at);
  const startMs = Number.isFinite(persistedStart) && persistedStart <= nowMs ? persistedStart : nowMs;
  return startMs + maxRuntimeMs;
}
function wait(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}
async function testProvider(baseURL, apiKey, timeoutMs = 15e3) {
  const endpoint = buildProviderEndpoint(baseURL, "/models");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort("timeout"), timeoutMs);
  try {
    const response = await fetch(endpoint, {
      headers: { Authorization: `Bearer ${apiKey}` },
      redirect: "manual",
      signal: controller.signal
    });
    if (response.ok) return { ok: true, status: response.status, message: "\u8FDE\u63A5\u6210\u529F\u3002" };
    return { ok: false, status: response.status, message: `\u6A21\u578B\u670D\u52A1\u8FD4\u56DE ${response.status}\u3002` };
  } catch (error) {
    return { ok: false, status: 0, message: redactSecrets(error instanceof Error ? error.message : "\u8FDE\u63A5\u5931\u8D25\u3002") };
  } finally {
    clearTimeout(timer);
  }
}
async function optimizePrompt(input, provider, apiKey, env) {
  if (!provider.prompt_base_url) {
    throw new ProviderError("provider_missing", "\u8BF7\u5148\u5728\u8BBE\u7F6E\u4E2D\u914D\u7F6E\u63D0\u793A\u8BCD Provider \u7684 baseURL \u548C API Key\u3002");
  }
  const endpoint = buildProviderEndpoint(provider.prompt_base_url, "/responses");
  const controller = new AbortController();
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, DEFAULT_PROMPT_OPTIMIZER_TIMEOUT_MS);
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: resolveResponsesModel(resolvePromptOptimizerModel(provider.prompt_optimizer_model ?? env.PROMPT_OPTIMIZER_MODEL)),
        instructions: PROMPT_OPTIMIZER_INSTRUCTIONS,
        input: promptOptimizationInput(input)
      }),
      redirect: "manual",
      signal: controller.signal
    });
    if (!response.ok) {
      const text = await providerMessage(response);
      const code = providerErrorCode(response.status, text);
      throw new ProviderError(
        code,
        providerStatusMessage(response.status, text, DEFAULT_PROMPT_OPTIMIZER_TIMEOUT_MS),
        providerErrorRetryable(code, response.status)
      );
    }
    const optimizedPrompt = extractResponsesOutputText(await response.json()).trim();
    if (!optimizedPrompt) {
      throw new ProviderError("empty_response", "\u6A21\u578B\u670D\u52A1\u6CA1\u6709\u8FD4\u56DE\u4F18\u5316\u540E\u7684\u63D0\u793A\u8BCD\u3002");
    }
    return optimizedPrompt;
  } catch (error) {
    if (error instanceof ProviderError) throw error;
    if (timedOut) {
      throw new ProviderError(
        "provider_timeout",
        `\u63D0\u793A\u8BCD\u4F18\u5316\u8D85\u8FC7 ${formatDuration(DEFAULT_PROMPT_OPTIMIZER_TIMEOUT_MS)} \u4ECD\u672A\u8FD4\u56DE\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002`,
        true
      );
    }
    throw new ProviderError("provider_request_failed", redactSecrets(error instanceof Error ? error.message : "\u63D0\u793A\u8BCD\u4F18\u5316\u5931\u8D25\u3002"));
  } finally {
    clearTimeout(timer);
  }
}
async function processGenerationMessage(message, env, options = {}) {
  const job = await getGenerationJobForWorker(env.DB, message.jobId);
  if (!job || job.space_id !== message.spaceId) return;
  if (job.status !== "queued" && job.status !== "running") return;
  const credential = await getCredential(env.DB, job.space_id);
  if (!credential) {
    await updateJobStatus(env.DB, job.id, "failed", "provider_missing", "\u8BF7\u5148\u5728\u8BBE\u7F6E\u4E2D\u914D\u7F6E baseURL \u548C API Key\u3002");
    return;
  }
  await updateJobStatus(env.DB, job.id, "running", void 0, void 0, {
    stage: "waiting_provider",
    progressCurrent: await completedSlotCount(env, job),
    progressTotal: job.quantity
  });
  try {
    const apiKey = await decryptSecret(credential.encrypted_api_key, env.APP_ENCRYPTION_KEY ?? "");
    const result = await requestGeneration(job, credential, apiKey, env);
    const completedCount = result.existingCount + result.storedImages.length;
    const retryError = [...result.errors].reverse().find((error) => shouldRetryProcessingError(error, options));
    if (retryError) throw retryError;
    if (completedCount === 0) {
      throw result.errors.at(-1) ?? new ProviderError("empty_response", "\u6A21\u578B\u670D\u52A1\u6CA1\u6709\u8FD4\u56DE\u56FE\u7247\u3002");
    }
    const usage = result.storedImages.map((image) => image.usage).filter((item) => item !== void 0);
    const revisedPrompt = result.storedImages.find((image) => image.revisedPrompt)?.revisedPrompt ?? null;
    const usageJson = usage.length === 0 ? null : JSON.stringify(usage.length === 1 ? usage[0] : usage);
    const status = completedCount >= result.requestedCount ? "succeeded" : "partial_succeeded";
    const lastError = result.errors.at(-1);
    const partialMessage = status === "partial_succeeded" ? `\u90E8\u5206\u56FE\u7247\u751F\u6210\u5931\u8D25\uFF0C\u5DF2\u4FDD\u7559 ${completedCount}/${result.requestedCount} \u5F20\u6210\u529F\u7ED3\u679C\u3002${lastError?.message ?? "\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002"}` : null;
    await completeJob(
      env.DB,
      job.id,
      status,
      revisedPrompt,
      usageJson,
      status === "partial_succeeded" ? lastError?.code ?? "partial_generation_failed" : null,
      partialMessage
    );
  } catch (error) {
    const providerError = normalizeProviderError(error);
    if (shouldRetryProcessingError(providerError, options)) {
      throw providerError;
    }
    await updateJobStatus(env.DB, job.id, "failed", providerError.code, providerError.message);
  }
}
function shouldRetryProcessingError(error, options) {
  if (!error.retryable) return false;
  if (error.retryScope === "post_processing") return options.retryPostProcessingErrors === true;
  return options.retryProviderErrors ?? options.throwRetryableErrors ?? false;
}
async function requestGeneration(job, credential, apiKey, env) {
  const timeoutMs = resolveGenerationTimeoutMs(env.REQUEST_TIMEOUT_MS);
  const jobDeadline = generationJobDeadlineMs(job, resolveGenerationJobMaxRuntimeMs(env.GENERATION_JOB_MAX_RUNTIME_MS));
  const concurrency = resolveProviderImageConcurrency(env.PROVIDER_IMAGE_CONCURRENCY);
  const existingImages = await listImagesForJob(env.DB, job.space_id, job.id);
  const existingResults = await listGenerationResultsForJob(env.DB, job.space_id, job.id);
  const remainingCount = Math.max(0, job.quantity - existingImages.length);
  const storedImages = [];
  const errors = [];
  const availableIndexes = availableResultIndexes(job.quantity, existingResults, existingImages.length);
  const tasks = Array.from({ length: remainingCount }, (_, index) => async () => {
    const resultIndex = availableIndexes[index] ?? existingImages.length + index;
    const startedAt = (/* @__PURE__ */ new Date()).toISOString();
    await upsertGenerationJobResult(env.DB, {
      id: generationResultId(job.id, resultIndex),
      space_id: job.space_id,
      job_id: job.id,
      result_index: resultIndex,
      status: "running",
      image_asset_id: null,
      error_code: null,
      error_message: null,
      started_at: startedAt,
      completed_at: null
    });
    await updateJobStatus(env.DB, job.id, "running", void 0, void 0, {
      stage: "waiting_provider",
      progressCurrent: existingImages.length + storedImages.length + errors.length,
      progressTotal: job.quantity
    });
    try {
      const stored = await generateAndStoreOneImage(
        job,
        credential,
        apiKey,
        Math.min(timeoutMs, Math.max(jobDeadline - Date.now(), PROVIDER_IMAGE_DOWNLOAD_ATTEMPT_TIMEOUT_MS)),
        env,
        resultIndex,
        jobDeadline
      );
      await upsertGenerationJobResult(env.DB, {
        id: generationResultId(job.id, resultIndex),
        space_id: job.space_id,
        job_id: job.id,
        result_index: resultIndex,
        status: "succeeded",
        image_asset_id: stored.imageId,
        error_code: null,
        error_message: null,
        started_at: startedAt,
        completed_at: (/* @__PURE__ */ new Date()).toISOString()
      });
      return stored;
    } catch (error) {
      const providerError = normalizeProviderError(error);
      await upsertGenerationJobResult(env.DB, {
        id: generationResultId(job.id, resultIndex),
        space_id: job.space_id,
        job_id: job.id,
        result_index: resultIndex,
        status: "failed",
        image_asset_id: null,
        error_code: providerError.code,
        error_message: providerError.message,
        started_at: startedAt,
        completed_at: (/* @__PURE__ */ new Date()).toISOString()
      });
      throw providerError;
    }
  });
  for (let start = 0; start < tasks.length; start += concurrency) {
    const settled = await Promise.allSettled(tasks.slice(start, start + concurrency).map((task) => task()));
    for (const result of settled) {
      if (result.status === "fulfilled") {
        storedImages.push(result.value);
      } else {
        errors.push(normalizeProviderError(result.reason));
      }
    }
    await updateJobStatus(env.DB, job.id, "running", void 0, void 0, {
      stage: "waiting_provider",
      progressCurrent: existingImages.length + storedImages.length + errors.length,
      progressTotal: job.quantity
    });
  }
  return { requestedCount: job.quantity, existingCount: existingImages.length, storedImages, errors };
}
async function generateAndStoreOneImage(job, credential, apiKey, timeoutMs, env, resultIndex, jobDeadlineMs) {
  const recovered = await recoverStoredImageForResult(job, resultIndex, env);
  if (recovered) {
    const checkpoint2 = await loadProviderResultCheckpoint(job, resultIndex, env);
    await deleteProviderResultCheckpointBestEffort(job, resultIndex, env);
    return checkpoint2 ? { ...recovered, revisedPrompt: checkpoint2.revisedPrompt, usage: checkpoint2.usage } : recovered;
  }
  let checkpoint = await loadProviderResultCheckpoint(job, resultIndex, env);
  if (!checkpoint) {
    const idempotencyKey = providerIdempotencyKey(job, resultIndex);
    const response = await requestGenerationBatchWithRecovery(job, credential, apiKey, timeoutMs, env, idempotencyKey, jobDeadlineMs);
    const image = response.data?.find((item) => item.b64_json || item.url);
    if (!image) {
      throw new ProviderError("empty_response", "\u6A21\u578B\u670D\u52A1\u6CA1\u6709\u8FD4\u56DE\u56FE\u7247\u3002");
    }
    checkpoint = {
      version: PROVIDER_RESULT_CHECKPOINT_VERSION,
      acceptedAt: (/* @__PURE__ */ new Date()).toISOString(),
      image: checkpointImage(image),
      revisedPrompt: image.revised_prompt ?? null,
      usage: response.usage
    };
    await persistProviderResultCheckpoint(job, resultIndex, checkpoint, env);
  }
  const downloadTimeoutMs = resolvePostCheckpointImageTimeoutMs(jobDeadlineMs - Date.now(), timeoutMs);
  if (downloadTimeoutMs < 1e3) {
    throw new ProviderError(
      "generation_runtime_exceeded",
      "\u6A21\u578B\u5DF2\u8FD4\u56DE\u7ED3\u679C\uFF0C\u4F46\u4EFB\u52A1\u5DF2\u8FBE\u5230\u6700\u957F\u8FD0\u884C\u65F6\u95F4\uFF0C\u672A\u7EE7\u7EED\u4E0B\u8F7D\u3002\u7CFB\u7EDF\u53EA\u4F1A\u6062\u590D\u8FD9\u4EFD\u5DF2\u63A5\u6536\u7ED3\u679C\uFF0C\u4E0D\u4F1A\u91CD\u65B0\u63D0\u4EA4\u751F\u56FE\u3002",
      true,
      "post_processing"
    );
  }
  const binary = await resolveProviderImageBinary(
    checkpoint.image,
    job.output_format,
    downloadTimeoutMs,
    { providerBaseURL: credential.base_url, apiKey }
  );
  const id = imageIdForResult(job.id, resultIndex);
  await persistGeneratedImage(job, env, id, resultIndex, binary.bytes, binary.mimeType, binary.format, Date.now() + downloadTimeoutMs);
  await deleteProviderResultCheckpointBestEffort(job, resultIndex, env);
  return {
    imageId: id,
    resultIndex,
    revisedPrompt: checkpoint.revisedPrompt,
    usage: checkpoint.usage
  };
}
async function requestGenerationBatchWithRecovery(job, credential, apiKey, timeoutMs, env, idempotencyKey, deadlineMs = Date.now() + timeoutMs) {
  try {
    const remainingMs = deadlineMs - Date.now();
    if (remainingMs < 1e3) {
      throw new ProviderError("generation_runtime_exceeded", "\u751F\u6210\u4EFB\u52A1\u5DF2\u8FBE\u5230\u6700\u957F\u8FD0\u884C\u65F6\u95F4\uFF0C\u672A\u518D\u6B21\u63D0\u4EA4\u6A21\u578B\u8BF7\u6C42\u3002");
    }
    return await requestGenerationBatch(job, credential, apiKey, Math.min(timeoutMs, remainingMs), env, idempotencyKey);
  } catch (error) {
    const providerError = normalizeProviderError(error);
    if (!shouldImmediatelyRetryImageGeneration(providerError)) throw providerError;
    const retryAttempts = resolveProviderTimeoutRetryAttempts(env.PROVIDER_TIMEOUT_RETRY_ATTEMPTS);
    for (let attempt = 0; attempt < retryAttempts; attempt += 1) {
      const retryDelayMs = resolveProviderTimeoutRetryDelayMs(attempt);
      if (Date.now() + retryDelayMs >= deadlineMs) break;
      await wait(retryDelayMs);
      const remainingMs = deadlineMs - Date.now();
      if (remainingMs < 1e3) break;
      const retryTimeoutMs = Math.min(timeoutMs, IMMEDIATE_PROVIDER_TIMEOUT_RETRY_REQUEST_TIMEOUT_MS, remainingMs);
      try {
        return await requestGenerationBatch(job, credential, apiKey, retryTimeoutMs, env, idempotencyKey);
      } catch (retryError) {
        const retryProviderError = normalizeProviderError(retryError);
        if (!shouldImmediatelyRetryImageGeneration(retryProviderError)) throw retryProviderError;
      }
    }
    throw providerError;
  }
}
async function resolveProviderImageBinary(image, fallbackFormat, timeoutMs, options) {
  if (image.b64_json) {
    return providerImageBinaryFromBytes(bytesFromBase64(image.b64_json), fallbackFormat);
  }
  if (!image.url) {
    throw new ProviderError("empty_response", "\u6A21\u578B\u670D\u52A1\u6CA1\u6709\u8FD4\u56DE\u56FE\u7247\u3002");
  }
  const initialUrl = validateProviderImageUrl(image.url);
  const deadline = Date.now() + Math.max(1e3, timeoutMs);
  let lastError = null;
  for (let attempt = 0; attempt <= PROVIDER_IMAGE_DOWNLOAD_RETRY_DELAYS_MS.length; attempt += 1) {
    if (attempt > 0) {
      const retryDelayMs = PROVIDER_IMAGE_DOWNLOAD_RETRY_DELAYS_MS[attempt - 1] ?? 0;
      if (Date.now() + retryDelayMs >= deadline) break;
      await wait(retryDelayMs);
    }
    const remainingMs = deadline - Date.now();
    if (remainingMs < 1e3) break;
    try {
      return await downloadProviderImageOnce(
        initialUrl,
        fallbackFormat,
        Math.min(remainingMs, PROVIDER_IMAGE_DOWNLOAD_ATTEMPT_TIMEOUT_MS),
        options
      );
    } catch (error) {
      const providerError = error instanceof ProviderError ? error : new ProviderError(
        "provider_image_download_failed",
        `\u6A21\u578B\u5DF2\u8FD4\u56DE\u56FE\u7247\u94FE\u63A5\uFF0C\u4F46\u4E0B\u8F7D\u5931\u8D25\uFF1A${redactSecrets(error instanceof Error ? error.message : "\u672A\u77E5\u9519\u8BEF")}`,
        true
      );
      lastError = providerError;
      if (!shouldRetryProviderImageDownload(providerError) || attempt === PROVIDER_IMAGE_DOWNLOAD_RETRY_DELAYS_MS.length) {
        console.warn(
          "provider image download failed",
          JSON.stringify({ host: initialUrl.host, attempt: attempt + 1, code: providerError.code })
        );
        throw asPostProcessingError(providerError);
      }
      console.warn(
        "provider image download retrying",
        JSON.stringify({ host: initialUrl.host, attempt: attempt + 1, code: providerError.code })
      );
    }
  }
  throw asPostProcessingError(
    lastError ?? new ProviderError("provider_image_download_timeout", "\u6A21\u578B\u5DF2\u8FD4\u56DE\u56FE\u7247\u94FE\u63A5\uFF0C\u4F46\u4E0B\u8F7D\u56FE\u7247\u8D85\u65F6\u3002", true)
  );
}
async function downloadProviderImageOnce(initialUrl, fallbackFormat, attemptTimeoutMs, options) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort("timeout"), Math.max(1e3, attemptTimeoutMs));
  try {
    const { response, finalUrl } = await fetchProviderImageUrl(initialUrl, controller.signal, options);
    if (!response.ok) {
      await response.body?.cancel().catch(() => {
      });
      throw new ProviderError(
        "provider_image_download_failed",
        `\u6A21\u578B\u5DF2\u8FD4\u56DE\u56FE\u7247\u94FE\u63A5\uFF0C\u4F46\u4E0B\u8F7D\u5931\u8D25\uFF1A${response.status}\u3002`,
        isRetryableProviderImageStatus(response.status)
      );
    }
    const contentType = normalizeProviderContentType(response.headers.get("content-type"));
    if (isTransientProviderImageContentType(contentType)) {
      throw new ProviderError("provider_image_download_failed", "\u6A21\u578B\u5DF2\u8FD4\u56DE\u56FE\u7247\u94FE\u63A5\uFF0C\u4F46\u54CD\u5E94\u8FD8\u4E0D\u662F\u56FE\u7247\u3002", true);
    }
    if (!isAcceptedProviderImageContentType(contentType)) {
      throw new ProviderError("provider_image_download_invalid_content_type", "\u6A21\u578B\u5DF2\u8FD4\u56DE\u56FE\u7247\u94FE\u63A5\uFF0C\u4F46\u54CD\u5E94\u4E0D\u662F\u652F\u6301\u7684\u56FE\u7247\u683C\u5F0F\u3002");
    }
    const declaredLength = contentLength(response.headers.get("content-length"));
    if (declaredLength !== null && declaredLength > MAX_PROVIDER_IMAGE_DOWNLOAD_BYTES) {
      throw new ProviderError("provider_image_download_too_large", "\u6A21\u578B\u5DF2\u8FD4\u56DE\u56FE\u7247\u94FE\u63A5\uFF0C\u4F46\u56FE\u7247\u6587\u4EF6\u8D85\u8FC7 25MB\u3002");
    }
    const bytes = await responseBytesWithLimit(response, MAX_PROVIDER_IMAGE_DOWNLOAD_BYTES);
    return providerImageBinaryFromBytes(bytes, providerImageFormatFromResponse(contentType, finalUrl.toString(), fallbackFormat));
  } catch (error) {
    if (error instanceof ProviderError) throw error;
    if (controller.signal.aborted) {
      throw new ProviderError("provider_image_download_timeout", "\u6A21\u578B\u5DF2\u8FD4\u56DE\u56FE\u7247\u94FE\u63A5\uFF0C\u4F46\u4E0B\u8F7D\u56FE\u7247\u8D85\u65F6\u3002", true);
    }
    throw new ProviderError(
      "provider_image_download_failed",
      `\u6A21\u578B\u5DF2\u8FD4\u56DE\u56FE\u7247\u94FE\u63A5\uFF0C\u4F46\u4E0B\u8F7D\u5931\u8D25\uFF1A${redactSecrets(error instanceof Error ? error.message : "\u672A\u77E5\u9519\u8BEF")}`,
      true
    );
  } finally {
    clearTimeout(timer);
  }
}
function shouldRetryProviderImageDownload(error) {
  return error.retryable && (error.code === "provider_image_download_failed" || error.code === "provider_image_download_timeout");
}
function asPostProcessingError(error) {
  const message = error.retryable ? `${error.message} \u7CFB\u7EDF\u53EA\u4F1A\u6062\u590D\u8FD9\u4EFD\u5DF2\u63A5\u6536\u7ED3\u679C\uFF0C\u4E0D\u4F1A\u91CD\u65B0\u63D0\u4EA4\u751F\u56FE\u3002` : error.message;
  return new ProviderError(error.code, message, error.retryable, "post_processing");
}
function validateProviderImageUrl(rawUrl) {
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    throw new ProviderError("provider_image_download_blocked", "\u6A21\u578B\u8FD4\u56DE\u7684\u56FE\u7247\u94FE\u63A5\u4E0D\u662F\u6709\u6548 URL\u3002");
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") {
    throw new ProviderError("provider_image_download_blocked", "\u6A21\u578B\u8FD4\u56DE\u7684\u56FE\u7247\u94FE\u63A5\u53EA\u652F\u6301 HTTP/HTTPS \u534F\u8BAE\u3002");
  }
  if (url.username || url.password || isBlockedProviderImageHost(url.hostname)) {
    throw new ProviderError("provider_image_download_blocked", "\u6A21\u578B\u8FD4\u56DE\u7684\u56FE\u7247\u94FE\u63A5\u4E0D\u5141\u8BB8\u6307\u5411\u672C\u673A\u6216\u5185\u7F51\u5730\u5740\u3002");
  }
  return url;
}
async function fetchProviderImageUrl(initialUrl, signal, options) {
  let currentUrl = initialUrl;
  for (let redirectCount = 0; redirectCount <= MAX_PROVIDER_IMAGE_REDIRECTS; redirectCount += 1) {
    const authorization = providerImageAuthorization(currentUrl, options);
    const response = await fetch(currentUrl.toString(), {
      redirect: "manual",
      signal,
      headers: {
        Accept: "image/*",
        "User-Agent": PROVIDER_IMAGE_DOWNLOAD_USER_AGENT,
        ...authorization ? { Authorization: authorization } : {}
      }
    });
    if (!isRedirectStatus(response.status)) return { response, finalUrl: currentUrl };
    const location = response.headers.get("location");
    await response.body?.cancel().catch(() => {
    });
    if (!location) return { response, finalUrl: currentUrl };
    currentUrl = validateProviderImageUrl(new URL(location, currentUrl).toString());
  }
  throw new ProviderError("provider_image_download_blocked", "\u6A21\u578B\u8FD4\u56DE\u7684\u56FE\u7247\u94FE\u63A5\u91CD\u5B9A\u5411\u6B21\u6570\u8FC7\u591A\u3002");
}
function providerImageAuthorization(url, options) {
  if (!options?.apiKey) return null;
  try {
    return new URL(options.providerBaseURL).origin === url.origin ? `Bearer ${options.apiKey}` : null;
  } catch {
    return null;
  }
}
function isRetryableProviderImageStatus(status) {
  return status === 404 || status === 408 || status === 409 || status === 425 || status === 429 || status >= 500;
}
function isRedirectStatus(status) {
  return status === 301 || status === 302 || status === 303 || status === 307 || status === 308;
}
function isBlockedProviderImageHost(hostname) {
  const host = hostname.toLowerCase().replace(/^\[/, "").replace(/\]$/, "").replace(/\.$/, "");
  if (!host || host === "localhost" || host.endsWith(".localhost")) return true;
  if (host.includes(":")) return isBlockedIpv6Host(host);
  const octets = host.split(".");
  if (octets.length !== 4 || !octets.every((octet) => /^\d+$/.test(octet))) return false;
  const values = octets.map(Number);
  if (!values.every((value) => Number.isInteger(value) && value >= 0 && value <= 255)) return false;
  const [a, b] = values;
  if (a === 0 || a === 10 || a === 127) return true;
  if (a === 100 && b >= 64 && b <= 127) return true;
  if (a === 169 && b === 254) return true;
  if (a === 172 && b >= 16 && b <= 31) return true;
  if (a === 192 && b === 168) return true;
  if (a === 198 && (b === 18 || b === 19)) return true;
  return a >= 224;
}
function isBlockedIpv6Host(host) {
  return host === "::" || host === "::1" || host.startsWith("fc") || host.startsWith("fd") || host.startsWith("fe80:");
}
function contentLength(value) {
  if (!value) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : null;
}
async function responseBytesWithLimit(response, maxBytes) {
  if (!response.body) {
    const bytes2 = new Uint8Array(await response.arrayBuffer());
    if (bytes2.byteLength > maxBytes) {
      throw new ProviderError("provider_image_download_too_large", "\u6A21\u578B\u5DF2\u8FD4\u56DE\u56FE\u7247\u94FE\u63A5\uFF0C\u4F46\u56FE\u7247\u6587\u4EF6\u8D85\u8FC7 25MB\u3002");
    }
    return bytes2;
  }
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!value) continue;
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel().catch(() => {
        });
        throw new ProviderError("provider_image_download_too_large", "\u6A21\u578B\u5DF2\u8FD4\u56DE\u56FE\u7247\u94FE\u63A5\uFF0C\u4F46\u56FE\u7247\u6587\u4EF6\u8D85\u8FC7 25MB\u3002");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bytes;
}
function checkpointImage(image) {
  if (image.b64_json) return { b64_json: image.b64_json };
  if (image.url) return { url: image.url };
  return {};
}
function providerResultCheckpointStorageKey(job, resultIndex) {
  return `${job.space_id}/${job.id}/provider-result-${resultIndex}.json`;
}
async function persistProviderResultCheckpoint(job, resultIndex, checkpoint, env) {
  const storageKey = providerResultCheckpointStorageKey(job, resultIndex);
  const serialized = JSON.stringify(checkpoint);
  let lastError;
  for (let attempt = 0; attempt <= IMAGE_STORAGE_RETRY_DELAYS_MS.length; attempt += 1) {
    if (attempt > 0) await wait(IMAGE_STORAGE_RETRY_DELAYS_MS[attempt - 1] ?? 0);
    try {
      await env.IMAGES.put(storageKey, serialized, {
        httpMetadata: {
          contentType: "application/json",
          contentDisposition: `inline; filename="provider-result-${resultIndex}.json"`
        },
        customMetadata: {
          jobId: job.id,
          spaceId: job.space_id,
          resultIndex: String(resultIndex),
          kind: "provider-result-checkpoint"
        }
      });
      return;
    } catch (error) {
      lastError = error;
    }
  }
  throw new ProviderError(
    "provider_result_checkpoint_failed",
    `\u6A21\u578B\u5DF2\u8FD4\u56DE\u7ED3\u679C\uFF0C\u4F46\u4FDD\u5B58\u5B89\u5168\u6062\u590D\u8BB0\u5F55\u5931\u8D25\uFF1A${redactSecrets(lastError instanceof Error ? lastError.message : "\u672A\u77E5\u9519\u8BEF")}\u3002\u4E3A\u907F\u514D\u91CD\u590D\u6263\u8D39\uFF0C\u7CFB\u7EDF\u4E0D\u4F1A\u81EA\u52A8\u91CD\u65B0\u63D0\u4EA4\u751F\u56FE\u3002`
  );
}
async function loadProviderResultCheckpoint(job, resultIndex, env) {
  const storageKey = providerResultCheckpointStorageKey(job, resultIndex);
  let object;
  try {
    object = await env.IMAGES.get(storageKey);
  } catch (error) {
    throw new ProviderError(
      "provider_result_checkpoint_read_failed",
      `\u8BFB\u53D6\u751F\u56FE\u6062\u590D\u8BB0\u5F55\u5931\u8D25\uFF1A${redactSecrets(error instanceof Error ? error.message : "\u672A\u77E5\u9519\u8BEF")}`,
      true,
      "post_processing"
    );
  }
  if (!object) return null;
  try {
    const parsed = JSON.parse(new TextDecoder().decode(await object.arrayBuffer()));
    const image = parsed.image;
    if (parsed.version !== PROVIDER_RESULT_CHECKPOINT_VERSION || !image || typeof image.b64_json !== "string" && typeof image.url !== "string") {
      throw new Error("checkpoint shape is invalid");
    }
    return {
      version: PROVIDER_RESULT_CHECKPOINT_VERSION,
      acceptedAt: typeof parsed.acceptedAt === "string" ? parsed.acceptedAt : "",
      image: checkpointImage(image),
      revisedPrompt: typeof parsed.revisedPrompt === "string" ? parsed.revisedPrompt : null,
      usage: parsed.usage
    };
  } catch (error) {
    throw new ProviderError(
      "provider_result_checkpoint_invalid",
      `\u751F\u56FE\u6062\u590D\u8BB0\u5F55\u635F\u574F\uFF1A${redactSecrets(error instanceof Error ? error.message : "\u672A\u77E5\u9519\u8BEF")}\u3002\u4E3A\u907F\u514D\u91CD\u590D\u6263\u8D39\uFF0C\u7CFB\u7EDF\u4E0D\u4F1A\u91CD\u65B0\u63D0\u4EA4\u751F\u56FE\u3002`
    );
  }
}
async function deleteProviderResultCheckpointBestEffort(job, resultIndex, env) {
  const storageKey = providerResultCheckpointStorageKey(job, resultIndex);
  try {
    await env.IMAGES.delete(storageKey);
  } catch (error) {
    console.warn("provider result checkpoint cleanup skipped", redactSecrets(error instanceof Error ? error.message : "unknown error"));
  }
}
async function recoverStoredImageForResult(job, resultIndex, env) {
  const id = imageIdForResult(job.id, resultIndex);
  const candidates = [.../* @__PURE__ */ new Set([normalizeProviderImageFormat(job.output_format), "png", "webp", "jpeg"])];
  let stored = null;
  for (const candidate of candidates) {
    const storageKey2 = storageKeyForResult(job, id, candidate);
    let object2;
    try {
      object2 = await env.IMAGES.get(storageKey2);
    } catch (error) {
      throw new ProviderError(
        "image_recovery_read_failed",
        `\u68C0\u67E5\u5DF2\u4FDD\u5B58\u56FE\u7247\u5931\u8D25\uFF1A${redactSecrets(error instanceof Error ? error.message : "\u672A\u77E5\u9519\u8BEF")}`,
        true,
        "post_processing"
      );
    }
    if (object2) {
      stored = { format: candidate, storageKey: storageKey2, object: object2 };
      break;
    }
  }
  if (!stored) return null;
  const { storageKey, object } = stored;
  try {
    const bytes = new Uint8Array(await object.arrayBuffer());
    const binary = providerImageBinaryFromBytes(bytes, stored.format);
    await insertImageAsset(env.DB, {
      id,
      space_id: job.space_id,
      job_id: job.id,
      storage_key: storageKey,
      mime_type: object.httpMetadata?.contentType ?? binary.mimeType,
      format: binary.format,
      width: job.width,
      height: job.height,
      byte_size: bytes.byteLength,
      sha256: await sha256Hex(bytes),
      thumbnail_storage_key: null,
      thumbnail_mime_type: null,
      thumbnail_byte_size: null,
      thumbnail_sha256: null
    });
    await insertImageUsageEvent(env.DB, job.space_id, id);
  } catch (error) {
    if (error instanceof ProviderError) throw error;
    throw new ProviderError(
      "image_asset_recovery_failed",
      `\u56FE\u7247\u5DF2\u4FDD\u5B58\uFF0C\u4F46\u8865\u5199\u56FE\u7247\u8BB0\u5F55\u5931\u8D25\uFF1A${redactSecrets(error instanceof Error ? error.message : "\u672A\u77E5\u9519\u8BEF")}`,
      true,
      "post_processing"
    );
  }
  return {
    imageId: id,
    resultIndex,
    revisedPrompt: null,
    usage: void 0
  };
}
async function persistGeneratedImage(job, env, id, resultIndex, bytes, mimeType, format, deadlineMs) {
  const storageKey = storageKeyForResult(job, id, format);
  let thumbnail = null;
  await storeGeneratedImageWithRecovery(job, env, id, resultIndex, storageKey, bytes, mimeType, format, deadlineMs);
  thumbnail = await persistGeneratedThumbnailBestEffort(job, env, id, resultIndex, bytes);
  try {
    await insertImageAsset(env.DB, {
      id,
      space_id: job.space_id,
      job_id: job.id,
      storage_key: storageKey,
      mime_type: mimeType,
      format,
      width: job.width,
      height: job.height,
      byte_size: bytes.byteLength,
      sha256: await sha256Hex(bytes),
      thumbnail_storage_key: thumbnail?.storageKey ?? null,
      thumbnail_mime_type: thumbnail?.mimeType ?? null,
      thumbnail_byte_size: thumbnail?.bytes.byteLength ?? null,
      thumbnail_sha256: thumbnail ? await sha256Hex(thumbnail.bytes) : null
    });
    await insertImageUsageEvent(env.DB, job.space_id, id);
  } catch (error) {
    throw new ProviderError(
      "image_asset_persist_failed",
      `\u6A21\u578B\u5DF2\u8FD4\u56DE\u56FE\u7247\u5E76\u4FDD\u5B58\u5230\u5BF9\u8C61\u5B58\u50A8\uFF0C\u4F46\u5199\u5165\u56FE\u7247\u8BB0\u5F55\u5931\u8D25\uFF1B\u4E0B\u6B21\u91CD\u8BD5\u4F1A\u4F18\u5148\u8865\u4FDD\u5B58\u8BB0\u5F55\uFF1A${redactSecrets(error instanceof Error ? error.message : "\u672A\u77E5\u9519\u8BEF")}`,
      true,
      "post_processing"
    );
  }
}
async function storeGeneratedImageWithRecovery(job, env, id, resultIndex, storageKey, bytes, mimeType, format, deadlineMs) {
  let lastError;
  for (let attempt = 0; attempt <= IMAGE_STORAGE_RETRY_DELAYS_MS.length; attempt += 1) {
    if (attempt > 0) {
      const delayMs = IMAGE_STORAGE_RETRY_DELAYS_MS[attempt - 1] ?? 0;
      if (Date.now() + delayMs >= deadlineMs) break;
      await wait(delayMs);
    }
    if (deadlineMs - Date.now() < 1e3) break;
    try {
      await env.IMAGES.put(storageKey, bytes, {
        httpMetadata: {
          contentType: mimeType,
          contentDisposition: `inline; filename="${id}.${format}"`
        },
        customMetadata: {
          jobId: job.id,
          spaceId: job.space_id,
          resultIndex: String(resultIndex)
        }
      });
      return;
    } catch (error) {
      lastError = error;
    }
  }
  throw new ProviderError(
    "image_storage_failed",
    `\u6A21\u578B\u5DF2\u8FD4\u56DE\u56FE\u7247\uFF0C\u4F46\u4FDD\u5B58\u5230\u5BF9\u8C61\u5B58\u50A8\u5931\u8D25\uFF1A${redactSecrets(lastError instanceof Error ? lastError.message : "\u5DF2\u8FBE\u5230\u4EFB\u52A1\u6700\u957F\u8FD0\u884C\u65F6\u95F4")}\u3002\u7CFB\u7EDF\u53EA\u4F1A\u6062\u590D\u8FD9\u4EFD\u5DF2\u63A5\u6536\u7ED3\u679C\uFF0C\u4E0D\u4F1A\u91CD\u65B0\u63D0\u4EA4\u751F\u56FE\u3002`,
    true,
    "post_processing"
  );
}
async function requestGenerationBatch(job, credential, apiKey, timeoutMs, env, idempotencyKey) {
  const endpoint = buildProviderEndpoint(credential.base_url, imageGenerationEndpointPath(job));
  const controller = new AbortController();
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);
  try {
    const body = await providerRequestBody(job, env);
    const response = await fetch(endpoint, {
      method: "POST",
      headers: providerRequestHeaders(apiKey, body, idempotencyKey),
      body,
      redirect: "manual",
      signal: controller.signal
    });
    if (!response.ok) {
      const text = await providerMessage(response);
      const code = providerErrorCode(response.status, text);
      throw new ProviderError(
        code,
        providerStatusMessage(response.status, text, timeoutMs),
        providerErrorRetryable(code, response.status)
      );
    }
    return await response.json();
  } catch (error) {
    if (error instanceof ProviderError) throw error;
    if (timedOut) {
      throw new ProviderError(
        "provider_timeout",
        `\u6A21\u578B\u670D\u52A1\u8D85\u8FC7 ${formatDuration(timeoutMs)} \u4ECD\u672A\u8FD4\u56DE\uFF0C\u5DF2\u505C\u6B62\u7B49\u5F85\u3002\u8BF7\u786E\u8BA4 baseURL \u7684\u7F51\u5173\u3001\u8D1F\u8F7D\u5747\u8861\u548C\u6A21\u578B\u670D\u52A1\u8D85\u65F6\u90FD\u4E0D\u4F4E\u4E8E\u8FD9\u4E2A\u65F6\u95F4\u3002`,
        true
      );
    }
    throw new ProviderError("provider_request_failed", redactSecrets(error instanceof Error ? error.message : "\u6A21\u578B\u8BF7\u6C42\u5931\u8D25\u3002"));
  } finally {
    clearTimeout(timer);
  }
}
async function providerRequestBody(job, env) {
  const payload = buildImageGenerationPayload(job, 1);
  if (!hasReferenceImages(job)) {
    return JSON.stringify(payload);
  }
  const referenceImages = await loadReferenceImageBlobs(job, env);
  let maskImage;
  if (job.mask_image_storage_key) {
    maskImage = await loadMaskImageBlob(job, env);
  }
  return buildImageGenerationFormData(payload, referenceImages, maskImage);
}
function providerRequestHeaders(apiKey, body, idempotencyKey) {
  const headers = {
    Authorization: `Bearer ${apiKey}`,
    "Idempotency-Key": idempotencyKey
  };
  if (!(body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
  }
  return headers;
}
function providerErrorCode(status, message = "") {
  if (isProviderBalanceMessage(message) || status === 402) return "provider_balance_insufficient";
  if (isProviderContentRejectedMessage(message)) return "provider_content_rejected";
  if (status === 401 || status === 403) return "provider_auth_failed";
  if (status === 429) return "provider_rate_limited";
  if (status === 408 || status === 504 || status === 522 || status === 524) return "provider_timeout";
  if (status >= 500) return "provider_upstream_error";
  return "provider_rejected";
}
function providerStatusMessage(status, message, timeoutMs) {
  const code = providerErrorCode(status, message);
  if (code === "provider_auth_failed") return "\u6A21\u578B\u670D\u52A1\u9274\u6743\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5 baseURL \u548C API Key\u3002";
  if (code === "provider_balance_insufficient") return "\u6A21\u578B\u670D\u52A1\u4F59\u989D\u6216\u989D\u5EA6\u4E0D\u8DB3\uFF0C\u8BF7\u68C0\u67E5\u4E0A\u6E38\u8D26\u53F7\u4F59\u989D\u3001\u5957\u9910\u6216\u989D\u5EA6\u9650\u5236\u3002";
  if (code === "provider_content_rejected") return message || "\u6A21\u578B\u670D\u52A1\u62D2\u7EDD\u4E86\u8FD9\u6B21\u8BF7\u6C42\uFF0C\u901A\u5E38\u662F\u5185\u5BB9\u5B89\u5168\u6216\u5BA1\u6838\u7B56\u7565\u5BFC\u81F4\u3002\u8BF7\u8C03\u6574\u63D0\u793A\u8BCD\u6216\u53C2\u8003\u56FE\u540E\u91CD\u8BD5\u3002";
  if (status === 522 || status === 524) {
    return `\u6A21\u578B\u670D\u52A1\u8FD4\u56DE ${status}\uFF0C\u4E0A\u6E38\u7F51\u5173\u7B49\u5F85\u6A21\u578B\u670D\u52A1\u8D85\u65F6\u3002\u5F53\u524D Worker \u5DF2\u5141\u8BB8\u6700\u957F\u7B49\u5F85 ${formatDuration(timeoutMs)}\uFF1B\u5982\u679C\u5355\u6B21\u751F\u56FE\u7ECF\u5E38\u8D85\u8FC7 120 \u79D2\uFF0C\u8BF7\u5C06 baseURL \u6307\u5411 DNS-only/\u76F4\u8FDE\u6E90\u7AD9\u57DF\u540D\uFF0C\u6216\u628A\u4E0A\u6E38\u63A5\u53E3\u6539\u6210\u5F02\u6B65\u4EFB\u52A1/\u8F6E\u8BE2\u6A21\u5F0F\u3002`;
  }
  if (code === "provider_timeout") {
    return `\u6A21\u578B\u670D\u52A1\u8FD4\u56DE ${status}\uFF0C\u8BF7\u6C42\u7B49\u5F85\u8D85\u65F6\u3002\u5F53\u524D Worker \u5DF2\u5141\u8BB8\u6700\u957F\u7B49\u5F85 ${formatDuration(timeoutMs)}\uFF1B\u5982\u679C\u9891\u7E41\u8D85\u65F6\uFF0C\u8BF7\u68C0\u67E5\u4E0A\u6E38\u7F51\u5173\u548C\u6A21\u578B\u670D\u52A1\u8D85\u65F6\u914D\u7F6E\u3002`;
  }
  if (code === "provider_upstream_error") {
    return `\u6A21\u578B\u670D\u52A1\u8FD4\u56DE ${status}\uFF0C\u4E0A\u6E38\u670D\u52A1\u6682\u65F6\u4E0D\u53EF\u7528\u6216\u5185\u90E8\u9519\u8BEF\u3002\u8BF7\u68C0\u67E5 baseURL \u7F51\u5173\u3001\u6A21\u578B\u670D\u52A1\u5065\u5EB7\u72B6\u6001\u548C\u4E0A\u6E38\u9519\u8BEF\u65E5\u5FD7\u3002`;
  }
  return message || `\u6A21\u578B\u670D\u52A1\u8FD4\u56DE ${status}\u3002`;
}
function providerErrorRetryable(code, status) {
  if (code === "provider_timeout" || code === "provider_upstream_error" || code === "provider_rate_limited") return true;
  return status >= 500 && code !== "provider_auth_failed" && code !== "provider_balance_insufficient" && code !== "provider_content_rejected";
}
async function providerMessage(response) {
  const text = redactSecrets(await response.text());
  try {
    const parsed = JSON.parse(text);
    if (parsed.error) {
      const parts = [parsed.error.code, parsed.error.type, parsed.error.message].filter((part) => Boolean(part));
      if (parts.length > 0) return redactSecrets(parts.join(" "));
    }
  } catch {
  }
  if (text.trimStart().startsWith("<")) return "";
  return text.length > 240 ? `${text.slice(0, 240)}...` : text;
}
function normalizeProviderError(error) {
  if (error instanceof ProviderError) return error;
  return new ProviderError("generation_failed", redactSecrets(error instanceof Error ? error.message : "\u751F\u6210\u5931\u8D25\u3002"));
}
function isProviderBalanceMessage(message) {
  return /insufficient[_\s-]*(quota|balance|credit|funds)|billing|payment required|余额不足|额度不足|余额|欠费|quota exceeded/i.test(message);
}
function isProviderContentRejectedMessage(message) {
  return /content[_\s-]*policy|policy[_\s-]*violation|safety|moderation|unsafe|blocked by policy|内容审核|安全策略|审核|违规/i.test(message);
}
function resolveGenerationTimeoutMs(value) {
  return Math.min(Math.max(envNumber(value, DEFAULT_GENERATION_TIMEOUT_MS), 1e3), MAX_QUEUE_CONSUMER_TIMEOUT_MS);
}
function resolveGenerationJobMaxRuntimeMs(value) {
  return Math.min(Math.max(envNumber(value, DEFAULT_GENERATION_JOB_MAX_RUNTIME_MS), MIN_GENERATION_JOB_MAX_RUNTIME_MS), MAX_QUEUE_CONSUMER_TIMEOUT_MS);
}
function resolveProviderImageConcurrency(value) {
  return Math.min(Math.max(Math.trunc(envNumber(value, DEFAULT_PROVIDER_IMAGE_CONCURRENCY)), 1), MAX_PROVIDER_IMAGE_CONCURRENCY);
}
function resolvePromptOptimizerModel(value) {
  const model = value?.trim();
  return model && PROMPT_OPTIMIZER_MODELS.has(model) ? model : DEFAULT_PROMPT_OPTIMIZER_MODEL;
}
function resolveResponsesModel(value, fallbackValue) {
  const model = value?.trim();
  if (model && !isImageOnlyModel(model)) return model;
  const fallbackModel = fallbackValue?.trim();
  if (fallbackModel && !isImageOnlyModel(fallbackModel)) return fallbackModel;
  return DEFAULT_RESPONSES_MODEL;
}
function extractResponsesOutputText(response) {
  if (typeof response.output_text === "string" && response.output_text.trim()) {
    return response.output_text;
  }
  if (!Array.isArray(response.output)) return "";
  const chunks = [];
  for (const outputItem of response.output) {
    if (!outputItem || typeof outputItem !== "object") continue;
    const content = outputItem.content;
    if (!Array.isArray(content)) continue;
    for (const contentItem of content) {
      if (!contentItem || typeof contentItem !== "object") continue;
      const item = contentItem;
      if (item.type === "output_text" && typeof item.text === "string") {
        chunks.push(item.text);
      }
    }
  }
  return chunks.join("\n");
}
function buildImageGenerationPayload(job, count) {
  const payload = {
    model: job.model,
    prompt: buildProviderImagePrompt(job),
    n: count,
    size: `${job.width}x${job.height}`,
    quality: job.quality,
    output_format: job.output_format,
    background: resolveImageBackground(job.prompt, job.output_format, job.background),
    moderation: job.moderation,
    user: job.space_id
  };
  if (job.output_format !== "png" && job.compression !== null) {
    payload.output_compression = job.compression;
  }
  return payload;
}
function buildProviderImagePrompt(job) {
  const prompt = job.prompt.trim();
  const referenceContext = referencePromptContext(job);
  return [prompt, referenceContext, job.mask_image_storage_key ? MASKED_IMAGE_EDIT_PROMPT_SUFFIX : ""].filter(Boolean).join("\n\n");
}
function referencePromptContext(job) {
  const snapshots = parseReferenceImagesJson(job.reference_images_json);
  if (!job.reference_image_storage_key && snapshots.length === 0) return "";
  const hasSource = Boolean(job.mask_image_storage_key) || snapshots.some((snapshot) => snapshot.role === "source");
  return hasSource ? SOURCE_IMAGE_PROMPT_SUFFIX : REFERENCE_IMAGE_PROMPT_SUFFIX;
}
function imageGenerationEndpointPath(job) {
  return hasReferenceImages(job) ? "/images/edits" : "/images/generations";
}
function resolveImageBackground(prompt, outputFormat, configuredBackground = "auto") {
  if (outputFormat === "jpeg") {
    return configuredBackground === "opaque" ? "opaque" : "auto";
  }
  if (configuredBackground === "opaque" || configuredBackground === "transparent") {
    return configuredBackground;
  }
  return promptRequestsTransparentBackground(prompt) ? "transparent" : "auto";
}
function promptRequestsTransparentBackground(prompt) {
  const normalized = prompt.trim().toLowerCase();
  if (!normalized) return false;
  const negativePatterns = [
    /不(?:要|需要)?透明背景/,
    /不要背景透明/,
    /无需透明背景/,
    /非透明背景/,
    /不透明背景/,
    /\bno transparent background\b/,
    /\bnot transparent background\b/,
    /\bwithout transparent background\b/,
    /\bopaque background\b/,
    /\bsolid background\b/
  ];
  if (negativePatterns.some((pattern) => pattern.test(normalized))) return false;
  const positivePatterns = [
    /透明(?:背景|底|底色)/,
    /背景透明/,
    /透明通道/,
    /alpha\s*通道/,
    /无背景/,
    /去(?:除)?背景/,
    /去背/,
    /抠图/,
    /\btransparent background\b/,
    /\bbackground transparent\b/,
    /\bwith transparency\b/,
    /\balpha channel\b/,
    /\bno background\b/,
    /\bremove(?:d)? background\b/,
    /\bbackground removed\b/,
    /\bcutout\b/
  ];
  return positivePatterns.some((pattern) => pattern.test(normalized));
}
function buildImageGenerationFormData(payload, referenceImages, maskImage) {
  const formData = new FormData();
  appendImageGenerationFormFields(formData, payload);
  const images = Array.isArray(referenceImages) ? referenceImages : [referenceImages];
  for (const referenceImage of images) {
    formData.append("image[]", referenceImage.blob, referenceImage.filename);
  }
  if (maskImage) {
    formData.append("mask", maskImage.blob, maskImage.filename);
  }
  return formData;
}
function appendImageGenerationFormFields(formData, payload) {
  for (const [key, value] of Object.entries(payload)) {
    formData.set(key, String(value));
  }
}
async function loadReferenceImageBlobs(job, env) {
  const snapshots = referenceImageSnapshots(job);
  if (snapshots.length === 0) {
    throw new ProviderError("reference_image_missing", "\u53C2\u8003\u56FE\u6587\u4EF6\u4E0D\u5B58\u5728\uFF0C\u8BF7\u91CD\u65B0\u4E0A\u4F20\u540E\u518D\u8BD5\u3002");
  }
  return Promise.all(snapshots.map((snapshot) => loadReferenceSnapshotBlob(snapshot, env)));
}
async function loadReferenceSnapshotBlob(snapshot, env) {
  const referenceObject = await env.IMAGES.get(snapshot.storageKey);
  if (!referenceObject) {
    throw new ProviderError("reference_image_missing", "\u53C2\u8003\u56FE\u6587\u4EF6\u4E0D\u5B58\u5728\uFF0C\u8BF7\u91CD\u65B0\u4E0A\u4F20\u540E\u518D\u8BD5\u3002");
  }
  const referenceBytes = await referenceObject.arrayBuffer();
  const referenceMimeType = snapshot.mimeType || referenceObject.httpMetadata?.contentType || "image/png";
  const extension = referenceMimeType === "image/jpeg" ? "jpg" : referenceMimeType === "image/webp" ? "webp" : "png";
  return {
    blob: new Blob([referenceBytes], { type: referenceMimeType }),
    filename: snapshot.name || `reference.${extension}`
  };
}
function referenceImageSnapshots(job) {
  const parsed = parseReferenceImagesJson(job.reference_images_json);
  if (parsed.length > 0) return parsed;
  if (!job.reference_image_storage_key) return [];
  return [
    {
      storageKey: job.reference_image_storage_key,
      mimeType: job.reference_image_mime_type ?? "image/png",
      name: job.reference_image_name ?? "reference.png",
      byteSize: job.reference_image_byte_size ?? 0
    }
  ];
}
function parseReferenceImagesJson(value) {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    if (!Array.isArray(parsed)) return [];
    return parsed.map((item) => {
      if (!item || typeof item !== "object") return null;
      const record = item;
      const storageKey = typeof record.storageKey === "string" ? record.storageKey : "";
      if (!storageKey) return null;
      return {
        storageKey,
        mimeType: typeof record.mimeType === "string" ? record.mimeType : "image/png",
        name: typeof record.name === "string" ? record.name : "reference.png",
        byteSize: typeof record.byteSize === "number" ? record.byteSize : 0,
        ...record.role === "source" || record.role === "reference" ? { role: record.role } : {}
      };
    }).filter((item) => Boolean(item));
  } catch {
    return [];
  }
}
function hasReferenceImages(job) {
  return Boolean(job.reference_image_storage_key || parseReferenceImagesJson(job.reference_images_json).length > 0);
}
function availableResultIndexes(quantity, existingResults, existingImageCount) {
  const succeeded = new Set(existingResults.filter((result) => result.status === "succeeded").map((result) => result.result_index));
  const indexes = [];
  for (let index = 0; index < quantity; index += 1) {
    if (!succeeded.has(index)) indexes.push(index);
  }
  if (indexes.length > 0) return indexes;
  return Array.from({ length: Math.max(0, quantity - existingImageCount) }, (_, index) => existingImageCount + index);
}
async function completedSlotCount(env, job) {
  const images = await listImagesForJob(env.DB, job.space_id, job.id);
  return images.length;
}
function generationResultId(jobId, resultIndex) {
  return `res_${jobId}_${resultIndex}`;
}
function imageIdForResult(jobId, resultIndex) {
  return `img_${jobId}_${resultIndex}`;
}
function storageKeyForResult(job, imageId, format) {
  return `${job.space_id}/${job.id}/${imageId}.${format}`;
}
async function loadSharp() {
  try {
    const sharpModule = await import("sharp");
    return sharpModule.default ?? sharpModule;
  } catch {
    return null;
  }
}
async function thumbnailMetadataForResult(job, imageId, bytes) {
  const sharp = await loadSharp();
  if (!sharp) return null;
  return sharp(bytes, { failOn: "none" }).rotate().resize({
    width: GENERATED_THUMBNAIL_MAX_EDGE_PX,
    height: GENERATED_THUMBNAIL_MAX_EDGE_PX,
    fit: "inside",
    withoutEnlargement: true
  }).webp({ quality: GENERATED_THUMBNAIL_WEBP_QUALITY }).toBuffer().then((thumbnailBytes) => ({
    storageKey: `${job.space_id}/${job.id}/thumb_${imageId}.webp`,
    mimeType: "image/webp",
    format: "webp",
    bytes: thumbnailBytes
  })).catch(() => null);
}
async function persistGeneratedThumbnailBestEffort(job, env, imageId, resultIndex, bytes) {
  const thumbnail = await thumbnailMetadataForResult(job, imageId, bytes);
  if (!thumbnail) return null;
  try {
    await env.IMAGES.put(thumbnail.storageKey, thumbnail.bytes, {
      httpMetadata: {
        contentType: thumbnail.mimeType,
        contentDisposition: `inline; filename="${imageId}-thumbnail.${thumbnail.format}"`
      },
      customMetadata: {
        jobId: job.id,
        spaceId: job.space_id,
        resultIndex: String(resultIndex),
        sourceImageId: imageId,
        kind: "thumbnail"
      }
    });
    return thumbnail;
  } catch (error) {
    console.warn("generated thumbnail persistence skipped", redactSecrets(error instanceof Error ? error.message : "unknown error"));
    return null;
  }
}
async function loadMaskImageBlob(job, env) {
  if (!job.mask_image_storage_key) {
    throw new ProviderError("mask_image_missing", "\u9009\u533A\u906E\u7F69\u6587\u4EF6\u4E0D\u5B58\u5728\uFF0C\u8BF7\u91CD\u65B0\u6D82\u62B9\u540E\u518D\u8BD5\u3002");
  }
  const maskObject = await env.IMAGES.get(job.mask_image_storage_key);
  if (!maskObject) {
    throw new ProviderError("mask_image_missing", "\u9009\u533A\u906E\u7F69\u6587\u4EF6\u4E0D\u5B58\u5728\uFF0C\u8BF7\u91CD\u65B0\u6D82\u62B9\u540E\u518D\u8BD5\u3002");
  }
  const maskBytes = await maskObject.arrayBuffer();
  return {
    blob: new Blob([maskBytes], { type: "image/png" }),
    filename: job.mask_image_name ?? "mask.png"
  };
}
function isImageOnlyModel(model) {
  const normalized = model.toLowerCase();
  return normalized.startsWith("image-") || normalized.startsWith("gpt-image") || normalized.startsWith("dall-e");
}
function formatDuration(ms) {
  const seconds = Math.round(ms / 1e3);
  if (seconds < 60) return `${seconds} \u79D2`;
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return remainingSeconds ? `${minutes} \u5206 ${remainingSeconds} \u79D2` : `${minutes} \u5206\u949F`;
}
function providerTimestampMs(value) {
  if (!value) return Number.NaN;
  return Date.parse(/[zZ]|[+-]\d{2}:\d{2}$/.test(value) ? value : `${value.replace(" ", "T")}Z`);
}
function mimeFromFormat(format) {
  if (format === "webp") return "image/webp";
  if (format === "jpeg") return "image/jpeg";
  return "image/png";
}
function normalizeProviderContentType(value) {
  const normalized = value?.split(";")[0]?.trim().toLowerCase();
  if (!normalized) return null;
  if (normalized === "image/jpg") return "image/jpeg";
  return normalized;
}
function providerImageFormatFromResponse(contentType, rawUrl, fallbackFormat) {
  const fromMime = formatFromMimeType(contentType);
  if (fromMime) return fromMime;
  const fromUrl = formatFromImageUrl(rawUrl);
  if (fromUrl) return fromUrl;
  return normalizeProviderImageFormat(fallbackFormat);
}
function formatFromMimeType(contentType) {
  if (contentType === "image/png") return "png";
  if (contentType === "image/webp") return "webp";
  if (contentType === "image/jpeg") return "jpeg";
  return null;
}
function isTransientProviderImageContentType(contentType) {
  return contentType === "text/html" || contentType === "application/json" || contentType === "application/xml" || contentType === "text/xml" || contentType === "text/javascript" || contentType === "application/javascript";
}
function isAcceptedProviderImageContentType(contentType) {
  if (!contentType || formatFromMimeType(contentType)) return true;
  return contentType === "application/octet-stream" || contentType === "binary/octet-stream" || contentType === "application/binary" || contentType === "application/force-download" || contentType === "application/download" || contentType === "text/plain";
}
function formatFromImageUrl(rawUrl) {
  try {
    const pathname = new URL(rawUrl).pathname.toLowerCase();
    if (pathname.endsWith(".png")) return "png";
    if (pathname.endsWith(".webp")) return "webp";
    if (pathname.endsWith(".jpg") || pathname.endsWith(".jpeg")) return "jpeg";
  } catch {
    return null;
  }
  return null;
}
function normalizeProviderImageFormat(format) {
  return format === "jpeg" || format === "webp" ? format : "png";
}
function providerImageBinaryFromBytes(bytes, fallbackFormat) {
  const format = formatFromImageBytes(bytes);
  if (!format) {
    throw new ProviderError("provider_image_invalid_data", "\u6A21\u578B\u670D\u52A1\u8FD4\u56DE\u7684\u5185\u5BB9\u4E0D\u662F\u6709\u6548\u7684 PNG\u3001JPEG \u6216 WebP \u56FE\u7247\u3002");
  }
  void fallbackFormat;
  return { bytes, format, mimeType: mimeFromFormat(format) };
}
function formatFromImageBytes(bytes) {
  if (bytes.length >= 8 && bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71 && bytes[4] === 13 && bytes[5] === 10 && bytes[6] === 26 && bytes[7] === 10) {
    return "png";
  }
  if (bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return "jpeg";
  if (bytes.length >= 12 && bytes[0] === 82 && bytes[1] === 73 && bytes[2] === 70 && bytes[3] === 70 && bytes[8] === 87 && bytes[9] === 69 && bytes[10] === 66 && bytes[11] === 80) {
    return "webp";
  }
  return null;
}
var PROMPT_OPTIMIZER_INSTRUCTIONS = [
  "\u4F60\u662F\u56FE\u7247\u751F\u6210\u63D0\u793A\u8BCD\u4F18\u5316\u5668\u3002",
  "\u57FA\u4E8E\u7528\u6237\u539F\u59CB\u610F\u56FE\u4F18\u5316\u63D0\u793A\u8BCD\uFF0C\u8BA9\u5B83\u66F4\u9002\u5408\u9AD8\u8D28\u91CF\u56FE\u7247\u751F\u6210\u3002",
  "\u8865\u5F3A\u4E3B\u4F53\u3001\u6784\u56FE\u3001\u6750\u8D28\u3001\u98CE\u683C\u3001\u955C\u5934\u3001\u5149\u7EBF\u3001\u8272\u5F69\u548C\u7EC6\u8282\uFF0C\u4F46\u4E0D\u8981\u6539\u53D8\u7528\u6237\u60F3\u751F\u6210\u7684\u6838\u5FC3\u5185\u5BB9\u3002",
  "\u5982\u679C\u5B58\u5728\u53C2\u8003\u56FE\uFF0C\u4E25\u683C\u4FDD\u7559\u7528\u6237\u5BF9\u7B2C1\u5F20\u3001\u7B2C2\u5F20\u7B49\u56FE\u7247\u89D2\u8272\u548C\u987A\u5E8F\u7684\u63CF\u8FF0\uFF0C\u4E0D\u8981\u91CD\u65B0\u5206\u914D\u89D2\u8272\u3002",
  "\u660E\u786E\u533A\u5206\u5FC5\u987B\u4FDD\u6301\u7684\u5185\u5BB9\u4E0E\u5FC5\u987B\u6539\u53D8\u7684\u5185\u5BB9\uFF1B\u4E0D\u8981\u628A\u2018\u4FDD\u6301\u57FA\u672C\u5F62\u72B6\u2019\u6269\u5927\u6210\u989C\u8272\u3001\u6750\u8D28\u3001\u5149\u7EBF\u548C\u7EC6\u8282\u90FD\u5B8C\u5168\u4E0D\u53D8\u3002",
  "\u7528\u6237\u8981\u6C42\u4FEE\u6B63\u3001\u53D8\u5316\u6216\u98CE\u683C\u8FC1\u79FB\u65F6\uFF0C\u8BA9\u76EE\u6807\u53D8\u5316\u6E05\u6670\u53EF\u89C1\uFF0C\u5E76\u907F\u514D\u540C\u65F6\u52A0\u5165\u4E92\u76F8\u51B2\u7A81\u7684\u4FDD\u6301\u4E0E\u6539\u53D8\u7EA6\u675F\u3002",
  "\u4FDD\u7559\u7528\u6237\u4F7F\u7528\u7684\u4E3B\u8981\u8BED\u8A00\uFF1B\u5982\u679C\u7528\u6237\u6DF7\u5408\u4E2D\u82F1\u6587\uFF0C\u53EF\u4EE5\u6DF7\u5408\u8F93\u51FA\u3002",
  "\u53EA\u8F93\u51FA\u4F18\u5316\u540E\u7684\u63D0\u793A\u8BCD\u672C\u8EAB\uFF0C\u4E0D\u8F93\u51FA\u89E3\u91CA\u3001\u6807\u9898\u3001\u7F16\u53F7\u3001Markdown \u6216\u5F15\u53F7\u3002"
].join("\n");
function promptOptimizationInput(input) {
  return [
    `\u539F\u59CB\u63D0\u793A\u8BCD\uFF1A${input.prompt}`,
    "",
    "\u5F53\u524D\u751F\u6210\u53C2\u6570\uFF1A",
    `- \u6BD4\u4F8B\uFF1A${input.aspectRatio}`,
    `- \u5C3A\u5BF8\uFF1A${input.width}x${input.height}`,
    `- \u8D28\u91CF\uFF1A${input.quality}`,
    `- \u8F93\u51FA\u683C\u5F0F\uFF1A${input.outputFormat}`,
    `- \u53C2\u8003\u56FE\u6570\u91CF\uFF1A${input.referenceImageCount}`,
    `- \u662F\u5426\u57FA\u4E8E\u5DF2\u6709\u751F\u6210\u56FE\u7EE7\u7EED\u521B\u4F5C\uFF1A${input.hasSourceImage ? "\u662F\uFF1B\u7B2C1\u5F20\u56FE\u662F\u5F53\u524D\u7F16\u8F91\u76EE\u6807" : "\u5426"}`,
    `- \u662F\u5426\u4E3A\u5C40\u90E8\u91CD\u7ED8\uFF1A${input.hasMaskImage ? "\u662F\uFF1B\u53EA\u6539\u906E\u7F69\u9009\u533A\uFF0C\u672A\u9009\u533A\u57DF\u4FDD\u6301\u4E0D\u53D8" : "\u5426"}`,
    "- \u80CC\u666F\uFF1A\u6839\u636E\u539F\u59CB\u63D0\u793A\u8BCD\u5224\u65AD\uFF1B\u5982\u679C\u539F\u59CB\u63D0\u793A\u8BCD\u660E\u786E\u8981\u6C42\u900F\u660E\u80CC\u666F\uFF0C\u8BF7\u5728\u4F18\u5316\u7ED3\u679C\u4E2D\u4FDD\u7559\u8BE5\u8981\u6C42\uFF0C\u5426\u5219\u4E0D\u8981\u989D\u5916\u6DFB\u52A0\u900F\u660E\u80CC\u666F\u8981\u6C42\u3002"
  ].join("\n");
}

// src/worker/validation.ts
var RATIO_TO_SIZE = {
  "16:9": [1536, 864],
  "9:16": [864, 1536],
  "4:3": [1536, 1152],
  "3:4": [1152, 1536],
  "3:2": [1536, 1024],
  "2:3": [1024, 1536],
  "1:1": [1024, 1024]
};
var QUALITIES = /* @__PURE__ */ new Set(["auto", "low", "medium", "high"]);
var FORMATS = /* @__PURE__ */ new Set(["png", "webp", "jpeg"]);
var BACKGROUNDS = /* @__PURE__ */ new Set(["auto", "opaque", "transparent"]);
var MODERATIONS = /* @__PURE__ */ new Set(["auto", "low"]);
function parseGenerationInput(raw, maxImagesValue) {
  if (!raw || typeof raw !== "object") return { error: "\u8BF7\u6C42\u4F53\u683C\u5F0F\u4E0D\u6B63\u786E\u3002" };
  const body = raw;
  const maxImages = Math.min(envNumber(maxImagesValue, 4), 10);
  const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
  const model = typeof body.model === "string" ? body.model.trim() : "";
  if (!prompt) return { error: "\u8BF7\u8F93\u5165\u63D0\u793A\u8BCD\u3002" };
  if (prompt.length > 32e3) return { error: "\u63D0\u793A\u8BCD\u6700\u591A 32000 \u4E2A\u5B57\u7B26\u3002" };
  const aspectRatio2 = typeof body.aspectRatio === "string" ? body.aspectRatio : "1:1";
  const ratioSize = RATIO_TO_SIZE[aspectRatio2];
  const hasExplicitSize = body.width !== void 0 && body.height !== void 0;
  let width = hasExplicitSize ? toInt(body.width, ratioSize?.[0] ?? 1024) : ratioSize?.[0] ?? toInt(body.width, 1024);
  let height = hasExplicitSize ? toInt(body.height, ratioSize?.[1] ?? 1024) : ratioSize?.[1] ?? toInt(body.height, 1024);
  const quality = typeof body.quality === "string" && QUALITIES.has(body.quality) ? body.quality : "auto";
  const quantity = toInt(body.quantity, 1);
  const outputFormat = typeof body.outputFormat === "string" && FORMATS.has(body.outputFormat) ? body.outputFormat : "png";
  const background = typeof body.background === "string" && BACKGROUNDS.has(body.background) ? body.background : "auto";
  const compression = toInt(body.compression, 100);
  const moderation = typeof body.moderation === "string" && MODERATIONS.has(body.moderation) ? body.moderation : "auto";
  const turnstileToken = typeof body.turnstileToken === "string" ? body.turnstileToken : void 0;
  if (quantity < 1 || quantity > maxImages) return { error: `\u5355\u6B21\u751F\u6210\u6570\u91CF\u5FC5\u987B\u5728 1-${maxImages} \u4E4B\u95F4\u3002` };
  const sizeError = validateSize(width, height);
  if (sizeError) return { error: sizeError };
  if (ratioSize && hasExplicitSize && !matchesRatio(width, height, ratioSize[0], ratioSize[1])) {
    return { error: "\u5BBD\u9AD8\u5FC5\u987B\u5339\u914D\u6240\u9009\u56FE\u7247\u6BD4\u4F8B\u3002" };
  }
  if (compression < 0 || compression > 100) return { error: "\u538B\u7F29\u7387\u5FC5\u987B\u5728 0-100 \u4E4B\u95F4\u3002" };
  if (background === "transparent" && outputFormat === "jpeg") {
    return { error: "\u900F\u660E\u80CC\u666F\u53EA\u80FD\u4F7F\u7528 PNG \u6216 WebP \u683C\u5F0F\u3002" };
  }
  return {
    input: {
      prompt,
      ...model ? { model } : {},
      aspectRatio: aspectRatio2,
      width,
      height,
      quality,
      quantity,
      outputFormat,
      background,
      compression,
      moderation,
      turnstileToken
    }
  };
}
function parsePromptOptimizationInput(raw) {
  if (!raw || typeof raw !== "object") return { error: "\u8BF7\u6C42\u4F53\u683C\u5F0F\u4E0D\u6B63\u786E\u3002" };
  const body = raw;
  const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
  if (!prompt) return { error: "\u8BF7\u8F93\u5165\u63D0\u793A\u8BCD\u3002" };
  if (prompt.length > 32e3) return { error: "\u63D0\u793A\u8BCD\u6700\u591A 32000 \u4E2A\u5B57\u7B26\u3002" };
  const aspectRatio2 = typeof body.aspectRatio === "string" && body.aspectRatio.trim() ? body.aspectRatio.trim() : "1:1";
  const ratioSize = RATIO_TO_SIZE[aspectRatio2];
  const width = toInt(body.width, ratioSize?.[0] ?? 1024);
  const height = toInt(body.height, ratioSize?.[1] ?? 1024);
  const quality = typeof body.quality === "string" && QUALITIES.has(body.quality) ? body.quality : "auto";
  const outputFormat = typeof body.outputFormat === "string" && FORMATS.has(body.outputFormat) ? body.outputFormat : "png";
  const background = typeof body.background === "string" && BACKGROUNDS.has(body.background) ? body.background : "auto";
  const referenceImageCount = Math.min(Math.max(toInt(body.referenceImageCount, 0), 0), 8);
  const hasSourceImage = body.hasSourceImage === true;
  const hasMaskImage = body.hasMaskImage === true;
  return {
    input: {
      prompt,
      aspectRatio: aspectRatio2,
      width,
      height,
      quality,
      outputFormat,
      background,
      referenceImageCount,
      hasSourceImage,
      hasMaskImage
    }
  };
}
function validateSize(width, height) {
  if (!Number.isInteger(width) || !Number.isInteger(height)) return "\u5BBD\u9AD8\u5FC5\u987B\u662F\u6574\u6570\u3002";
  if (width < 16 || height < 16) return "\u5BBD\u9AD8\u4E0D\u80FD\u5C0F\u4E8E 16\u3002";
  if (width % 16 !== 0 || height % 16 !== 0) return "\u5BBD\u9AD8\u5FC5\u987B\u80FD\u88AB 16 \u6574\u9664\u3002";
  const ratio = width / height;
  if (ratio < 1 / 3 || ratio > 3) return "\u56FE\u7247\u6BD4\u4F8B\u5FC5\u987B\u5728 1:3 \u5230 3:1 \u4E4B\u95F4\u3002";
  if (width > 3840 || height > 3840) return "\u56FE\u7247\u957F\u8FB9\u4E0D\u80FD\u8D85\u8FC7 3840px\u3002";
  const totalPixels = width * height;
  if (totalPixels < 655360 || totalPixels > 8294400) return "\u56FE\u7247\u603B\u50CF\u7D20\u5FC5\u987B\u5728 655360 \u5230 8294400 \u4E4B\u95F4\u3002";
  return null;
}
function matchesRatio(width, height, ratioWidth, ratioHeight) {
  const actual = width / height;
  const expected = ratioWidth / ratioHeight;
  return Math.abs(actual - expected) / expected < 0.015;
}
function toInt(value, fallback) {
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? Math.trunc(parsed) : fallback;
}

// src/worker/index.ts
var SESSION_COOKIE = "image2_session";
var SESSION_DAYS = 30;
var SOURCE_IMAGE_ID_FIELD = "sourceImageId";
var LEGACY_SOURCE_IMAGE_ID_FIELD = "referenceImageId";
var REFERENCE_IMAGE_FIELD = "referenceImage";
var MASK_IMAGE_FIELD = "maskImage";
var REFERENCE_IMAGE_MAX_BYTES = 10 * 1024 * 1024;
var MAX_REFERENCE_IMAGES = 8;
var MASK_IMAGE_MAX_BYTES = 10 * 1024 * 1024;
var REFERENCE_IMAGE_MIME_TYPES = /* @__PURE__ */ new Set(["image/png", "image/jpeg", "image/webp"]);
var MASK_IMAGE_MIME_TYPES = /* @__PURE__ */ new Set(["image/png"]);
var IMAGE_MODEL_OPTIONS = ["image-2.5", "gpt-image-2"];
var PROMPT_OPTIMIZER_MODEL_OPTIONS = ["gpt-5.5", "gpt-5.4"];
var DEFAULT_PROVIDER_RETRY_ATTEMPTS = 0;
var MAX_PROVIDER_RETRY_ATTEMPTS = 4;
var DEFAULT_POST_PROCESSING_RETRY_ATTEMPTS = 2;
var MAX_POST_PROCESSING_RETRY_ATTEMPTS = 4;
var IMAGE_CACHE_CONTROL = "private, max-age=31536000, immutable";
var app = new Hono();
app.use("/api/*", cors({ origin: [], credentials: true }));
app.onError((error, c) => {
  if ("res" in error && error.res instanceof Response) return error.res;
  console.error(error);
  return c.json({ ok: false, error: { code: "internal_error", message: "\u670D\u52A1\u6682\u65F6\u4E0D\u53EF\u7528\u3002" } }, 500);
});
async function parseGenerationRequest(request) {
  const contentType = request.headers.get("content-type") ?? "";
  if (contentType.toLowerCase().includes("multipart/form-data")) {
    const formData = await request.formData().catch(() => null);
    if (!formData) return { body: null, referenceImages: [] };
    const body2 = {};
    for (const [key, value] of formData.entries()) {
      if (key === REFERENCE_IMAGE_FIELD || key === MASK_IMAGE_FIELD || value instanceof File) continue;
      body2[key] = value;
    }
    const uploadedImages = formData.getAll(REFERENCE_IMAGE_FIELD).filter((value) => value instanceof File && value.size > 0);
    const uploadedMask = formData.get(MASK_IMAGE_FIELD);
    return {
      body: body2,
      referenceImages: uploadedImages,
      maskImage: uploadedMask instanceof File && uploadedMask.size > 0 ? uploadedMask : void 0
    };
  }
  const body = await request.json().catch(() => null);
  return { body: body && typeof body === "object" ? body : null, referenceImages: [] };
}
async function storeReferenceImage(env, spaceId, jobId, file, index = 0) {
  const mimeType = normalizeReferenceImageMime(file.type);
  if (!REFERENCE_IMAGE_MIME_TYPES.has(mimeType)) {
    throw jsonError(400, "invalid_reference_image", "\u53C2\u8003\u56FE\u4EC5\u652F\u6301 PNG\u3001JPEG \u6216 WebP \u683C\u5F0F\u3002");
  }
  if (file.size > REFERENCE_IMAGE_MAX_BYTES) {
    throw jsonError(400, "reference_image_too_large", "\u53C2\u8003\u56FE\u4E0D\u80FD\u8D85\u8FC7 10MB\u3002");
  }
  const bytes = await file.arrayBuffer();
  const extension = extensionForReferenceImage(mimeType);
  const name = safeReferenceImageName(file.name, extension);
  const storageKey = `${spaceId}/${jobId}/reference-${index + 1}.${extension}`;
  await env.IMAGES.put(storageKey, bytes, {
    httpMetadata: {
      contentType: mimeType,
      contentDisposition: `inline; filename="${name}"`
    },
    customMetadata: {
      jobId,
      spaceId,
      kind: "reference",
      referenceIndex: String(index + 1)
    }
  });
  return {
    storageKey,
    mimeType,
    name,
    byteSize: bytes.byteLength,
    role: "reference"
  };
}
async function storeReferenceImages(env, spaceId, jobId, files, startIndex = 0) {
  if (files.length + startIndex > MAX_REFERENCE_IMAGES) {
    throw jsonError(400, "too_many_reference_images", `\u53C2\u8003\u56FE\u6700\u591A ${MAX_REFERENCE_IMAGES} \u5F20\u3002`);
  }
  return Promise.all(files.map((file, index) => storeReferenceImage(env, spaceId, jobId, file, index + startIndex)));
}
async function cloneSourceImageAsReference(env, spaceId, jobId, sourceImageId) {
  const sourceImage = await getImage(env.DB, spaceId, sourceImageId);
  if (!sourceImage) {
    throw jsonError(404, "source_image_not_found", "\u6E90\u56FE\u7247\u4E0D\u5B58\u5728\u3002");
  }
  const mimeType = normalizeReferenceImageMime(sourceImage.mime_type);
  if (!REFERENCE_IMAGE_MIME_TYPES.has(mimeType)) {
    throw jsonError(400, "invalid_source_image", "\u6E90\u56FE\u7247\u683C\u5F0F\u4E0D\u652F\u6301\u7F16\u8F91\u3002");
  }
  const extension = extensionForReferenceImage(mimeType);
  const name = safeReferenceImageName(`${sourceImage.id}.${extension}`, extension);
  const storageKey = `${spaceId}/${jobId}/reference-1.${extension}`;
  const putOptions = {
    httpMetadata: {
      contentType: mimeType,
      contentDisposition: `inline; filename="${name}"`
    },
    customMetadata: {
      jobId,
      spaceId,
      kind: "source",
      referenceIndex: "1"
    }
  };
  if (env.IMAGES.copy) {
    await env.IMAGES.copy(sourceImage.storage_key, storageKey, putOptions);
  } else {
    const sourceObject = await env.IMAGES.get(sourceImage.storage_key);
    if (!sourceObject) {
      throw jsonError(404, "source_image_file_missing", "\u6E90\u56FE\u7247\u6587\u4EF6\u4E0D\u5B58\u5728\u3002");
    }
    await env.IMAGES.put(storageKey, await sourceObject.arrayBuffer(), putOptions);
  }
  return {
    storageKey,
    mimeType,
    name,
    byteSize: sourceImage.byte_size,
    role: "source"
  };
}
async function storeMaskImage(env, spaceId, jobId, file) {
  const mimeType = normalizeReferenceImageMime(file.type);
  if (!MASK_IMAGE_MIME_TYPES.has(mimeType)) {
    throw jsonError(400, "invalid_mask_image", "\u9009\u533A\u906E\u7F69\u4EC5\u652F\u6301 PNG \u683C\u5F0F\u3002");
  }
  if (file.size > MASK_IMAGE_MAX_BYTES) {
    throw jsonError(400, "mask_image_too_large", "\u9009\u533A\u906E\u7F69\u4E0D\u80FD\u8D85\u8FC7 10MB\u3002");
  }
  const bytes = await file.arrayBuffer();
  const name = safeReferenceImageName(file.name, "png");
  const storageKey = `${spaceId}/${jobId}/mask.png`;
  await env.IMAGES.put(storageKey, bytes, {
    httpMetadata: {
      contentType: "image/png",
      contentDisposition: `inline; filename="${name}"`
    },
    customMetadata: {
      jobId,
      spaceId,
      kind: "mask"
    }
  });
  return {
    storageKey,
    mimeType: "image/png",
    name,
    byteSize: bytes.byteLength
  };
}
function normalizeReferenceImageMime(value) {
  const mimeType = value.trim().toLowerCase();
  return mimeType === "image/jpg" ? "image/jpeg" : mimeType;
}
function extensionForReferenceImage(mimeType) {
  if (mimeType === "image/jpeg") return "jpg";
  if (mimeType === "image/webp") return "webp";
  return "png";
}
function safeReferenceImageName(value, extension) {
  const fallback = `reference.${extension}`;
  const safe = (value || fallback).replace(/[^\w.-]/g, "_").slice(0, 120);
  return safe || fallback;
}
async function assertGenerationLimitsForRequest(env, spaceId, requestedImages) {
  const runningLimit = envNumber(env.MAX_RUNNING_JOBS_PER_SPACE, 2);
  if (await countActiveJobs(env.DB, spaceId) >= runningLimit) {
    await insertRateLimitEvent(env.DB, spaceId, "active_generation_limit");
    throw jsonError(429, "active_limit_reached", `\u540C\u65F6\u8FD0\u884C\u4EFB\u52A1\u6700\u591A ${runningLimit} \u4E2A\u3002`);
  }
}
function hasImageProviderConfigured(credential) {
  return Boolean(credential?.base_url && credential.encrypted_api_key);
}
function hasPromptProviderConfigured(credential) {
  return Boolean(credential?.prompt_base_url && credential.prompt_encrypted_api_key);
}
function generationInputFromJob(job) {
  return {
    prompt: job.prompt,
    aspectRatio: job.aspect_ratio,
    width: job.width,
    height: job.height,
    quality: job.quality,
    quantity: job.quantity,
    outputFormat: job.output_format,
    background: job.background,
    compression: job.compression ?? 100,
    moderation: job.moderation
  };
}
async function cloneReferenceImage(env, spaceId, nextJobId, sourceJob) {
  const snapshots = referenceImagesFromJob(sourceJob);
  if (snapshots.length === 0) return [];
  const copied = [];
  for (const [index, snapshot] of snapshots.entries()) {
    const sourceObject = await env.IMAGES.get(snapshot.storageKey);
    if (!sourceObject) {
      throw jsonError(404, "reference_image_missing", "\u53C2\u8003\u56FE\u6587\u4EF6\u4E0D\u5B58\u5728\uFF0C\u8BF7\u91CD\u65B0\u4E0A\u4F20\u540E\u518D\u8BD5\u3002");
    }
    const mimeType = snapshot.mimeType ?? sourceObject.httpMetadata?.contentType ?? "image/png";
    const extension = extensionForReferenceImage(mimeType);
    const name = safeReferenceImageName(snapshot.name ?? "", extension);
    const bytes = await sourceObject.arrayBuffer();
    const storageKey = `${spaceId}/${nextJobId}/reference-${index + 1}.${extension}`;
    await env.IMAGES.put(storageKey, bytes, {
      httpMetadata: {
        contentType: mimeType,
        contentDisposition: `inline; filename="${name}"`
      },
      customMetadata: {
        jobId: nextJobId,
        spaceId,
        kind: snapshot.role === "source" ? "source" : "reference",
        referenceIndex: String(index + 1)
      }
    });
    copied.push({
      storageKey,
      mimeType,
      name,
      byteSize: bytes.byteLength,
      ...snapshot.role ? { role: snapshot.role } : {}
    });
  }
  return copied;
}
function referenceImagesFromJob(job) {
  const parsed = parseReferenceImagesJson2(job.reference_images_json);
  if (parsed.length > 0) return parsed;
  if (!job.reference_image_storage_key) return [];
  return [
    {
      storageKey: job.reference_image_storage_key,
      mimeType: job.reference_image_mime_type ?? "image/png",
      name: job.reference_image_name ?? "reference.png",
      byteSize: job.reference_image_byte_size ?? 0
    }
  ];
}
function parseReferenceImagesJson2(value) {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    if (!Array.isArray(parsed)) return [];
    return parsed.map((item) => {
      if (!item || typeof item !== "object") return null;
      const record = item;
      const storageKey = typeof record.storageKey === "string" ? record.storageKey : "";
      if (!storageKey) return null;
      return {
        storageKey,
        mimeType: typeof record.mimeType === "string" ? record.mimeType : "image/png",
        name: typeof record.name === "string" ? record.name : "reference.png",
        byteSize: typeof record.byteSize === "number" ? record.byteSize : 0,
        ...record.role === "source" || record.role === "reference" ? { role: record.role } : {}
      };
    }).filter((item) => Boolean(item));
  } catch {
    return [];
  }
}
function conversationIdFromBody(body) {
  if (!body) return void 0;
  const value = body.conversationId;
  if (typeof value !== "string") return void 0;
  const normalized = value.trim();
  return normalized || void 0;
}
function sourceImageIdFromBody(body) {
  if (!body) return "";
  const current = typeof body[SOURCE_IMAGE_ID_FIELD] === "string" ? body[SOURCE_IMAGE_ID_FIELD].trim() : "";
  if (current) return current;
  return typeof body[LEGACY_SOURCE_IMAGE_ID_FIELD] === "string" ? body[LEGACY_SOURCE_IMAGE_ID_FIELD].trim() : "";
}
async function resolveConversationId(db, spaceId, requestedConversationId) {
  if (!requestedConversationId) return void 0;
  const sourceJob = await getGenerationJob(db, spaceId, requestedConversationId);
  if (!sourceJob) return void 0;
  return sourceJob.conversation_id ?? sourceJob.id;
}
async function cloneMaskImage(env, spaceId, nextJobId, sourceJob) {
  if (!sourceJob.mask_image_storage_key) return void 0;
  const sourceObject = await env.IMAGES.get(sourceJob.mask_image_storage_key);
  if (!sourceObject) {
    throw jsonError(404, "mask_image_missing", "\u9009\u533A\u906E\u7F69\u6587\u4EF6\u4E0D\u5B58\u5728\uFF0C\u8BF7\u91CD\u65B0\u6D82\u62B9\u540E\u518D\u8BD5\u3002");
  }
  const bytes = await sourceObject.arrayBuffer();
  const name = safeReferenceImageName(sourceJob.mask_image_name ?? "", "png");
  const storageKey = `${spaceId}/${nextJobId}/mask.png`;
  await env.IMAGES.put(storageKey, bytes, {
    httpMetadata: {
      contentType: "image/png",
      contentDisposition: `inline; filename="${name}"`
    },
    customMetadata: {
      jobId: nextJobId,
      spaceId,
      kind: "mask"
    }
  });
  return {
    storageKey,
    mimeType: "image/png",
    name,
    byteSize: bytes.byteLength
  };
}
app.get("/api/config", (c) => {
  return c.json({
    ok: true,
    config: {
      model: optionOrFallback(c.env.DEFAULT_IMAGE_MODEL, IMAGE_MODEL_OPTIONS),
      modelOptions: [...IMAGE_MODEL_OPTIONS],
      promptOptimizerModel: optionOrFallback(c.env.PROMPT_OPTIMIZER_MODEL, PROMPT_OPTIMIZER_MODEL_OPTIONS),
      maxImagesPerRequest: envNumber(c.env.MAX_IMAGES_PER_REQUEST, 4),
      generationTimeoutSeconds: Math.round(resolveGenerationTimeoutMs(c.env.REQUEST_TIMEOUT_MS) / 1e3),
      ratios: [...Object.keys(RATIO_TO_SIZE), "custom"],
      qualities: ["auto", "low", "medium", "high"],
      formats: ["png", "webp", "jpeg"],
      turnstileSiteKey: c.env.TURNSTILE_SITE_KEY ?? "",
      turnstileRequired: c.env.TURNSTILE_REQUIRED === "true"
    }
  });
});
app.post("/api/auth/space-login", async (c) => {
  const body = await c.req.json().catch(() => null);
  if (!body || typeof body !== "object") throw jsonError(400, "invalid_request", "\u8BF7\u6C42\u4F53\u683C\u5F0F\u4E0D\u6B63\u786E\u3002");
  const { spaceName, password, turnstileToken } = body;
  if (typeof spaceName !== "string" || spaceName.trim().length < 2) {
    throw jsonError(400, "invalid_space_name", "\u7A7A\u95F4\u540D\u81F3\u5C11\u9700\u8981 2 \u4E2A\u5B57\u7B26\u3002");
  }
  if (typeof password !== "string" || password.length < 1) throw jsonError(400, "invalid_password", "\u8BF7\u8F93\u5165\u7A7A\u95F4\u5BC6\u7801\u3002");
  const turnstileOk = await verifyTurnstile(typeof turnstileToken === "string" ? turnstileToken : void 0, c.req.raw, c.env);
  if (!turnstileOk) throw jsonError(403, "turnstile_failed", "\u4EBA\u673A\u9A8C\u8BC1\u5931\u8D25\u3002");
  const normalized = normalizeSpaceName(spaceName);
  let space = await getSpaceByKey(c.env.DB, normalized.key);
  if (space) {
    const ok = await verifyPassword(password, space.password_hash);
    if (!ok) throw jsonError(401, "invalid_credentials", "\u7A7A\u95F4\u540D\u6216\u5BC6\u7801\u4E0D\u6B63\u786E\u3002");
  } else {
    if (password.length < 8) {
      throw jsonError(400, "invalid_password", "\u65B0\u7A7A\u95F4\u5BC6\u7801\u81F3\u5C11\u9700\u8981 8 \u4E2A\u5B57\u7B26\u3002");
    }
    space = await createSpace(c.env.DB, normalized.displayName, normalized.key, await hashPassword(password));
  }
  const token = makeSessionToken();
  await createSession(c.env.DB, space.id, await sha256Hex(token), daysFromNow(SESSION_DAYS));
  const isSecureRequest = new URL(c.req.url).protocol === "https:";
  setCookie(c, SESSION_COOKIE, token, {
    httpOnly: true,
    secure: isSecureRequest,
    sameSite: "Lax",
    path: "/",
    maxAge: SESSION_DAYS * 24 * 60 * 60
  });
  return c.json({ ok: true, spaceId: space.id, spaceName: space.space_name });
});
app.post("/api/auth/logout", async (c) => {
  const token = getCookie(c, SESSION_COOKIE);
  if (token) await deleteSession(c.env.DB, await sha256Hex(token));
  deleteCookie(c, SESSION_COOKIE, { path: "/" });
  return c.json({ ok: true });
});
app.use("/api/*", async (c, next) => {
  const publicPaths = /* @__PURE__ */ new Set(["/api/config", "/api/auth/space-login"]);
  if (publicPaths.has(new URL(c.req.url).pathname)) return next();
  const token = getCookie(c, SESSION_COOKIE);
  if (!token) throw jsonError(401, "unauthorized", "\u8BF7\u5148\u8FDB\u5165\u7A7A\u95F4\u3002");
  const session = await getSession(c.env.DB, await sha256Hex(token));
  if (!session) {
    deleteCookie(c, SESSION_COOKIE, { path: "/" });
    throw jsonError(401, "session_expired", "\u767B\u5F55\u72B6\u6001\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u91CD\u65B0\u8FDB\u5165\u7A7A\u95F4\u3002");
  }
  c.set("session", session);
  c.set("space", {
    id: session.space_id,
    space_name: session.space_name,
    space_key: session.space_key,
    password_hash: session.password_hash,
    created_at: session.created_at,
    updated_at: session.updated_at
  });
  return next();
});
app.get("/api/me", async (c) => {
  const space = c.get("space");
  const credential = await getCredential(c.env.DB, space.id);
  return c.json({
    ok: true,
    space: { id: space.id, name: space.space_name },
    providerConfigured: hasImageProviderConfigured(credential)
  });
});
app.get("/api/settings/provider", async (c) => {
  const credential = await getCredential(c.env.DB, c.get("space").id);
  return c.json({
    ok: true,
    imageProvider: hasImageProviderConfigured(credential) ? {
      baseURL: credential.base_url,
      model: optionOrFallback(credential.model, IMAGE_MODEL_OPTIONS),
      apiKeyHint: credential.api_key_hint,
      lastTestOk: Boolean(credential.last_test_ok),
      lastTestedAt: credential.last_tested_at
    } : null,
    promptProvider: hasPromptProviderConfigured(credential) ? {
      baseURL: credential.prompt_base_url ?? "",
      model: optionOrFallback(credential.prompt_optimizer_model ?? c.env.PROMPT_OPTIMIZER_MODEL, PROMPT_OPTIMIZER_MODEL_OPTIONS),
      apiKeyHint: credential.prompt_api_key_hint ?? "",
      lastTestOk: Boolean(credential.prompt_last_test_ok),
      lastTestedAt: credential.prompt_last_tested_at
    } : null
  });
});
app.post("/api/settings/provider", async (c) => {
  const body = await c.req.json().catch(() => null);
  if (!body || typeof body !== "object") throw jsonError(400, "invalid_request", "\u8BF7\u6C42\u4F53\u683C\u5F0F\u4E0D\u6B63\u786E\u3002");
  const { imageProvider, promptProvider } = body;
  if ((!imageProvider || typeof imageProvider !== "object") && (!promptProvider || typeof promptProvider !== "object")) {
    throw jsonError(400, "invalid_request", "\u8BF7\u81F3\u5C11\u586B\u5199\u4E00\u4E2A Provider\u3002");
  }
  const existingCredential = await getCredential(c.env.DB, c.get("space").id);
  const imageInput = imageProvider && typeof imageProvider === "object" ? imageProvider : null;
  const promptInput = promptProvider && typeof promptProvider === "object" ? promptProvider : null;
  if (imageInput && typeof imageInput.baseURL !== "string") throw jsonError(400, "invalid_base_url", "\u8BF7\u8F93\u5165\u751F\u56FE Provider \u7684 baseURL\u3002");
  if (promptInput && typeof promptInput.baseURL !== "string") throw jsonError(400, "invalid_prompt_base_url", "\u8BF7\u8F93\u5165\u63D0\u793A\u8BCD Provider \u7684 baseURL\u3002");
  if (!imageInput && !hasImageProviderConfigured(existingCredential)) throw jsonError(400, "invalid_image_provider", "\u8BF7\u586B\u5199\u751F\u56FE Provider\u3002");
  const resolvedImageBaseURL = imageInput?.baseURL ?? existingCredential?.base_url;
  const resolvedPromptBaseURL = promptInput?.baseURL ?? existingCredential?.prompt_base_url;
  if (typeof resolvedImageBaseURL !== "string") throw jsonError(400, "invalid_base_url", "\u8BF7\u8F93\u5165\u751F\u56FE Provider \u7684 baseURL\u3002");
  const imageValidation = validateBaseURL(resolvedImageBaseURL);
  const promptValidation = typeof resolvedPromptBaseURL === "string" ? validateBaseURL(resolvedPromptBaseURL) : null;
  if (!imageValidation.ok || !imageValidation.normalized) throw jsonError(400, "invalid_base_url", imageValidation.error ?? "\u751F\u56FE Provider \u7684 baseURL \u4E0D\u5408\u6CD5\u3002");
  if (promptInput && (!promptValidation?.ok || !promptValidation.normalized)) {
    throw jsonError(400, "invalid_prompt_base_url", promptValidation?.error ?? "\u63D0\u793A\u8BCD Provider \u7684 baseURL \u4E0D\u5408\u6CD5\u3002");
  }
  const rawImageApiKey = imageInput && typeof imageInput.apiKey === "string" ? imageInput.apiKey.trim() : "";
  const rawPromptApiKey = promptInput && typeof promptInput.apiKey === "string" ? promptInput.apiKey.trim() : "";
  if (rawImageApiKey && rawImageApiKey.length < 8) throw jsonError(400, "invalid_api_key", "\u8BF7\u8F93\u5165\u6709\u6548\u7684\u751F\u56FE Provider API Key\u3002");
  if (rawPromptApiKey && rawPromptApiKey.length < 8) throw jsonError(400, "invalid_prompt_api_key", "\u8BF7\u8F93\u5165\u6709\u6548\u7684\u63D0\u793A\u8BCD Provider API Key\u3002");
  if (!rawImageApiKey && !existingCredential?.encrypted_api_key) throw jsonError(400, "invalid_api_key", "\u8BF7\u8F93\u5165\u6709\u6548\u7684\u751F\u56FE Provider API Key\u3002");
  if (promptInput && !rawPromptApiKey && !existingCredential?.prompt_encrypted_api_key) {
    throw jsonError(400, "invalid_prompt_api_key", "\u8BF7\u8F93\u5165\u6709\u6548\u7684\u63D0\u793A\u8BCD Provider API Key\u3002");
  }
  const selectedImageModel = optionOrFallback(
    imageInput && typeof imageInput.model === "string" ? imageInput.model : existingCredential?.model ?? c.env.DEFAULT_IMAGE_MODEL,
    IMAGE_MODEL_OPTIONS
  );
  const selectedPromptOptimizerModel = optionOrFallback(
    promptInput && typeof promptInput.model === "string" ? promptInput.model : existingCredential?.prompt_optimizer_model ?? c.env.PROMPT_OPTIMIZER_MODEL,
    PROMPT_OPTIMIZER_MODEL_OPTIONS
  );
  const encryptedImageApiKey = rawImageApiKey ? await encryptSecret(rawImageApiKey, c.env.APP_ENCRYPTION_KEY ?? "") : existingCredential?.encrypted_api_key;
  const savedImageApiKeyHint = rawImageApiKey ? apiKeyHint(rawImageApiKey) : existingCredential?.api_key_hint;
  const encryptedPromptApiKey = rawPromptApiKey ? await encryptSecret(rawPromptApiKey, c.env.APP_ENCRYPTION_KEY ?? "") : existingCredential?.prompt_encrypted_api_key;
  const savedPromptApiKeyHint = rawPromptApiKey ? apiKeyHint(rawPromptApiKey) : existingCredential?.prompt_api_key_hint;
  if (!encryptedImageApiKey || !savedImageApiKeyHint) throw jsonError(400, "invalid_api_key", "\u8BF7\u8F93\u5165\u6709\u6548\u7684\u751F\u56FE Provider API Key\u3002");
  if (promptInput && (!encryptedPromptApiKey || !savedPromptApiKeyHint)) {
    throw jsonError(400, "invalid_prompt_api_key", "\u8BF7\u8F93\u5165\u6709\u6548\u7684\u63D0\u793A\u8BCD Provider API Key\u3002");
  }
  await upsertCredential(
    c.env.DB,
    c.get("space").id,
    {
      imageBaseURL: imageValidation.normalized,
      imageModel: selectedImageModel,
      imageEncryptedApiKey: encryptedImageApiKey,
      imageApiKeyHint: savedImageApiKeyHint,
      promptBaseURL: promptValidation?.normalized ?? null,
      promptModel: selectedPromptOptimizerModel,
      promptEncryptedApiKey: encryptedPromptApiKey ?? null,
      promptApiKeyHint: savedPromptApiKeyHint ?? null
    }
  );
  return c.json({
    ok: true,
    imageProvider: {
      baseURL: imageValidation.normalized,
      model: selectedImageModel,
      apiKeyHint: savedImageApiKeyHint,
      lastTestOk: false,
      lastTestedAt: null
    },
    promptProvider: promptValidation?.normalized && savedPromptApiKeyHint ? {
      baseURL: promptValidation.normalized,
      model: selectedPromptOptimizerModel,
      apiKeyHint: savedPromptApiKeyHint,
      lastTestOk: false,
      lastTestedAt: null
    } : null
  });
});
app.delete("/api/settings/provider", async (c) => {
  await deleteCredential(c.env.DB, c.get("space").id);
  return c.json({ ok: true });
});
app.post("/api/provider/test", async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const spaceId = c.get("space").id;
  const kind = body && typeof body === "object" && body.kind === "prompt" ? "prompt" : "image";
  let baseURL;
  let apiKey;
  if (body && typeof body === "object" && typeof body.baseURL === "string") {
    const raw = body;
    const validation = validateBaseURL(raw.baseURL);
    if (!validation.ok || !validation.normalized) throw jsonError(400, "invalid_base_url", validation.error ?? "baseURL \u4E0D\u5408\u6CD5\u3002");
    const rawApiKey = typeof raw.apiKey === "string" ? raw.apiKey.trim() : "";
    baseURL = validation.normalized;
    if (rawApiKey) {
      apiKey = rawApiKey;
    } else {
      const credential = await getCredential(c.env.DB, spaceId);
      if (!credential) throw jsonError(400, "invalid_api_key", "\u8BF7\u8F93\u5165 API Key\u3002");
      const encryptedApiKey = kind === "prompt" ? credential.prompt_encrypted_api_key : credential.encrypted_api_key;
      if (!encryptedApiKey) throw jsonError(400, "invalid_api_key", "\u8BF7\u8F93\u5165 API Key\u3002");
      apiKey = await decryptSecret(encryptedApiKey, c.env.APP_ENCRYPTION_KEY ?? "");
    }
  } else {
    const credential = await getCredential(c.env.DB, spaceId);
    if (!credential) throw jsonError(400, "provider_missing", "\u8BF7\u5148\u4FDD\u5B58 provider \u914D\u7F6E\u3002");
    baseURL = kind === "prompt" ? credential.prompt_base_url ?? void 0 : credential.base_url;
    const encryptedApiKey = kind === "prompt" ? credential.prompt_encrypted_api_key : credential.encrypted_api_key;
    if (!baseURL || !encryptedApiKey) {
      throw jsonError(400, "provider_missing", kind === "prompt" ? "\u8BF7\u5148\u4FDD\u5B58\u63D0\u793A\u8BCD Provider \u914D\u7F6E\u3002" : "\u8BF7\u5148\u4FDD\u5B58\u751F\u56FE Provider \u914D\u7F6E\u3002");
    }
    apiKey = await decryptSecret(encryptedApiKey, c.env.APP_ENCRYPTION_KEY ?? "");
  }
  const result = await testProvider(baseURL, apiKey);
  if (!(body && typeof body === "object" && typeof body.baseURL === "string")) {
    await markCredentialTested(c.env.DB, spaceId, kind, result.ok);
  }
  return c.json({ ok: true, result });
});
app.post("/api/prompts/optimize", async (c) => {
  const body = await c.req.json().catch(() => null);
  const parsed = parsePromptOptimizationInput(body);
  if (!parsed.input) throw jsonError(400, "invalid_prompt_input", parsed.error ?? "\u63D0\u793A\u8BCD\u4F18\u5316\u53C2\u6570\u4E0D\u6B63\u786E\u3002");
  const spaceId = c.get("space").id;
  const credential = await getCredential(c.env.DB, spaceId);
  if (!hasPromptProviderConfigured(credential)) throw jsonError(400, "provider_missing", "\u8BF7\u5148\u5728\u8BBE\u7F6E\u4E2D\u914D\u7F6E\u63D0\u793A\u8BCD Provider\u3002");
  try {
    const apiKey = await decryptSecret(credential.prompt_encrypted_api_key ?? "", c.env.APP_ENCRYPTION_KEY ?? "");
    const optimizedPrompt = await optimizePrompt(parsed.input, credential, apiKey, c.env);
    return c.json({ ok: true, optimizedPrompt });
  } catch (error) {
    const providerError = error instanceof ProviderError ? error : new ProviderError("prompt_optimization_failed", "\u63D0\u793A\u8BCD\u4F18\u5316\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002");
    throw jsonError(providerHttpStatus(providerError), providerError.code, providerError.message);
  }
});
app.post("/api/generations", async (c) => {
  const requestPayload = await parseGenerationRequest(c.req.raw);
  const parsed = parseGenerationInput(requestPayload.body, c.env.MAX_IMAGES_PER_REQUEST);
  if (!parsed.input) throw jsonError(400, "invalid_generation_input", parsed.error ?? "\u751F\u56FE\u53C2\u6570\u4E0D\u6B63\u786E\u3002");
  const sourceImageId = sourceImageIdFromBody(requestPayload.body);
  const requestedConversationId = conversationIdFromBody(requestPayload.body);
  const turnstileOk = await verifyTurnstile(parsed.input.turnstileToken, c.req.raw, c.env);
  if (!turnstileOk) throw jsonError(403, "turnstile_failed", "\u4EBA\u673A\u9A8C\u8BC1\u5931\u8D25\u3002");
  const space = c.get("space");
  const credential = await getCredential(c.env.DB, space.id);
  if (!hasImageProviderConfigured(credential)) throw jsonError(400, "provider_missing", "\u8BF7\u5148\u5728\u8BBE\u7F6E\u4E2D\u914D\u7F6E\u751F\u56FE Provider\u3002");
  await assertGenerationLimitsForRequest(c.env, space.id, parsed.input.quantity);
  const sourceImageCount = sourceImageId ? 1 : 0;
  if (requestPayload.referenceImages.length + sourceImageCount > MAX_REFERENCE_IMAGES) {
    throw jsonError(400, "too_many_reference_images", `\u53C2\u8003\u56FE\u6700\u591A ${MAX_REFERENCE_IMAGES} \u5F20\u3002`);
  }
  if (requestPayload.maskImage && requestPayload.referenceImages.length === 0 && !sourceImageId) {
    throw jsonError(400, "mask_requires_reference_image", "\u9009\u533A\u906E\u7F69\u9700\u8981\u548C\u53C2\u8003\u56FE\u4E00\u8D77\u63D0\u4EA4\u3002");
  }
  const jobId = randomId("job");
  const sourceImage = sourceImageId ? await cloneSourceImageAsReference(c.env, space.id, jobId, sourceImageId) : null;
  const uploadedReferences = await storeReferenceImages(c.env, space.id, jobId, requestPayload.referenceImages, sourceImage ? 1 : 0);
  const referenceImages = sourceImage ? [sourceImage, ...uploadedReferences] : uploadedReferences;
  const maskImage = requestPayload.maskImage ? await storeMaskImage(c.env, space.id, jobId, requestPayload.maskImage) : void 0;
  await createGenerationJob(
    c.env.DB,
    space.id,
    parsed.input,
    optionOrFallback(parsed.input.model ?? credential.model ?? c.env.DEFAULT_IMAGE_MODEL, IMAGE_MODEL_OPTIONS),
    await sha256Hex(credential.base_url),
    referenceImages,
    maskImage,
    jobId,
    await resolveConversationId(c.env.DB, space.id, requestedConversationId)
  );
  await enqueueGenerationJob(c.env, jobId, space.id, parsed.input.quantity);
  return c.json({ ok: true, jobId, status: "queued" });
});
app.get("/api/generations", async (c) => {
  const spaceId = c.get("space").id;
  const jobs = await listGenerationJobs(c.env.DB, spaceId, c.req.query("cursor"));
  const visibleJobs = jobs.slice(0, GENERATION_JOB_PAGE_SIZE);
  const jobIds = visibleJobs.map((job) => job.id);
  const images = await listImagesForJobs(c.env.DB, spaceId, jobIds);
  const results = await listGenerationResultsForJobs(c.env.DB, spaceId, jobIds);
  const imagesByJob = /* @__PURE__ */ new Map();
  for (const image of images) {
    const group = imagesByJob.get(image.job_id) ?? [];
    group.push(image);
    imagesByJob.set(image.job_id, group);
  }
  const resultsByJob = /* @__PURE__ */ new Map();
  for (const result of results) {
    const group = resultsByJob.get(result.job_id) ?? [];
    group.push(result);
    resultsByJob.set(result.job_id, group);
  }
  return c.json({
    ok: true,
    records: visibleJobs.map((job) => {
      const jobImages = imagesByJob.get(job.id) ?? [];
      return {
        job: serializeGenerationJob(job, resultsByJob.get(job.id) ?? []),
        elapsedSeconds: generationElapsedSeconds(job),
        images: jobImages.map((image) => serializeImage(image))
      };
    }),
    nextCursor: jobs.length > GENERATION_JOB_PAGE_SIZE ? visibleJobs.at(-1)?.created_at : null
  });
});
app.get("/api/generations/:jobId", async (c) => {
  const job = await getGenerationJob(c.env.DB, c.get("space").id, c.req.param("jobId"));
  if (!job) throw jsonError(404, "job_not_found", "\u4EFB\u52A1\u4E0D\u5B58\u5728\u3002");
  const images = await listImagesForJob(c.env.DB, c.get("space").id, job.id);
  const results = await listGenerationResultsForJob(c.env.DB, c.get("space").id, job.id);
  return c.json({
    ok: true,
    job: serializeGenerationJob(job, results),
    images: images.map((image) => serializeImage(image))
  });
});
app.get("/api/generations/:jobId/references/:index", async (c) => {
  const spaceId = c.get("space").id;
  const job = await getGenerationJob(c.env.DB, spaceId, c.req.param("jobId"));
  if (!job) throw jsonError(404, "job_not_found", "\u4EFB\u52A1\u4E0D\u5B58\u5728\u3002");
  const index = Number(c.req.param("index"));
  const reference = referenceImagesFromJob(job)[index];
  if (!Number.isInteger(index) || index < 0 || !reference) {
    throw jsonError(404, "reference_image_not_found", "\u53C2\u8003\u56FE\u4E0D\u5B58\u5728\u3002");
  }
  const etag = referenceImageETag(reference.storageKey, reference.byteSize);
  const headers = imageResponseHeaders(reference.mimeType, `inline; filename="${reference.name}"`, etag);
  if (matchesIfNoneMatch(c.req.header("If-None-Match"), etag)) {
    return new Response(null, { status: 304, headers });
  }
  const object = await c.env.IMAGES.get(reference.storageKey);
  if (!object) throw jsonError(404, "reference_image_missing", "\u53C2\u8003\u56FE\u6587\u4EF6\u4E0D\u5B58\u5728\u3002");
  return new Response(object.body, {
    headers
  });
});
app.delete("/api/generations/:jobId", async (c) => {
  const spaceId = c.get("space").id;
  const job = await getGenerationJob(c.env.DB, spaceId, c.req.param("jobId"));
  if (!job) throw jsonError(404, "job_not_found", "\u4EFB\u52A1\u4E0D\u5B58\u5728\u3002");
  if (job.status === "queued" || job.status === "running") {
    throw jsonError(409, "job_active", "\u4EFB\u52A1\u4ECD\u5728\u751F\u6210\u4E2D\uFF0C\u6682\u65F6\u4E0D\u80FD\u5220\u9664\u3002\u8BF7\u7B49\u5F85\u4EFB\u52A1\u7ED3\u675F\uFF0C\u907F\u514D\u4E0A\u6E38\u5DF2\u8BA1\u8D39\u4F46\u7ED3\u679C\u88AB\u63D0\u524D\u79FB\u9664\u3002");
  }
  const images = await listImagesForJob(c.env.DB, spaceId, job.id);
  const recoveryKeys = Array.from({ length: job.quantity }, (_, resultIndex) => {
    const imageId = `img_${job.id}_${resultIndex}`;
    return [
      providerResultCheckpointStorageKey(job, resultIndex),
      ...["png", "jpeg", "webp"].map((format) => `${spaceId}/${job.id}/${imageId}.${format}`),
      `${spaceId}/${job.id}/thumb_${imageId}.webp`
    ];
  }).flat();
  const storageKeys = /* @__PURE__ */ new Set([
    ...images.map((image) => image.storage_key),
    ...images.map((image) => image.thumbnail_storage_key).filter((key) => Boolean(key)),
    ...referenceImagesFromJob(job).map((reference) => reference.storageKey),
    ...job.mask_image_storage_key ? [job.mask_image_storage_key] : [],
    ...recoveryKeys
  ]);
  for (const storageKey of storageKeys) {
    await c.env.IMAGES.delete(storageKey);
  }
  await deleteGenerationJob(c.env.DB, spaceId, job.id);
  return c.json({ ok: true });
});
app.post("/api/generations/:jobId/regenerate", async (c) => {
  const space = c.get("space");
  const sourceJob = await getGenerationJob(c.env.DB, space.id, c.req.param("jobId"));
  if (!sourceJob) throw jsonError(404, "job_not_found", "\u4EFB\u52A1\u4E0D\u5B58\u5728\u3002");
  const credential = await getCredential(c.env.DB, space.id);
  if (!hasImageProviderConfigured(credential)) throw jsonError(400, "provider_missing", "\u8BF7\u5148\u5728\u8BBE\u7F6E\u4E2D\u914D\u7F6E\u751F\u56FE Provider\u3002");
  await assertGenerationLimitsForRequest(c.env, space.id, sourceJob.quantity);
  const jobId = randomId("job");
  const referenceImages = await cloneReferenceImage(c.env, space.id, jobId, sourceJob);
  const maskImage = await cloneMaskImage(c.env, space.id, jobId, sourceJob);
  await createGenerationJob(
    c.env.DB,
    space.id,
    generationInputFromJob(sourceJob),
    credential.model,
    await sha256Hex(credential.base_url),
    referenceImages,
    maskImage,
    jobId,
    sourceJob.conversation_id ?? sourceJob.id
  );
  await enqueueGenerationJob(c.env, jobId, space.id, sourceJob.quantity);
  return c.json({ ok: true, jobId, status: "queued" });
});
app.get("/api/images", async (c) => {
  const images = await listImages(c.env.DB, c.get("space").id, c.req.query("cursor"));
  return c.json({
    ok: true,
    images: images.map((image) => serializeImage(image, true)),
    nextCursor: images.length === 30 ? images[images.length - 1]?.created_at : null
  });
});
app.get("/api/images/:imageId/download", async (c) => {
  const image = await getImage(c.env.DB, c.get("space").id, c.req.param("imageId"));
  if (!image) throw jsonError(404, "image_not_found", "\u56FE\u7247\u4E0D\u5B58\u5728\u3002");
  const filename = `${image.id}.${image.format}`;
  const inlineContentDisposition = `inline; filename="${filename}"`;
  const attachmentContentDisposition = `attachment; filename="${filename}"`;
  const rawDownload = c.req.query("raw") === "1";
  const attachmentDownload = c.req.query("download") === "1";
  const etag = imageETag(image.sha256);
  const cachedHeaders = imageResponseHeaders(image.mime_type, attachmentDownload ? attachmentContentDisposition : inlineContentDisposition, etag, image.byte_size);
  if (rawDownload) {
    if (matchesIfNoneMatch(c.req.header("If-None-Match"), etag)) {
      return new Response(null, { status: 304, headers: cachedHeaders });
    }
    const object2 = await c.env.IMAGES.get(image.storage_key);
    if (!object2) throw jsonError(404, "image_file_missing", "\u56FE\u7247\u6587\u4EF6\u4E0D\u5B58\u5728\u3002");
    return new Response(object2.body, {
      headers: cachedHeaders
    });
  }
  if (c.env.IMAGES.createPresignedGetUrl) {
    const url = await c.env.IMAGES.createPresignedGetUrl(image.storage_key, {
      expiresInSeconds: 300,
      contentType: image.mime_type,
      contentDisposition: inlineContentDisposition
    });
    return c.redirect(url, 302);
  }
  const object = await c.env.IMAGES.get(image.storage_key);
  if (!object) throw jsonError(404, "image_file_missing", "\u56FE\u7247\u6587\u4EF6\u4E0D\u5B58\u5728\u3002");
  return new Response(object.body, {
    headers: imageResponseHeaders(image.mime_type, inlineContentDisposition, etag, image.byte_size)
  });
});
app.get("/api/images/:imageId/thumbnail", async (c) => {
  const image = await getImage(c.env.DB, c.get("space").id, c.req.param("imageId"));
  if (!image) throw jsonError(404, "image_not_found", "\u56FE\u7247\u4E0D\u5B58\u5728\u3002");
  if (!image.thumbnail_storage_key || !image.thumbnail_mime_type || !image.thumbnail_sha256) {
    throw jsonError(404, "image_thumbnail_missing", "\u56FE\u7247\u7F29\u7565\u56FE\u4E0D\u5B58\u5728\u3002");
  }
  const format = formatFromMimeType2(image.thumbnail_mime_type);
  const etag = imageETag(image.thumbnail_sha256);
  const headers = imageResponseHeaders(
    image.thumbnail_mime_type,
    `inline; filename="${image.id}-thumbnail.${format}"`,
    etag,
    image.thumbnail_byte_size ?? void 0
  );
  if (matchesIfNoneMatch(c.req.header("If-None-Match"), etag)) {
    return new Response(null, { status: 304, headers });
  }
  const object = await c.env.IMAGES.get(image.thumbnail_storage_key);
  if (!object) throw jsonError(404, "image_thumbnail_missing", "\u56FE\u7247\u7F29\u7565\u56FE\u6587\u4EF6\u4E0D\u5B58\u5728\u3002");
  return new Response(object.body, { headers });
});
app.get("/api/inspirations", async (c) => {
  const result = await listInspirations(c.env.DB, c.get("space").id, {
    q: c.req.query("q"),
    source: c.req.query("source"),
    tag: c.req.query("tag"),
    favorites: c.req.query("favorites") === "1",
    cursor: c.req.query("cursor")
  });
  return c.json({
    ok: true,
    inspirations: result.items.map((item) => serializeInspiration(item)),
    nextCursor: result.nextCursor
  });
});
app.post("/api/inspirations/import-url", async (c) => {
  const body = await c.req.json().catch(() => null);
  if (!body || typeof body !== "object") throw jsonError(400, "invalid_request", "\u8BF7\u6C42\u4F53\u683C\u5F0F\u4E0D\u6B63\u786E\u3002");
  const raw = body;
  if (typeof raw.url !== "string") throw jsonError(400, "invalid_url", "\u8BF7\u8F93\u5165\u7075\u611F\u6765\u6E90\u94FE\u63A5\u3002");
  const tags = Array.isArray(raw.tags) ? raw.tags.filter((item) => typeof item === "string") : void 0;
  try {
    const item = await importInspirationUrl(c.env, {
      url: raw.url,
      prompt: typeof raw.prompt === "string" ? raw.prompt : void 0,
      title: typeof raw.title === "string" ? raw.title : void 0,
      author: typeof raw.author === "string" ? raw.author : void 0,
      tags
    });
    return c.json({ ok: true, inspiration: serializeInspiration({ ...item, favorite: 0 }) });
  } catch (error) {
    throw jsonError(400, "inspiration_import_failed", error instanceof Error ? error.message : "\u5BFC\u5165\u5931\u8D25\u3002");
  }
});
app.post("/api/inspirations/:itemId/favorite", async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const favorite = body && typeof body === "object" && typeof body.favorite === "boolean" ? body.favorite : void 0;
  try {
    const nextFavorite = await toggleInspirationFavorite(c.env.DB, c.get("space").id, c.req.param("itemId"), favorite);
    return c.json({ ok: true, favorite: nextFavorite });
  } catch (error) {
    throw jsonError(404, "inspiration_not_found", error instanceof Error ? error.message : "\u7075\u611F\u7D20\u6750\u4E0D\u5B58\u5728\u3002");
  }
});
app.post("/api/inspirations/:itemId/use", async (c) => {
  await recordInspirationUse(c.env.DB, c.req.param("itemId"));
  return c.json({ ok: true });
});
app.get("/api/inspirations/:itemId/thumbnail", async (c) => {
  const item = await getInspirationItem(c.env.DB, c.req.param("itemId"));
  if (!item || item.status !== "published" || !item.thumbnail_storage_key) {
    throw jsonError(404, "inspiration_thumbnail_missing", "\u7075\u611F\u7F29\u7565\u56FE\u4E0D\u5B58\u5728\u3002");
  }
  const contentDisposition = `inline; filename="${item.id}"`;
  if (c.env.IMAGES.createPresignedGetUrl) {
    const url = await c.env.IMAGES.createPresignedGetUrl(item.thumbnail_storage_key, {
      expiresInSeconds: 300,
      contentType: item.thumbnail_mime_type ?? "image/jpeg",
      contentDisposition
    });
    return c.redirect(url, 302);
  }
  const object = await c.env.IMAGES.get(item.thumbnail_storage_key);
  if (!object) throw jsonError(404, "inspiration_thumbnail_missing", "\u7075\u611F\u7F29\u7565\u56FE\u4E0D\u5B58\u5728\u3002");
  return new Response(object.body, {
    headers: {
      "Content-Type": item.thumbnail_mime_type ?? "image/jpeg",
      "Cache-Control": "private, max-age=300",
      "Content-Disposition": contentDisposition
    }
  });
});
function providerHttpStatus(error) {
  if (error.code === "provider_rate_limited") return 429;
  if (error.code === "provider_timeout") return 504;
  if (error.code === "provider_auth_failed") return 502;
  return 502;
}
async function enqueueGenerationJob(env, jobId, spaceId, quantity) {
  try {
    await env.GENERATION_QUEUE.send({ jobId, spaceId });
  } catch (error) {
    const message = "\u751F\u56FE\u4EFB\u52A1\u8FDB\u5165\u961F\u5217\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002";
    try {
      await updateJobStatus(env.DB, jobId, "failed", "queue_enqueue_failed", message, {
        stage: "failed",
        progressCurrent: 0,
        progressTotal: quantity
      });
    } catch (updateError) {
      console.error("generation queue enqueue compensation failed", updateError);
    }
    throw jsonError(503, "queue_enqueue_failed", message);
  }
}
function serializeGenerationJob(job, results) {
  return {
    ...job,
    conversation_id: job.conversation_id ?? job.id,
    stage: job.stage ?? stageFromStatus(job.status),
    progress_current: job.progress_current ?? inferredProgressCurrent(job, results),
    progress_total: job.progress_total ?? job.quantity,
    error_reason: job.error_reason ?? job.error_message,
    results: normalizeGenerationResults(job, results),
    referenceImages: referenceImagesFromJob(job).map((reference, index) => ({
      name: reference.name,
      mimeType: reference.mimeType,
      byteSize: reference.byteSize,
      role: reference.role ?? "reference",
      url: `/api/generations/${job.id}/references/${index}`
    }))
  };
}
function normalizeGenerationResults(job, results) {
  const byIndex = new Map(results.map((result) => [result.result_index, result]));
  return Array.from({ length: job.quantity }, (_, index) => {
    const result = byIndex.get(index);
    if (result) {
      return {
        index,
        status: result.status,
        imageId: result.image_asset_id,
        errorCode: result.error_code,
        errorMessage: result.error_message,
        startedAt: result.started_at,
        completedAt: result.completed_at
      };
    }
    return {
      index,
      status: job.status === "queued" || job.status === "running" ? job.status : "failed",
      imageId: null,
      errorCode: job.status === "partial_succeeded" || job.status === "failed" ? job.error_code : null,
      errorMessage: job.status === "partial_succeeded" || job.status === "failed" ? job.error_message : null,
      startedAt: null,
      completedAt: null
    };
  });
}
function inferredProgressCurrent(job, results) {
  if (job.status === "succeeded" || job.status === "partial_succeeded" || job.status === "failed" || job.status === "cancelled") return job.quantity;
  return results.filter((result) => result.status === "succeeded" || result.status === "failed").length;
}
function stageFromStatus(status) {
  if (status === "queued") return "queued";
  if (status === "running") return "waiting_provider";
  if (status === "cancelled") return "cancelled";
  if (status === "failed") return "failed";
  return "completed";
}
function serializeImage(image, includeMetadata = false) {
  return {
    id: image.id,
    jobId: image.job_id,
    url: `/api/images/${image.id}/download?raw=1`,
    width: image.width,
    height: image.height,
    format: image.format,
    byteSize: image.byte_size,
    thumbnailUrl: image.thumbnail_storage_key ? `/api/images/${image.id}/thumbnail` : null,
    createdAt: image.created_at,
    ...includeMetadata ? {
      prompt: image.prompt,
      quality: image.quality,
      aspectRatio: image.aspect_ratio
    } : {}
  };
}
function imageResponseHeaders(contentType, contentDisposition, etag, contentLength2) {
  const headers = {
    "Content-Type": contentType,
    "Cache-Control": IMAGE_CACHE_CONTROL,
    "Content-Disposition": contentDisposition,
    "ETag": etag
  };
  if (typeof contentLength2 === "number" && Number.isFinite(contentLength2) && contentLength2 >= 0) {
    headers["Content-Length"] = String(contentLength2);
  }
  return headers;
}
function imageETag(sha256) {
  return `"${sha256.replace(/"/g, "")}"`;
}
function referenceImageETag(storageKey, byteSize) {
  return imageETag(`${storageKey}:${byteSize}`);
}
function formatFromMimeType2(mimeType) {
  if (mimeType === "image/jpeg") return "jpg";
  if (mimeType === "image/webp") return "webp";
  return "png";
}
function matchesIfNoneMatch(value, etag) {
  if (!value) return false;
  return value.split(",").map((item) => item.trim()).some((item) => item === etag || item === "*");
}
function generationElapsedSeconds(job) {
  const startedAt = parseDbTimestamp(job.started_at ?? job.created_at);
  const finishedAt = job.completed_at ? parseDbTimestamp(job.completed_at) : Date.now();
  if (!Number.isFinite(startedAt) || !Number.isFinite(finishedAt) || finishedAt < startedAt) return null;
  return Math.round((finishedAt - startedAt) / 1e3);
}
function parseDbTimestamp(value) {
  if (/[zZ]|[+-]\d{2}:\d{2}$/.test(value)) return Date.parse(value);
  return Date.parse(`${value.replace(" ", "T")}Z`);
}
function optionOrFallback(value, options) {
  const normalized = value?.trim() ?? "";
  return options.some((option) => option === normalized) ? normalized : options[0];
}
function resolveProviderRetryAttempts(value) {
  return Math.min(Math.max(Math.trunc(envNumber(value, DEFAULT_PROVIDER_RETRY_ATTEMPTS)), 0), MAX_PROVIDER_RETRY_ATTEMPTS);
}
function resolvePostProcessingRetryAttempts(value) {
  return Math.min(
    Math.max(Math.trunc(envNumber(value, DEFAULT_POST_PROCESSING_RETRY_ATTEMPTS)), 0),
    MAX_POST_PROCESSING_RETRY_ATTEMPTS
  );
}
function serializeInspiration(item) {
  return inspirationItemShape(item);
}
function inspirationItemShape(item) {
  return {
    id: item.id,
    sourceKey: item.source_key ?? "",
    sourceName: item.source_name ?? "",
    originalUrl: item.original_url,
    author: item.author,
    title: item.title,
    prompt: item.prompt,
    negativePrompt: item.negative_prompt,
    thumbnailUrl: item.thumbnail_storage_key ? `/api/inspirations/${item.id}/thumbnail` : null,
    externalImageUrl: item.original_image_url,
    width: item.width,
    height: item.height,
    aspectRatio: item.aspect_ratio,
    tags: parseInspirationTags(item.tags_json),
    model: item.model,
    safety: item.safety,
    useCount: item.use_count,
    importedAt: item.imported_at,
    favorite: Boolean(item.favorite)
  };
}

// src/node/worker.ts
var runtime = createNodeRuntime({ queues: false });
var redisUrl = process.env.REDIS_URL ?? "redis://127.0.0.1:6379";
var generationConnection = createRedisConnection(redisUrl);
var inspirationConnection = createRedisConnection(redisUrl);
var maxProviderRetryAttempts = resolveProviderRetryAttempts(runtime.env.PROVIDER_RETRY_ATTEMPTS);
var maxPostProcessingRetryAttempts = resolvePostProcessingRetryAttempts(runtime.env.POST_PROCESSING_RETRY_ATTEMPTS);
var generationConcurrency = Math.max(1, Number(process.env.NODE_GENERATION_WORKER_CONCURRENCY ?? 10));
var generationWorker = new Worker(
  GENERATION_QUEUE_NAME,
  async (job) => {
    await processGenerationMessage(job.data, runtime.env, {
      retryProviderErrors: job.attemptsMade < maxProviderRetryAttempts,
      retryPostProcessingErrors: job.attemptsMade < maxPostProcessingRetryAttempts
    });
  },
  {
    connection: generationConnection,
    concurrency: generationConcurrency,
    lockDuration: 12e4
  }
);
var inspirationWorker = new Worker(
  INSPIRATION_QUEUE_NAME,
  async (job) => {
    await processInspirationSourceMessage(job.data, runtime.env);
  },
  {
    connection: inspirationConnection,
    concurrency: Math.max(1, Number(process.env.NODE_INSPIRATION_WORKER_CONCURRENCY ?? 1)),
    lockDuration: 12e4
  }
);
generationWorker.on("failed", (job, error) => {
  console.error("generation job failed", JSON.stringify({ id: job?.id, attemptsMade: job?.attemptsMade, error: error.message }));
});
inspirationWorker.on("failed", (job, error) => {
  console.error("inspiration job failed", JSON.stringify({ id: job?.id, attemptsMade: job?.attemptsMade, error: error.message }));
});
console.log(
  "oh-myimage workers started",
  JSON.stringify({ generationConcurrency, maxProviderRetryAttempts, maxPostProcessingRetryAttempts })
);
for (const signal of ["SIGINT", "SIGTERM"]) {
  process.on(signal, () => {
    void shutdown(signal);
  });
}
async function shutdown(signal) {
  console.log(`received ${signal}, shutting down workers`);
  await Promise.all([generationWorker.close(), inspirationWorker.close()]);
  generationConnection.disconnect();
  inspirationConnection.disconnect();
  await runtime.close();
  process.exit(0);
}
//# sourceMappingURL=worker.js.map
