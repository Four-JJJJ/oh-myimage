// src/node/env.ts
import "dotenv/config";

// src/node/postgres-d1.ts
import { Pool } from "pg";
function createPostgresDatabase(connectionString) {
  const pool = new Pool({
    connectionString,
    max: Number(process.env.POSTGRES_POOL_SIZE ?? 10),
    idleTimeoutMillis: 3e4,
    connectionTimeoutMillis: 1e4
  });
  return new PostgresD1Database(pool);
}
var PostgresD1Database = class {
  constructor(pool) {
    this.pool = pool;
  }
  pool;
  prepare(query) {
    return new PostgresPreparedStatement(this.pool, query);
  }
  async close() {
    await this.pool.end();
  }
};
var PostgresPreparedStatement = class {
  constructor(pool, query) {
    this.pool = pool;
    this.query = query;
  }
  pool;
  query;
  values = [];
  bind(...values) {
    this.values = values;
    return this;
  }
  async first() {
    const result = await this.pool.query(translateSql(this.query), this.values);
    return normalizeRow(result.rows[0]);
  }
  async all() {
    const result = await this.pool.query(translateSql(this.query), this.values);
    return { results: result.rows.map((row) => normalizeRow(row)) };
  }
  async run() {
    const result = await this.pool.query(translateSql(this.query), this.values);
    return { success: true, meta: { changes: result.rowCount ?? 0 } };
  }
};
function translateSql(query) {
  const normalized = query.replace(
    /\bCURRENT_TIMESTAMP\b/g,
    "to_char(NOW() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')"
  );
  let index = 0;
  let inSingleQuote = false;
  let output = "";
  for (let i = 0; i < normalized.length; i += 1) {
    const char = normalized[i];
    const next = normalized[i + 1];
    if (char === "'" && next === "'") {
      output += "''";
      i += 1;
      continue;
    }
    if (char === "'") {
      inSingleQuote = !inSingleQuote;
      output += char;
      continue;
    }
    if (char === "?" && !inSingleQuote) {
      index += 1;
      output += `$${index}`;
      continue;
    }
    output += char;
  }
  return output;
}
function normalizeRow(row) {
  if (!row || typeof row !== "object") return row ?? null;
  const record = row;
  for (const [key, value] of Object.entries(record)) {
    if ((key === "count" || key.endsWith("_count")) && typeof value === "string") {
      const numberValue = Number(value);
      if (Number.isFinite(numberValue)) record[key] = numberValue;
    }
  }
  return record;
}

// src/node/queue.ts
import { Queue } from "bullmq";
import IORedis from "ioredis";
var GENERATION_QUEUE_NAME = process.env.BULLMQ_GENERATION_QUEUE_NAME ?? "oh-myimage-generation";
var INSPIRATION_QUEUE_NAME = process.env.BULLMQ_INSPIRATION_QUEUE_NAME ?? "oh-myimage-inspiration";
function createRedisConnection(redisUrl) {
  return new IORedis(redisUrl, {
    maxRetriesPerRequest: null,
    enableReadyCheck: false
  });
}
function createBullQueues(config) {
  const connection = createRedisConnection(config.redisUrl);
  const generation = new Queue(GENERATION_QUEUE_NAME, { connection });
  const inspiration = new Queue(INSPIRATION_QUEUE_NAME, { connection });
  return {
    generationQueue: new BullAppQueue(generation, "generation", {
      attempts: config.generationAttempts,
      backoff: { type: "exponential", delay: config.generationBackoffMs }
    }),
    inspirationQueue: new BullAppQueue(inspiration, "inspiration", {
      attempts: 1
    }),
    async close() {
      await Promise.all([generation.close(), inspiration.close()]);
      connection.disconnect();
    }
  };
}
var BullAppQueue = class {
  constructor(queue, name, defaults) {
    this.queue = queue;
    this.name = name;
    this.defaults = defaults;
  }
  queue;
  name;
  defaults;
  async send(message) {
    await this.queue.add(this.name, message, {
      attempts: this.defaults.attempts,
      backoff: this.defaults.backoff,
      removeOnComplete: 1e3,
      removeOnFail: 5e3
    });
  }
};

// src/node/r2-store.ts
import { Readable } from "node:stream";
import { CopyObjectCommand, DeleteObjectCommand, GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
function createR2Store(config) {
  const endpoint = resolveR2Endpoint(config);
  const client = new S3Client({
    region: "auto",
    endpoint,
    forcePathStyle: true,
    credentials: {
      accessKeyId: config.accessKeyId,
      secretAccessKey: config.secretAccessKey
    }
  });
  return new S3ObjectStore(client, config.bucket);
}
function resolveR2Endpoint(config) {
  const explicitEndpoint = config.endpoint?.trim();
  if (explicitEndpoint) return explicitEndpoint;
  const accountId = config.accountId?.trim();
  if (!accountId) {
    throw new Error("R2 account ID is required when R2_ENDPOINT is not set.");
  }
  return `https://${accountId}.r2.cloudflarestorage.com`;
}
var S3ObjectStore = class {
  constructor(client, bucket) {
    this.client = client;
    this.bucket = bucket;
  }
  client;
  bucket;
  async put(key, value, options) {
    await this.client.send(
      new PutObjectCommand({
        Bucket: this.bucket,
        Key: key,
        Body: await toS3Body(value),
        ContentType: options?.httpMetadata?.contentType,
        ContentDisposition: options?.httpMetadata?.contentDisposition,
        Metadata: options?.customMetadata
      })
    );
    return {};
  }
  async get(key) {
    try {
      const result = await this.client.send(new GetObjectCommand({ Bucket: this.bucket, Key: key }));
      if (!result.Body) return null;
      return new S3Object(result);
    } catch (error) {
      const name = error instanceof Error ? error.name : "";
      if (name === "NoSuchKey" || name === "NotFound") return null;
      throw error;
    }
  }
  async copy(sourceKey, destinationKey, options) {
    await this.client.send(
      new CopyObjectCommand({
        Bucket: this.bucket,
        Key: destinationKey,
        CopySource: s3CopySource(this.bucket, sourceKey),
        ContentType: options?.httpMetadata?.contentType,
        ContentDisposition: options?.httpMetadata?.contentDisposition,
        Metadata: options?.customMetadata,
        MetadataDirective: "REPLACE"
      })
    );
    return {};
  }
  async delete(key) {
    await this.client.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
  }
  async createPresignedGetUrl(key, options) {
    const command = new GetObjectCommand({
      Bucket: this.bucket,
      Key: key,
      ResponseContentType: options?.contentType,
      ResponseContentDisposition: options?.contentDisposition
    });
    return getSignedUrl(this.client, command, { expiresIn: options?.expiresInSeconds ?? 300 });
  }
};
function s3CopySource(bucket, key) {
  return `${bucket}/${key.split("/").map(encodeURIComponent).join("/")}`;
}
var S3Object = class {
  constructor(result) {
    this.result = result;
    this.httpMetadata = {
      contentType: result.ContentType,
      contentDisposition: result.ContentDisposition
    };
  }
  result;
  httpMetadata;
  get body() {
    const body = this.result.Body;
    return body ? toWebStream(body) : null;
  }
  async arrayBuffer() {
    const body = this.result.Body;
    if (body && typeof body.transformToByteArray === "function") {
      const bytes = await body.transformToByteArray();
      return toArrayBuffer(bytes);
    }
    if (!this.body) return new ArrayBuffer(0);
    return new Response(this.body).arrayBuffer();
  }
};
async function toS3Body(value) {
  if (typeof value === "string") return value;
  if (value instanceof Blob) return Buffer.from(await value.arrayBuffer());
  if (value instanceof ArrayBuffer) return Buffer.from(value);
  if (ArrayBuffer.isView(value)) return Buffer.from(value.buffer, value.byteOffset, value.byteLength);
  return Readable.fromWeb(value);
}
function toWebStream(body) {
  if (typeof body.transformToWebStream === "function") {
    return body.transformToWebStream();
  }
  if (body instanceof Readable) return Readable.toWeb(body);
  throw new Error("Unsupported S3 response body stream.");
}
function toArrayBuffer(bytes) {
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  return copy.buffer;
}

// src/image-models.ts
var DEFAULT_IMAGE_MODEL = "gpt-image-2.5-flare";

// src/worker/http.ts
import { HTTPException } from "hono/http-exception";
function envNumber(value, fallback) {
  if (!value) return fallback;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

// src/node/env.ts
function createNodeRuntime(options = {}) {
  const db = createPostgresDatabase(requiredEnv("DATABASE_URL"));
  const queues = options.queues === false ? null : createBullQueues({
    redisUrl: process.env.REDIS_URL ?? "redis://127.0.0.1:6379",
    generationAttempts: resolveGenerationAttempts(),
    generationBackoffMs: envNumber(process.env.POST_PROCESSING_RETRY_DELAY_SECONDS, 5) * 1e3
  });
  const env = {
    DB: db,
    IMAGES: createR2Store({
      accountId: process.env.R2_ACCOUNT_ID,
      endpoint: process.env.R2_ENDPOINT,
      accessKeyId: requiredEnv("R2_ACCESS_KEY_ID"),
      secretAccessKey: requiredEnv("R2_SECRET_ACCESS_KEY"),
      bucket: requiredEnv("R2_BUCKET")
    }),
    GENERATION_QUEUE: queues?.generationQueue ?? disabledQueue("generation"),
    INSPIRATION_QUEUE: queues?.inspirationQueue ?? disabledQueue("inspiration"),
    APP_ENCRYPTION_KEY: requiredEnv("APP_ENCRYPTION_KEY"),
    TURNSTILE_SECRET_KEY: process.env.TURNSTILE_SECRET_KEY ?? "",
    TURNSTILE_SITE_KEY: process.env.TURNSTILE_SITE_KEY ?? "",
    TURNSTILE_REQUIRED: process.env.TURNSTILE_REQUIRED ?? "false",
    DEFAULT_IMAGE_MODEL: process.env.DEFAULT_IMAGE_MODEL ?? DEFAULT_IMAGE_MODEL,
    PROMPT_OPTIMIZER_MODEL: process.env.PROMPT_OPTIMIZER_MODEL ?? "gpt-5.5",
    MAX_IMAGES_PER_REQUEST: process.env.MAX_IMAGES_PER_REQUEST ?? "4",
    MAX_RUNNING_JOBS_PER_SPACE: process.env.MAX_RUNNING_JOBS_PER_SPACE ?? "12",
    REQUEST_TIMEOUT_MS: process.env.REQUEST_TIMEOUT_MS ?? "600000",
    GENERATION_JOB_MAX_RUNTIME_MS: process.env.GENERATION_JOB_MAX_RUNTIME_MS ?? "840000",
    PROVIDER_IMAGE_CONCURRENCY: process.env.PROVIDER_IMAGE_CONCURRENCY ?? "2",
    PROVIDER_TIMEOUT_RETRY_ATTEMPTS: process.env.PROVIDER_TIMEOUT_RETRY_ATTEMPTS ?? "0",
    PROVIDER_RETRY_ATTEMPTS: process.env.PROVIDER_RETRY_ATTEMPTS ?? "0",
    PROVIDER_RETRY_DELAY_SECONDS: process.env.PROVIDER_RETRY_DELAY_SECONDS ?? "120",
    POST_PROCESSING_RETRY_ATTEMPTS: process.env.POST_PROCESSING_RETRY_ATTEMPTS ?? "2",
    POST_PROCESSING_RETRY_DELAY_SECONDS: process.env.POST_PROCESSING_RETRY_DELAY_SECONDS ?? "5",
    IMAGE_RETENTION_DAYS: process.env.IMAGE_RETENTION_DAYS ?? "90",
    X_BEARER_TOKEN: process.env.X_BEARER_TOKEN ?? "",
    INSPIRATION_FEATURE_ENABLED: process.env.INSPIRATION_FEATURE_ENABLED ?? "false",
    INSPIRATION_MAX_ITEMS_PER_RUN: process.env.INSPIRATION_MAX_ITEMS_PER_RUN ?? "12",
    INSPIRATION_THUMBNAIL_MAX_BYTES: process.env.INSPIRATION_THUMBNAIL_MAX_BYTES ?? "1048576",
    INSPIRATION_AUTO_PUBLISH_SOURCES: process.env.INSPIRATION_AUTO_PUBLISH_SOURCES ?? "civitai"
  };
  return {
    env,
    async close() {
      await Promise.all([closeDatabase(db), closeQueues(queues)]);
    }
  };
}
function requiredEnv(name) {
  const value = process.env[name]?.trim();
  if (!value) throw new Error(`${name} is required.`);
  return value;
}
function resolveGenerationAttempts() {
  return resolveGenerationQueueAttempts(process.env.PROVIDER_RETRY_ATTEMPTS, process.env.POST_PROCESSING_RETRY_ATTEMPTS);
}
function resolveGenerationQueueAttempts(providerValue, postProcessingValue) {
  return Math.max(1, Math.trunc(Math.max(envNumber(providerValue, 0), envNumber(postProcessingValue, 2))) + 1);
}
function disabledQueue(name) {
  return {
    async send() {
      throw new Error(`${name} queue is disabled in this process.`);
    }
  };
}
async function closeDatabase(db) {
  await db.close();
}
async function closeQueues(queues) {
  if (queues) await queues.close();
}

// src/worker/crypto.ts
var encoder = new TextEncoder();
var decoder = new TextDecoder();

// src/worker/inspiration.ts
async function listEnabledInspirationSources(db) {
  const result = await db.prepare("SELECT * FROM inspiration_sources WHERE enabled = 1 ORDER BY source_key ASC").all();
  return result.results ?? [];
}

// src/node/cron.ts
var runtime = createNodeRuntime();
try {
  if (runtime.env.INSPIRATION_FEATURE_ENABLED === "true") {
    const sources = await listEnabledInspirationSources(runtime.env.DB);
    const results = await Promise.allSettled(
      sources.map(
        (source) => runtime.env.INSPIRATION_QUEUE.send({
          type: "inspiration-source",
          sourceId: source.id,
          trigger: "scheduled"
        })
      )
    );
    const failed = results.filter((result) => result.status === "rejected").length;
    console.log(`scheduled inspiration enqueue completed: ${sources.length - failed}/${sources.length}`);
    if (failed > 0) process.exitCode = 1;
  } else {
    console.log("inspiration cron skipped: INSPIRATION_FEATURE_ENABLED is not true");
  }
} finally {
  await runtime.close();
}
//# sourceMappingURL=cron.js.map
