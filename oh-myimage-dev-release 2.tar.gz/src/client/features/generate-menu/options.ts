import { clampResolutionForRatio, qualityTiersForModel, RATIO_OPTIONS, RESOLUTION_OPTIONS, resolutionOptionsForRatio } from "../../../image-models";

export const qualityLabels: Record<string, string> = {
  auto: "Auto",
  low: "Low",
  medium: "Medium",
  high: "High",
  xhigh: "XHigh",
  max: "Max",
};

export const formatLabels: Record<string, string> = {
  png: "PNG",
  jpeg: "JPEG",
  webp: "WEBP",
};

export const ratioLabels: Record<string, string> = {
  custom: "自定义",
};

export const ratioOptions = [...RATIO_OPTIONS, "custom"] as const;
export const resolutionOptions = RESOLUTION_OPTIONS;
export const qualityOptions = ["auto", "low", "medium", "high", "xhigh", "max"] as const;
export const formatOptions = ["png", "jpeg", "webp"] as const;

export function qualityOptionsForModel(model: string): readonly string[] {
  return qualityTiersForModel(model);
}

export function resolutionOptionsForForm(form: { aspectRatio: string }): string[] {
  if (form.aspectRatio === "custom") return [...RESOLUTION_OPTIONS];
  const options = resolutionOptionsForRatio(form.aspectRatio);
  return options.length > 0 ? options : [...RESOLUTION_OPTIONS];
}

export function clampResolutionForForm(aspectRatio: string, resolution: string): string {
  return aspectRatio === "custom" ? resolution : clampResolutionForRatio(aspectRatio, resolution);
}

export interface GenerationSettingsSummaryInput {
  aspectRatio: string;
  quality: string;
  resolution: string;
  quantity: number;
  outputFormat: string;
}

export function generationSettingsSummaryParts(settings: GenerationSettingsSummaryInput): string[] {
  return [
    ratioLabels[settings.aspectRatio] ?? settings.aspectRatio,
    qualityLabels[settings.quality] ?? settings.quality,
    settings.resolution,
    `${settings.quantity}张`,
    formatLabels[settings.outputFormat] ?? settings.outputFormat.toUpperCase(),
  ];
}

export function formatGenerationSettingsSummary(settings: GenerationSettingsSummaryInput): string {
  return generationSettingsSummaryParts(settings).join("｜");
}
