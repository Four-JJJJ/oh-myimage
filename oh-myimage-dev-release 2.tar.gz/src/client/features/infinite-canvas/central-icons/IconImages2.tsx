import React, { memo, forwardRef, useId, createElement } from "react";

export const IconImages2 = memo(forwardRef<SVGSVGElement, { size?: number | string; color?: string; className?: string; style?: React.CSSProperties }>(function IconImages2({ size = 24, color, style, ...props }, ref) {
  const rawId = useId();
  const maskId = "icon" + rawId.replace(/:/g, "");
  return createElement("svg", { ...props, ref, width: size, height: size, viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg", style: { color, ...style } },
    createElement("mask", { id: maskId, maskUnits: "userSpaceOnUse", x: "0", y: "0", width: "24", height: "24" },
      createElement("rect", { width: "24", height: "24", fill: "#000" }),
      createElement("path", { d: "M6.58579 13.4142L7.11612 13.9445H7.11612L6.58579 13.4142ZM9.41421 13.4142L9.94454 12.8839L9.41421 13.4142ZM5.75 4.5H18.25V3H5.75V4.5ZM19.5 5.75V18.25H21V5.75H19.5ZM4.28033 16.7803L7.11612 13.9445L6.05546 12.8839L3.21967 15.7197L4.28033 16.7803ZM4.5 18.25V16.25H3V18.25H4.5ZM4.5 16.25V5.75H3V16.25H4.5ZM8.88388 13.9445L15.7197 20.7803L16.7803 19.7197L9.94454 12.8839L8.88388 13.9445ZM18.25 19.5H16.25V21H18.25V19.5ZM16.25 19.5H5.75V21H16.25V19.5ZM7.11612 13.9445C7.60427 13.4564 8.39573 13.4564 8.88388 13.9445L9.94454 12.8839C8.8706 11.8099 7.1294 11.8099 6.05546 12.8839L7.11612 13.9445ZM3 18.25C3 19.7688 4.23122 21 5.75 21V19.5C5.05964 19.5 4.5 18.9404 4.5 18.25H3ZM19.5 18.25C19.5 18.9404 18.9404 19.5 18.25 19.5V21C19.7688 21 21 19.7688 21 18.25H19.5ZM18.25 4.5C18.9404 4.5 19.5 5.05964 19.5 5.75H21C21 4.23122 19.7688 3 18.25 3V4.5ZM5.75 3C4.23122 3 3 4.23122 3 5.75H4.5C4.5 5.05964 5.05964 4.5 5.75 4.5V3ZM15.75 9.5C15.75 10.1904 15.1904 10.75 14.5 10.75V12.25C16.0188 12.25 17.25 11.0188 17.25 9.5H15.75ZM14.5 10.75C13.8096 10.75 13.25 10.1904 13.25 9.5H11.75C11.75 11.0188 12.9812 12.25 14.5 12.25V10.75ZM13.25 9.5C13.25 8.80964 13.8096 8.25 14.5 8.25V6.75C12.9812 6.75 11.75 7.98122 11.75 9.5H13.25ZM14.5 8.25C15.1904 8.25 15.75 8.80964 15.75 9.5H17.25C17.25 7.98122 16.0188 6.75 14.5 6.75V8.25Z", fill: "#fff" }),
    ),
    createElement("rect", { width: "24", height: "24", fill: "currentColor", mask: `url(#${maskId})` }),
  );
}));
