import React, { memo, forwardRef, useId, createElement } from "react";

export const IconHand5Finger = memo(forwardRef<SVGSVGElement, { size?: number | string; color?: string; className?: string; style?: React.CSSProperties }>(function IconHand5Finger({ size = 24, color, style, ...props }, ref) {
  const rawId = useId();
  const maskId = "icon" + rawId.replace(/:/g, "");
  return createElement("svg", { ...props, ref, width: size, height: size, viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg", style: { color, ...style } },
    createElement("mask", { id: maskId, maskUnits: "userSpaceOnUse", x: "0", y: "0", width: "24", height: "24" },
      createElement("rect", { width: "24", height: "24", fill: "#000" }),
      createElement("path", { d: "M16.25 7.75V7.25C16.25 6.42157 16.9216 5.75 17.75 5.75C18.5784 5.75 19.25 6.42157 19.25 7.25V14.2354C19.25 18.1094 16.1094 21.25 12.2354 21.25C9.32487 21.25 6.71671 19.4527 5.68043 16.7329L3.25 10.3542C3.73657 9.15947 5.3114 8.89654 6.15969 9.86836L7.25 11.1175V5.25C7.25 4.42157 7.92157 3.75 8.75 3.75C9.57843 3.75 10.25 4.42157 10.25 5.25V11M10.25 9.75V4.25C10.25 3.42157 10.9216 2.75 11.75 2.75C12.5784 2.75 13.25 3.42157 13.25 4.25V11.5M13.25 7.75V5.25C13.25 4.42157 13.9216 3.75 14.75 3.75C15.5784 3.75 16.25 4.42157 16.25 5.25V12", fill: "#fff" }),
    ),
    createElement("rect", { width: "24", height: "24", fill: "currentColor", mask: `url(#${maskId})` }),
  );
}));
