import React, { memo, forwardRef, useId, createElement } from "react";

export const IconPlusSmall = memo(forwardRef<SVGSVGElement, { size?: number | string; color?: string; className?: string; style?: React.CSSProperties }>(function IconPlusSmall({ size = 24, color, style, ...props }, ref) {
  const rawId = useId();
  const maskId = "icon" + rawId.replace(/:/g, "");
  return createElement("svg", { ...props, ref, width: size, height: size, viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg", style: { color, ...style } },
    createElement("mask", { id: maskId, maskUnits: "userSpaceOnUse", x: "0", y: "0", width: "24", height: "24" },
      createElement("rect", { width: "24", height: "24", fill: "#000" }),
      createElement("path", { d: "M12 6.75V12M12 12V17.25M12 12H6.75M12 12H17.25", fill: "#fff" }),
    ),
    createElement("rect", { width: "24", height: "24", fill: "currentColor", mask: `url(#${maskId})` }),
  );
}));
