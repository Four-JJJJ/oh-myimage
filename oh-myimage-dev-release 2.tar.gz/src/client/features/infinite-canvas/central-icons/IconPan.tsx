import React, { memo, forwardRef, useId, createElement } from "react";

export const IconPan = memo(forwardRef<SVGSVGElement, { size?: number | string; color?: string; className?: string; style?: React.CSSProperties }>(function IconPan({ size = 24, color, style, ...props }, ref) {
  const rawId = useId();
  const maskId = "icon" + rawId.replace(/:/g, "");
  return createElement("svg", { ...props, ref, width: size, height: size, viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg", style: { color, ...style } },
    createElement("mask", { id: maskId, maskUnits: "userSpaceOnUse", x: "0", y: "0", width: "24", height: "24" },
      createElement("rect", { width: "24", height: "24", fill: "#000" }),
      createElement("path", { d: "M15.8703 12.9552L23.1963 11.1494M2.80078 16.1767L15.8869 12.9531L16.2634 14.4449C16.6792 16.0928 15.6643 17.7617 13.9964 18.1725L6.95006 19.9084C5.28223 20.3192 3.59309 19.3164 3.17725 17.6686L2.80078 16.1767Z", fill: "#fff" }),
    ),
    createElement("rect", { width: "24", height: "24", fill: "currentColor", mask: `url(#${maskId})` }),
  );
}));
