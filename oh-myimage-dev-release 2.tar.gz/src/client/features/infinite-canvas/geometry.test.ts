import { describe, expect, it } from "vitest";
import {
  canConnect,
  connectNodes,
  createCanvasNode,
  duplicateNodes,
  emptyCanvasDocument,
  fitViewport,
  nodesInsideRect,
  parseCanvasDocument,
  promptForNode,
  referenceSourcesForNode,
  removeNodes,
  screenToCanvas,
  zoomViewportAt,
} from "./geometry";

describe("infinite canvas geometry", () => {
  it("keeps the point under the cursor fixed while zooming", () => {
    const viewport = zoomViewportAt({ x: 40, y: 20, zoom: 1 }, { x: 140, y: 120 }, 2);
    expect(screenToCanvas({ x: 140, y: 120 }, viewport)).toEqual({ x: 100, y: 100 });
    expect(viewport.zoom).toBe(2);
  });

  it("selects every node touched by a marquee, including a reverse drag", () => {
    const nodes = [
      createCanvasNode("text", { x: 0, y: 0 }, "a"),
      createCanvasNode("image", { x: 400, y: 40 }, "b"),
    ];
    expect(nodesInsideRect(nodes, { x: 500, y: 300, width: -180, height: -80 })).toEqual(["b"]);
  });

  it("rejects a connection that would cycle and accepts a usable upstream link", () => {
    const nodes = [
      createCanvasNode("text", { x: 0, y: 0 }, "prompt"),
      createCanvasNode("image", { x: 360, y: 0 }, "picture"),
    ];
    const edges = connectNodes(nodes, [], "prompt", "picture", "edge-1");
    expect(edges).toHaveLength(1);
    expect(canConnect(nodes, edges, "picture", "prompt")).toBe(false);
    expect(canConnect(nodes, edges, "prompt", "picture")).toBe(false);
  });

  it("builds a prompt from the node and its text upstreams", () => {
    const text = { ...createCanvasNode("text", { x: 0, y: 0 }, "text"), text: "雾气森林" };
    const image = { ...createCanvasNode("image", { x: 360, y: 0 }, "image"), text: "电影感" };
    const edges = connectNodes([text, image], [], "text", "image", "edge");
    expect(promptForNode([text, image], edges, "image")).toBe("电影感\n\n雾气森林");
  });

  it("keeps only upstream images that already have a picture", () => {
    const upload = { ...createCanvasNode("upload", { x: 0, y: 0 }, "upload"), imageUrl: "blob:ref" };
    const empty = createCanvasNode("image", { x: 0, y: 240 }, "empty");
    const target = createCanvasNode("image", { x: 360, y: 80 }, "target");
    const nodes = [upload, empty, target];
    const edges = [
      ...connectNodes(nodes, [], "upload", "target", "a"),
      ...connectNodes(nodes, [], "empty", "target", "b"),
    ];
    expect(referenceSourcesForNode(nodes, edges, "target").map((node) => node.id)).toEqual(["upload"]);
  });

  it("duplicates a connected selection without sharing ids or jobs", () => {
    const first = createCanvasNode("text", { x: 10, y: 10 }, "first");
    const second = { ...createCanvasNode("image", { x: 320, y: 10 }, "second"), jobId: "job_1", status: "succeeded" as const };
    const document = {
      ...emptyCanvasDocument(),
      nodes: [first, second],
      edges: connectNodes([first, second], [], "first", "second", "edge"),
    };
    const ids = ["copy-a", "copy-b", "copy-edge"];
    const duplicated = duplicateNodes(document, ["first", "second"], () => ids.shift() ?? "missing");
    expect(duplicated.nodes.map((node) => node.id)).toEqual(["first", "second", "copy-a", "copy-b"]);
    expect(duplicated.edges.at(-1)).toEqual({ id: "copy-edge", from: "copy-a", to: "copy-b" });
    expect(duplicated.nodes.at(-1)?.jobId).toBeUndefined();
    expect(removeNodes(duplicated, ["copy-a"]).edges.some((edge) => edge.id === "copy-edge")).toBe(false);
  });

  it("restores a saved document and drops dangling edges", () => {
    const raw = JSON.stringify({
      name: "分镜",
      nodes: [createCanvasNode("text", { x: 1, y: 2 }, "kept")],
      edges: [{ id: "gone", from: "kept", to: "missing" }],
      viewport: { x: 3, y: 4, zoom: 9 },
    });
    const parsed = parseCanvasDocument(raw);
    expect(parsed?.name).toBe("分镜");
    expect(parsed?.edges).toEqual([]);
    expect(parsed?.viewport.zoom).toBeLessThanOrEqual(2.4);
    expect(parseCanvasDocument("not-json")).toBeNull();
  });

  it("frames every node inside the visible canvas", () => {
    const nodes = [
      createCanvasNode("text", { x: 0, y: 0 }, "a"),
      createCanvasNode("image", { x: 600, y: 300 }, "b"),
    ];
    const viewport = fitViewport(nodes, { width: 1000, height: 700 });
    expect(viewport.zoom).toBeGreaterThan(0.2);
    expect(viewport.zoom).toBeLessThanOrEqual(1);
  });
});
